import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, PlayCircle, CalendarDays } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DemoRequest } from '@/api/entities'; // Added DemoRequest import

export default function Demo() {
  const [isSubmitting, setIsSubmitting] = useState(false); // Added state for form submission
  const [formData, setFormData] = useState({ // Added state for form data
    name: '',
    email: '',
    phone: '',
    companyName: '',
    comments: ''
  });

  const handleInputChange = (e) => { // Added input change handler
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => { // Updated submit handler
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Save demo request to database
      await DemoRequest.create({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        companyName: formData.companyName,
        comments: formData.comments,
        status: 'pending'
      });

      alert("Solicitação de demonstração enviada! Entraremos em contato em breve.");
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        phone: '',
        companyName: '',
        comments: ''
      });
    } catch (error) {
      console.error('Erro ao enviar solicitação:', error);
      alert("Erro ao enviar solicitação. Tente novamente.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Home
            </Button>
          </Link>
        </div>
        <div className="bg-white p-8 sm:p-12 shadow-xl rounded-lg">
          <header className="text-center mb-10">
            <PlayCircle className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <h1 className="text-4xl font-bold text-gray-900 mb-3">Agende uma Demonstração Personalizada</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Veja o AutoCheckin em ação e descubra como podemos transformar a gestão da sua oficina. É rápido, fácil e sem compromisso!
            </p>
          </header>
          
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-semibold text-gray-800 mb-3">O que você verá na demonstração:</h2>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Como funciona o check-in digital na prática.</li>
                  <li>Navegação pelo painel administrativo da oficina.</li>
                  <li>Criação e gestão de serviços.</li>
                  <li>Consulta ao histórico de veículos por placa.</li>
                  <li>Geração de relatórios e insights.</li>
                  <li>Funcionalidades do QR Code e links diretos.</li>
                  <li>Sessão de perguntas e respostas com nosso especialista.</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Benefícios de uma demo personalizada:</h3>
                 <p className="text-gray-700">
                   Entenda como o AutoCheckin se adapta às necessidades específicas da sua oficina e tire todas as suas dúvidas diretamente com nossa equipe.
                 </p>
              </div>
            </div>

            <Card className="p-8 bg-gray-50 shadow-lg">
              <form onSubmit={handleSubmit} className="space-y-6">
                <h3 className="text-xl font-semibold text-center text-blue-700 mb-4">Preencha para agendar:</h3>
                <div>
                  <Label htmlFor="name" className="font-medium">Seu Nome</Label>
                  <Input 
                    id="name" 
                    name="name"
                    type="text" 
                    required 
                    className="mt-1" 
                    placeholder="Nome Completo"
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="font-medium">Seu Email</Label>
                  <Input 
                    id="email" 
                    name="email"
                    type="email" 
                    required 
                    className="mt-1" 
                    placeholder="seu@email.com"
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="phone" className="font-medium">Seu Telefone/WhatsApp</Label>
                  <Input 
                    id="phone" 
                    name="phone"
                    type="tel" 
                    required 
                    className="mt-1" 
                    placeholder="(XX) XXXXX-XXXX"
                    value={formData.phone}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="companyName" className="font-medium">Nome da Oficina</Label>
                  <Input 
                    id="companyName" 
                    name="companyName"
                    type="text" 
                    className="mt-1" 
                    placeholder="Oficina Exemplo"
                    value={formData.companyName}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <Label htmlFor="comments" className="font-medium">Melhor horário ou observação (opcional)</Label>
                  <Input 
                    id="comments" 
                    name="comments"
                    type="text" 
                    className="mt-1" 
                    placeholder="Manhã, Tarde, etc."
                    value={formData.comments}
                    onChange={handleInputChange}
                  />
                </div>
                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
                  disabled={isSubmitting}
                >
                  <CalendarDays className="w-5 h-5" />
                  {isSubmitting ? 'Enviando...' : 'Solicitar Demonstração'}
                </Button>
              </form>
            </Card>
          </div>
           <p className="mt-8 text-center text-sm text-gray-500">
            (Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)
          </p>
        </div>
      </div>
    </div>
  );
}