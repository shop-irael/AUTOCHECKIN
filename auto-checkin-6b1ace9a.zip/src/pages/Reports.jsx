import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkin, Servico } from '@/api/entities';
import { 
  Download, 
  BarChart3, 
  Calendar,
  FileText,
  TrendingUp,
  Users,
  Car,
  DollarSign,
  Settings
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, startOfYear, endOfYear, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Reports() {
  const [checkins, setCheckins] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('current_month');
  const [reportData, setReportData] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (checkins.length > 0) {
      generateReport();
    }
  }, [checkins, services, period]);

  const loadData = async () => {
    try {
      const [checkinsData, servicesData] = await Promise.all([
        Checkin.list('-created_date'),
        Servico.list()
      ]);
      setCheckins(checkinsData);
      setServices(servicesData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDateRange = () => {
    const now = new Date();
    switch (period) {
      case 'current_month':
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case 'last_month':
        const lastMonth = subMonths(now, 1);
        return { start: startOfMonth(lastMonth), end: endOfMonth(lastMonth) };
      case 'current_year':
        return { start: startOfYear(now), end: endOfYear(now) };
      case 'all_time':
        return { start: new Date(0), end: now };
      default:
        return { start: startOfMonth(now), end: endOfMonth(now) };
    }
  };

  const generateReport = () => {
    const { start, end } = getDateRange();
    
    // Filtrar check-ins por período
    const filteredCheckins = checkins.filter(checkin => {
      const checkinDate = new Date(checkin.created_date);
      return checkinDate >= start && checkinDate <= end;
    });

    // Estatísticas gerais
    const totalCheckins = filteredCheckins.length;
    const completedCheckins = filteredCheckins.filter(c => c.status === 'completed').length;
    const pendingCheckins = filteredCheckins.filter(c => c.status === 'pending_confirmation').length;
    const inServiceCheckins = filteredCheckins.filter(c => c.status === 'in_service').length;

    // Clientes únicos
    const uniqueClients = new Set(filteredCheckins.map(c => c.clientPhone)).size;

    // Veículos únicos
    const uniqueVehicles = new Set(filteredCheckins.map(c => c.vehiclePlate)).size;

    // Serviços mais solicitados
    const serviceCount = {};
    filteredCheckins.forEach(checkin => {
      checkin.selectedServiceIds?.forEach(serviceId => {
        serviceCount[serviceId] = (serviceCount[serviceId] || 0) + 1;
      });
    });

    const topServices = Object.entries(serviceCount)
      .map(([serviceId, count]) => ({
        service: services.find(s => s.id === serviceId),
        count
      }))
      .filter(item => item.service)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // Receita estimada (baseada nos preços dos serviços)
    let estimatedRevenue = 0;
    filteredCheckins.forEach(checkin => {
      if (checkin.status === 'completed') {
        checkin.selectedServiceIds?.forEach(serviceId => {
          const service = services.find(s => s.id === serviceId);
          if (service?.price) {
            estimatedRevenue += service.price;
          }
        });
      }
    });

    // Check-ins por status
    const statusData = [
      { status: 'completed', count: completedCheckins, label: 'Concluídos' },
      { status: 'in_service', count: inServiceCheckins, label: 'Em Serviço' },
      { status: 'pending_confirmation', count: pendingCheckins, label: 'Pendentes' },
    ];

    // Check-ins por dia (últimos 7 dias para mês atual)
    const dailyData = [];
    if (period === 'current_month') {
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dayCheckins = filteredCheckins.filter(c => 
          new Date(c.created_date).toDateString() === date.toDateString()
        ).length;
        dailyData.push({
          date: format(date, 'dd/MM'),
          count: dayCheckins
        });
      }
    }

    setReportData({
      period: period,
      dateRange: { start, end },
      totalCheckins,
      completedCheckins,
      pendingCheckins,
      inServiceCheckins,
      uniqueClients,
      uniqueVehicles,
      estimatedRevenue,
      topServices,
      statusData,
      dailyData,
      filteredCheckins
    });
  };

  const exportToCSV = () => {
    if (!reportData) return;

    const csvContent = [
      ['Data', 'Cliente', 'Telefone', 'Placa', 'Veículo', 'Status', 'Serviços'],
      ...reportData.filteredCheckins.map(checkin => [
        format(new Date(checkin.created_date), 'dd/MM/yyyy HH:mm'),
        checkin.clientName,
        checkin.clientPhone,
        checkin.vehiclePlate,
        `${checkin.vehicleModel} ${checkin.vehicleYear}`,
        checkin.status,
        checkin.selectedServiceIds?.map(id => 
          services.find(s => s.id === id)?.name || 'Serviço não encontrado'
        ).join('; ') || ''
      ])
    ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `relatorio-checkins-${period}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getPeriodLabel = () => {
    switch (period) {
      case 'current_month': return 'Mês Atual';
      case 'last_month': return 'Mês Passado';
      case 'current_year': return 'Ano Atual';
      case 'all_time': return 'Todo o Período';
      default: return 'Período';
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="space-y-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-8 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Relatórios</h1>
          <p className="text-gray-600 mt-1">Análise detalhada dos check-ins da sua oficina</p>
        </div>
        <div className="flex gap-3">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current_month">Mês Atual</SelectItem>
              <SelectItem value="last_month">Mês Passado</SelectItem>
              <SelectItem value="current_year">Ano Atual</SelectItem>
              <SelectItem value="all_time">Todo o Período</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={exportToCSV} variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Exportar CSV
          </Button>
        </div>
      </div>

      {reportData && (
        <>
          {/* Period Info */}
          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{getPeriodLabel()}</h3>
                  <p className="text-gray-600">
                    {format(reportData.dateRange.start, "dd/MM/yyyy", { locale: ptBR })} - {' '}
                    {format(reportData.dateRange.end, "dd/MM/yyyy", { locale: ptBR })}
                  </p>
                </div>
                <Calendar className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          {/* Main Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-l-4 border-l-blue-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Total de Check-ins</p>
                    <p className="text-3xl font-bold text-gray-900">{reportData.totalCheckins}</p>
                  </div>
                  <FileText className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-green-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Clientes Únicos</p>
                    <p className="text-3xl font-bold text-gray-900">{reportData.uniqueClients}</p>
                  </div>
                  <Users className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Veículos Únicos</p>
                    <p className="text-3xl font-bold text-gray-900">{reportData.uniqueVehicles}</p>
                  </div>
                  <Car className="w-8 h-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-orange-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Receita Estimada</p>
                    <p className="text-3xl font-bold text-gray-900">
                      R$ {reportData.estimatedRevenue.toFixed(2)}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Status Distribution */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Distribuição por Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reportData.statusData.map((item, index) => (
                  <div key={item.status} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-4 h-4 rounded-full ${
                        item.status === 'completed' ? 'bg-green-500' :
                        item.status === 'in_service' ? 'bg-purple-500' :
                        'bg-yellow-500'
                      }`}></div>
                      <span className="font-medium">{item.label}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-2xl font-bold">{item.count}</span>
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            item.status === 'completed' ? 'bg-green-500' :
                            item.status === 'in_service' ? 'bg-purple-500' :
                            'bg-yellow-500'
                          }`}
                          style={{ 
                            width: `${reportData.totalCheckins > 0 ? (item.count / reportData.totalCheckins) * 100 : 0}%` 
                          }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-500 w-12">
                        {reportData.totalCheckins > 0 ? Math.round((item.count / reportData.totalCheckins) * 100) : 0}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Services */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Serviços Mais Solicitados
              </CardTitle>
            </CardHeader>
            <CardContent>
              {reportData.topServices.length === 0 ? (
                <p className="text-gray-500 text-center py-4">Nenhum serviço solicitado no período</p>
              ) : (
                <div className="space-y-4">
                  {reportData.topServices.map((item, index) => (
                    <div key={item.service.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-600">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{item.service.name}</p>
                          {item.service.category && (
                            <p className="text-sm text-gray-600">{item.service.category}</p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-blue-600">{item.count}</p>
                        <p className="text-sm text-gray-500">solicitações</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Daily Activity (for current month) */}
          {period === 'current_month' && reportData.dailyData.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Atividade dos Últimos 7 Dias
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between gap-2 h-40">
                  {reportData.dailyData.map((day, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div 
                        className="w-full bg-blue-500 rounded-t min-h-[4px] flex items-end justify-center text-white text-xs font-bold"
                        style={{ 
                          height: `${Math.max(20, (day.count / Math.max(...reportData.dailyData.map(d => d.count), 1)) * 120)}px` 
                        }}
                      >
                        {day.count > 0 && day.count}
                      </div>
                      <p className="text-xs text-gray-500 mt-2">{day.date}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}