import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Eye, Trash2, PlusCircle } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function EditPrecos() {
  const [saving, setSaving] = useState(false);
  const [pageData, setPageData] = useState({
    title: "Planos e Preços Transparentes",
    subtitle: "Escolha o plano AutoCheckin que melhor se adapta às necessidades e ao tamanho da sua oficina.",
    ctaText: "Comece seu teste grátis de 7 dias agora!",
    freeTrialDetails: "Sem cartão de crédito. Cancele quando quiser."
  });
  const [plans, setPlans] = useState([
    {
      id: 'basico',
      name: 'Básico',
      price: '29',
      period: '/mês',
      description: 'Perfeito para oficinas pequenas iniciando na digitalização.',
      checkins: '100 check-ins/mês',
      features: [
        'Formulário de check-in digital personalizável',
        'Armazenamento seguro de fotos e assinaturas',
        'Relatórios básicos de check-ins',
        'Suporte via email'
      ],
      popular: false,
      buttonText: 'Começar Teste Grátis'
    },
    {
      id: 'intermediario',
      name: 'Intermediário',
      price: '59',
      period: '/mês',
      description: 'Ideal para oficinas em crescimento que buscam mais eficiência.',
      checkins: '300 check-ins/mês',
      features: [
        'Tudo do plano Básico',
        'Histórico completo por placa de veículo',
        'QR Code personalizado para check-in rápido',
        'Opção de envio de comprovante por WhatsApp',
        'Relatórios avançados e métricas de desempenho',
        'Suporte prioritário por chat e email'
      ],
      popular: true,
      buttonText: 'Começar Teste Grátis'
    },
    {
      id: 'pro',
      name: 'Pro',
      price: '99',
      period: '/mês',
      description: 'A solução completa para oficinas que querem o máximo de automação e personalização.',
      checkins: 'Check-ins ilimitados',
      features: [
        'Tudo do plano Intermediário',
        'Personalização com logo da sua oficina',
        'Notificações automáticas por WhatsApp (em breve)',
        'Múltiplos usuários com diferentes níveis de acesso',
        'Acesso API para integrações customizadas',
        'Suporte premium dedicado 24/7'
      ],
      popular: false,
      buttonText: 'Começar Teste Grátis'
    }
  ]);

  const handlePageDataChange = (e) => {
    const { name, value } = e.target;
    setPageData(prev => ({ ...prev, [name]: value }));
  };

  const handlePlanChange = (index, field, value) => {
    const newPlans = [...plans];
    if (field === 'features') {
      newPlans[index][field] = value.split('\n');
    } else if (field === 'popular') {
      newPlans[index][field] = value;
    }
    else {
      newPlans[index][field] = value;
    }
    setPlans(newPlans);
  };

  const addFeature = (planIndex) => {
    const newPlans = [...plans];
    newPlans[planIndex].features.push("");
    setPlans(newPlans);
  };

  const removeFeature = (planIndex, featureIndex) => {
    const newPlans = [...plans];
    newPlans[planIndex].features.splice(featureIndex, 1);
    setPlans(newPlans);
  };
  
  const handleFeatureChange = (planIndex, featureIndex, value) => {
    const newPlans = [...plans];
    newPlans[planIndex].features[featureIndex] = value;
    setPlans(newPlans);
  };


  const handleSave = async () => {
    setSaving(true);
    try {
      // Simulação de salvamento
      // await ContentPage.update('precos', { pageData, plans });
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Página de Preços salva com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar página de preços:', error);
      alert('Erro ao salvar. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Settings")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Configurações
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Editar Página de Preços</h1>
            <p className="text-gray-600 mt-1">Personalize os planos e informações da sua página de preços</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to={createPageUrl("Precos")} target="_blank">
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visualizar
            </Button>
          </Link>
          <Button 
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </Button>
        </div>
      </div>

      {/* Page Header Content */}
      <Card>
        <CardHeader>
          <CardTitle>Conteúdo Geral da Página</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="title">Título Principal</Label>
            <Input id="title" name="title" value={pageData.title} onChange={handlePageDataChange} className="mt-1" />
          </div>
          <div>
            <Label htmlFor="subtitle">Subtítulo</Label>
            <Textarea id="subtitle" name="subtitle" value={pageData.subtitle} onChange={handlePageDataChange} className="mt-1" rows={2}/>
          </div>
          <div>
            <Label htmlFor="ctaText">Texto da Chamada para Ação (Rodapé dos Planos)</Label>
            <Input id="ctaText" name="ctaText" value={pageData.ctaText} onChange={handlePageDataChange} className="mt-1" />
          </div>
           <div>
            <Label htmlFor="freeTrialDetails">Detalhes do Teste Grátis (abaixo do CTA)</Label>
            <Input id="freeTrialDetails" name="freeTrialDetails" value={pageData.freeTrialDetails} onChange={handlePageDataChange} className="mt-1" />
          </div>
        </CardContent>
      </Card>

      {/* Plans Editor */}
      <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6">
        {plans.map((plan, planIndex) => (
          <Card key={plan.id}>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                Plano: {plan.name}
                 <label className="flex items-center space-x-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={plan.popular} 
                    onChange={(e) => handlePlanChange(planIndex, 'popular', e.target.checked)}
                    className="form-checkbox h-5 w-5 text-blue-600"
                  />
                  <span className="text-sm font-medium">Popular?</span>
                </label>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor={`planName-${planIndex}`}>Nome do Plano</Label>
                <Input id={`planName-${planIndex}`} value={plan.name} onChange={(e) => handlePlanChange(planIndex, 'name', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label htmlFor={`planPrice-${planIndex}`}>Preço (R$)</Label>
                  <Input id={`planPrice-${planIndex}`} value={plan.price} onChange={(e) => handlePlanChange(planIndex, 'price', e.target.value)} />
                </div>
                 <div>
                  <Label htmlFor={`planPeriod-${planIndex}`}>Período</Label>
                  <Input id={`planPeriod-${planIndex}`} value={plan.period} onChange={(e) => handlePlanChange(planIndex, 'period', e.target.value)} placeholder="/mês"/>
                </div>
              </div>
              <div>
                <Label htmlFor={`planCheckins-${planIndex}`}>Limite de Check-ins</Label>
                <Input id={`planCheckins-${planIndex}`} value={plan.checkins} onChange={(e) => handlePlanChange(planIndex, 'checkins', e.target.value)} />
              </div>
              <div>
                <Label htmlFor={`planDescription-${planIndex}`}>Descrição Curta</Label>
                <Textarea id={`planDescription-${planIndex}`} value={plan.description} onChange={(e) => handlePlanChange(planIndex, 'description', e.target.value)} rows={2}/>
              </div>
              <div>
                <Label>Funcionalidades (uma por linha)</Label>
                {plan.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center gap-2 mt-1">
                    <Input 
                      value={feature} 
                      onChange={(e) => handleFeatureChange(planIndex, featureIndex, e.target.value)}
                      placeholder="Nova funcionalidade"
                    />
                    <Button variant="ghost" size="sm" onClick={() => removeFeature(planIndex, featureIndex)} className="text-red-500 hover:text-red-700">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
                <Button variant="outline" size="sm" onClick={() => addFeature(planIndex)} className="mt-2 flex items-center gap-1">
                  <PlusCircle className="w-3 h-3"/> Adicionar Funcionalidade
                </Button>
              </div>
              <div>
                <Label htmlFor={`planButtonText-${planIndex}`}>Texto do Botão</Label>
                <Input id={`planButtonText-${planIndex}`} value={plan.buttonText} onChange={(e) => handlePlanChange(planIndex, 'buttonText', e.target.value)} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}