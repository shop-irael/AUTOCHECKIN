
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge"; // Added Badge
import { ArrowLeft, Save, Eye, PlusCircle, Trash2, FileText, CalendarDays, UserCircle } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
// import ReactQuill from 'react-quill'; // Descomentar se react-quill for usado
// import 'react-quill/dist/quill.snow.css'; // Descomentar se react-quill for usado

export default function EditBlog() {
  const [saving, setSaving] = useState(false);
  const [pageTitle, setPageTitle] = useState("Blog AutoCheckin");
  const [pageSubtitle, setPageSubtitle] = useState("Dicas, novidades e informações úteis sobre o universo automotivo e gestão de oficinas.");
  const [posts, setPosts] = useState([
    {
      id: '1',
      title: "5 Dicas Essenciais para Manutenção Preventiva do seu Veículo",
      slug: "dicas-manutencao-preventiva",
      author: "Equipe AutoCheckin",
      date: "2024-07-15",
      excerpt: "Manter seu carro em dia é fundamental para segurança e economia. Confira nossas dicas...",
      content: "Conteúdo completo do artigo sobre manutenção preventiva aqui...",
      imageUrl: "https://images.unsplash.com/photo-1553521244-80a8d6098f38?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2FyJTIwbWFpbnRlbmFuY2V8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60",
      tags: ["Manutenção", "Dicas", "Segurança"]
    },
    {
      id: '2',
      title: "Como a Digitalização Pode Transformar Sua Oficina Mecânica",
      slug: "digitalizacao-oficina-mecanica",
      author: "João Silva, Especialista",
      date: "2024-07-20",
      excerpt: "A tecnologia não é mais futuro, é o presente. Veja como o AutoCheckin pode ajudar...",
      content: "Conteúdo completo do artigo sobre digitalização...",
      imageUrl: "https://images.unsplash.com/photo-1605152276541-658a59510201?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8b2ZmaWNlJTIwdGVjaG5vbG9neXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60",
      tags: ["Tecnologia", "Oficina", "Gestão"]
    }
  ]);
  const [editingPost, setEditingPost] = useState(null); // null ou o post a ser editado
  const [showPostForm, setShowPostForm] = useState(false);

  const handlePageInfoChange = (e) => {
    const { name, value } = e.target;
    if (name === "pageTitle") setPageTitle(value);
    if (name === "pageSubtitle") setPageSubtitle(value);
  };

  const handlePostChange = (field, value) => {
    setEditingPost(prev => ({ ...prev, [field]: value }));
  };
  
  const handleTagsChange = (value) => {
    setEditingPost(prev => ({ ...prev, tags: value.split(',').map(tag => tag.trim()).filter(tag => tag) }));
  };

  const openNewPostForm = () => {
    setEditingPost({
      id: '', title: '', slug: '', author: '', date: new Date().toISOString().split('T')[0], 
      excerpt: '', content: '', imageUrl: '', tags: []
    });
    setShowPostForm(true);
  };

  const openEditPostForm = (post) => {
    setEditingPost({...post, tags: Array.isArray(post.tags) ? post.tags : [] });
    setShowPostForm(true);
  };

  const handleSavePost = () => {
    if (!editingPost.title || !editingPost.slug) {
      alert("Título e Slug são obrigatórios para o post.");
      return;
    }
    if (editingPost.id) { // Editando post existente
      setPosts(posts.map(p => p.id === editingPost.id ? editingPost : p));
    } else { // Novo post
      setPosts([...posts, { ...editingPost, id: Date.now().toString() }]);
    }
    setShowPostForm(false);
    setEditingPost(null);
  };

  const handleDeletePost = (postId) => {
    if (window.confirm("Tem certeza que deseja excluir este post?")) {
      setPosts(posts.filter(p => p.id !== postId));
    }
  };
  
  const handleSaveAll = async () => {
    setSaving(true);
    try {
      // Simulação de salvamento
      // await ContentPage.update('blog', { pageTitle, pageSubtitle, posts });
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Blog salvo com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar blog:', error);
      alert('Erro ao salvar. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Settings")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Configurações
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Editar Blog</h1>
            <p className="text-gray-600 mt-1">Gerencie os posts e o conteúdo do seu blog</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to={createPageUrl("Blog")} target="_blank">
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visualizar Blog
            </Button>
          </Link>
          <Button 
            onClick={handleSaveAll}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Salvando...' : 'Salvar Blog'}
          </Button>
        </div>
      </div>

      {/* Page Info */}
      <Card>
        <CardHeader><CardTitle>Informações Gerais do Blog</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="pageTitle">Título do Blog</Label>
            <Input id="pageTitle" name="pageTitle" value={pageTitle} onChange={handlePageInfoChange} />
          </div>
          <div>
            <Label htmlFor="pageSubtitle">Subtítulo do Blog</Label>
            <Textarea id="pageSubtitle" name="pageSubtitle" value={pageSubtitle} onChange={handlePageInfoChange} rows={2}/>
          </div>
        </CardContent>
      </Card>

      {/* Posts List */}
      <Card>
        <CardHeader className="flex justify-between items-center">
          <CardTitle>Posts do Blog</CardTitle>
          <Button onClick={openNewPostForm} className="flex items-center gap-1">
            <PlusCircle className="w-4 h-4"/> Novo Post
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {posts.length === 0 && <p className="text-center text-gray-500 py-4">Nenhum post encontrado. Clique em "Novo Post" para começar.</p>}
          {posts.map(post => (
            <div key={post.id} className="p-4 border rounded-lg flex justify-between items-start hover:bg-gray-50">
              <div>
                <h3 className="font-semibold text-lg">{post.title}</h3>
                <p className="text-sm text-gray-600 flex items-center gap-2">
                  <UserCircle className="w-4 h-4"/> {post.author} 
                  <CalendarDays className="w-4 h-4 ml-2"/> {new Date(post.date).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}
                </p>
                <p className="text-sm text-gray-500 mt-1">{post.excerpt.substring(0,100)}...</p>
                {post.tags && post.tags.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {post.tags.map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                  </div>
                )}
              </div>
              <div className="flex flex-col sm:flex-row gap-2 mt-2 sm:mt-0">
                <Button variant="outline" size="sm" onClick={() => openEditPostForm(post)}>Editar</Button>
                <Button variant="ghost" size="sm" onClick={() => handleDeletePost(post.id)} className="text-red-500 hover:text-red-700">
                  <Trash2 className="w-4 h-4"/>
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Post Form Modal/Dialog (simplified here, can be a separate component or ShadCN Dialog) */}
      {showPostForm && editingPost && (
        <Card className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold">{editingPost.id ? 'Editar Post' : 'Novo Post'}</h2>
              <Button variant="ghost" size="sm" onClick={() => setShowPostForm(false)}>Fechar</Button>
            </div>
            <div className="space-y-4">
              <div>
                <Label htmlFor="postTitle">Título do Post</Label>
                <Input id="postTitle" value={editingPost.title} onChange={(e) => handlePostChange('title', e.target.value)} />
              </div>
              <div>
                <Label htmlFor="postSlug">Slug (URL amigável, ex: meu-novo-post)</Label>
                <Input id="postSlug" value={editingPost.slug} onChange={(e) => handlePostChange('slug', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="postAuthor">Autor</Label>
                  <Input id="postAuthor" value={editingPost.author} onChange={(e) => handlePostChange('author', e.target.value)} />
                </div>
                <div>
                  <Label htmlFor="postDate">Data de Publicação</Label>
                  <Input type="date" id="postDate" value={editingPost.date} onChange={(e) => handlePostChange('date', e.target.value)} />
                </div>
              </div>
              <div>
                <Label htmlFor="postImageUrl">URL da Imagem de Capa</Label>
                <Input id="postImageUrl" value={editingPost.imageUrl} onChange={(e) => handlePostChange('imageUrl', e.target.value)} placeholder="https://exemplo.com/imagem.jpg"/>
              </div>
              <div>
                <Label htmlFor="postExcerpt">Resumo (chamada para o post)</Label>
                <Textarea id="postExcerpt" value={editingPost.excerpt} onChange={(e) => handlePostChange('excerpt', e.target.value)} rows={3}/>
              </div>
              <div>
                <Label htmlFor="postContent">Conteúdo Completo do Post</Label>
                {/* 
                  Idealmente, usar um editor de Rich Text aqui, como ReactQuill.
                  Por simplicidade, usando Textarea.
                */}
                <Textarea id="postContent" value={editingPost.content} onChange={(e) => handlePostChange('content', e.target.value)} rows={10} 
                  placeholder="Escreva o conteúdo do seu post aqui. Você pode usar Markdown básico se a página de visualização do blog o suportar."/>
                {/* 
                <ReactQuill 
                  theme="snow" 
                  value={editingPost.content} 
                  onChange={(content) => handlePostChange('content', content)}
                  className="bg-white"
                /> 
                */}
              </div>
               <div>
                <Label htmlFor="postTags">Tags (separadas por vírgula)</Label>
                <Input id="postTags" value={editingPost.tags.join(', ')} onChange={(e) => handleTagsChange(e.target.value)} placeholder="dica, manutenção, novidade"/>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowPostForm(false)}>Cancelar</Button>
                <Button onClick={handleSavePost} className="bg-blue-600 hover:bg-blue-700">Salvar Post</Button>
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
