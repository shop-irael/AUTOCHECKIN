import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Users, Target, Lightbulb } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function Sobre() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-purple-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Home
            </Button>
          </Link>
        </div>
        <div className="bg-white p-8 sm:p-12 shadow-xl rounded-lg">
          <header className="text-center mb-10">
             <Users className="w-16 h-16 text-purple-600 mx-auto mb-4" />
            <h1 className="text-4xl font-bold text-gray-900 mb-3">Sobre o AutoCheckin</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Nossa paixão é simplificar a gestão de oficinas automotivas através da tecnologia.
            </p>
          </header>
          
          <section className="mb-10">
            <h2 className="text-2xl font-semibold text-purple-700 mb-4 flex items-center gap-2">
                <Lightbulb className="w-7 h-7" /> Nossa História
            </h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              O AutoCheckin nasceu da observação das dificuldades enfrentadas por donos de oficinas no dia a dia: papelada excessiva, processos manuais demorados, falta de histórico organizado dos veículos e a busca constante por profissionalizar o atendimento. Percebemos que a tecnologia poderia ser uma grande aliada para superar esses desafios.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Reunimos uma equipe de desenvolvedores, designers e especialistas do setor automotivo com um objetivo comum: criar uma solução SaaS (Software como Serviço) intuitiva, poderosa e acessível, que realmente fizesse a diferença na rotina das oficinas, independentemente do seu tamanho.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-semibold text-purple-700 mb-4 flex items-center gap-2">
                <Target className="w-7 h-7" /> Nossa Missão e Visão
            </h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              <strong>Missão:</strong> Empoderar oficinas automotivas com ferramentas digitais inovadoras que otimizem a gestão, melhorem a experiência do cliente e impulsionem o crescimento do negócio.
            </p>
            <p className="text-gray-700 leading-relaxed">
              <strong>Visão:</strong> Ser a plataforma líder em soluções de check-in digital e gestão para oficinas na América Latina, reconhecida pela excelência, inovação e impacto positivo no setor.
            </p>
          </section>
          
          <section className="mb-10">
            <h2 className="text-2xl font-semibold text-purple-700 mb-4">Nossos Valores</h2>
            <ul className="list-disc list-inside text-gray-700 space-y-2 pl-4">
              <li><strong>Foco no Cliente:</strong> Suas necessidades são nossa prioridade.</li>
              <li><strong>Inovação Contínua:</strong> Buscamos sempre as melhores soluções.</li>
              <li><strong>Simplicidade:</strong> Tecnologia deve ser fácil de usar.</li>
              <li><strong>Transparência:</strong> Relações honestas e claras.</li>
              <li><strong>Paixão pelo que fazemos:</strong> Amamos ajudar oficinas a prosperar.</li>
            </ul>
          </section>
          
          <div className="mt-12 text-center border-t pt-8">
            <p className="text-gray-600 text-lg">
              Junte-se a nós nesta jornada de transformação digital!
            </p>
            <Link to={createPageUrl("Home")} state={{ scrollTo: 'precos' }}>
                <Button size="lg" className="mt-4 bg-purple-600 hover:bg-purple-700">
                    Conheça Nossos Planos
                </Button>
            </Link>
          </div>
           <p className="mt-6 text-sm text-gray-500">
            (Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)
          </p>
        </div>
      </div>
    </div>
  );
}