

import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import {
  Car,
  LayoutDashboard,
  ClipboardList,
  Settings,
  FileText,
  Users,
  BarChart3,
  LogOut,
  Building2,
  Calendar // Added Calendar icon import
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Check-ins",
    url: createPageUrl("CheckinList"),
    icon: ClipboardList,
  },
  {
    title: "Histórico de Veículos",
    url: createPageUrl("VehicleHistory"),
    icon: Car,
  },
  {
    title: "Relatórios",
    url: createPageUrl("Reports"),
    icon: BarChart3,
  },
  {
    title: "Solicitações de Demo", // Added Demo Requests menu item
    url: createPageUrl("DemoRequests"),
    icon: Calendar,
  },
  {
    title: "Serviços",
    url: createPageUrl("ServiceManagement"),
    icon: Settings,
  },
  {
    title: "Configurações",
    url: createPageUrl("Settings"),
    icon: Building2,
  },
];

// Lista de páginas que NÃO devem usar o layout do painel administrativo E não precisam de autenticação
const publicPages = [
  "Home",
  "CheckinForm",
  "Funcionalidades",
  "Precos",
  "Demo",
  "CentralAjuda",
  "WhatsApp",
  "Email",
  "Sobre",
  "Blog",
  "Contato",
  "PostLogin",
  "ClientDashboard",
  "PaymentSuccess",
  "PaymentCancel"
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();

  // For public pages, just render children without any auth checks
  if (publicPages.includes(currentPageName)) {
    return <>{children}</>;
  }

  // For admin pages, we can keep the existing auth logic in the admin layout
  // The sidebar and admin layout will handle any auth requirements
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gray-50">
        <Sidebar className="border-r border-gray-200">
          <SidebarHeader className="border-b border-gray-200 p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
                <Car className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900">AutoCheckin</h2>
                <p className="text-xs text-gray-500">Painel Administrativo</p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-2">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider px-2 py-2">
                Menu Principal
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`hover:bg-blue-50 hover:text-blue-700 transition-colors duration-200 rounded-lg mb-1 ${
                          location.pathname === item.url ? 'bg-blue-50 text-blue-700' : ''
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-3 py-2">
                          <item.icon className="w-4 h-4" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-medium text-gray-500 uppercase tracking-wider px-2 py-2">
                Estatísticas Rápidas
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <div className="px-3 py-2 space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <FileText className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">Check-ins Hoje</span>
                    <span className="ml-auto font-semibold text-blue-600">N/A</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">Pendentes</span>
                    <span className="ml-auto font-semibold text-orange-600">N/A</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Car className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">Em Serviço</span>
                    <span className="ml-auto font-semibold text-green-600">N/A</span>
                  </div>
                </div>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-gray-200 p-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-medium text-sm">OC</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 text-sm truncate">Oficina (Nome)</p>
                <p className="text-xs text-gray-500 truncate">Plano (Tipo)</p>
              </div>
              <button
                onClick={async () => {
                  try {
                    await User.logout();
                    window.location.href = createPageUrl("Home"); // Corrigido para forçar o redirecionamento
                  } catch (error) {
                    console.error("Erro no logout:", error);
                    // Adicionar um alerta para o usuário em caso de erro, se necessário
                    alert("Erro ao tentar fazer logout. Tente novamente.");
                  }
                }}
                className="p-1 hover:bg-gray-100 rounded transition-colors"
                title="Sair"
              >
                <LogOut className="w-4 h-4 text-gray-400" />
              </button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white border-b border-gray-200 px-6 py-4 md:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-gray-100 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-semibold">
                {navigationItems.find(item => location.pathname.startsWith(item.url))?.title || currentPageName || "AutoCheckin"}
              </h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

