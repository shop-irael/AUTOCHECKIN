
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import SignatureCanvas from '../components/SignatureCanvas';
import { Servico, Checkin, User } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Car, User as UserIcon, Phone, Wrench, Image as ImageIcon, MessageSquare, CheckCircle, AlertCircle, Loader2, Send, Camera, Upload, DollarSign } from 'lucide-react';

const MAX_PHOTOS = 10;
const MIN_PHOTOS = 3;

export default function CheckinForm() {
  const { companyId: companyIdFromParams } = useParams();
  const navigate = useNavigate();

  // For now, using a default companyId if not provided by params.
  // In a real scenario, this page shouldn't be accessible without a valid companyId.
  const companyId = companyIdFromParams || "oficina-do-carlos-demo"; 
  const workshopName = "Oficina do Carlos (Exemplo)"; // This would be fetched based on companyId

  const [formData, setFormData] = useState({
    clientName: '',
    clientPhone: '',
    vehiclePlate: '',
    vehicleModel: '',
    vehicleYear: '',
    vehicleColor: '',
    selectedServiceIds: [],
    observations: '',
  });
  const [photos, setPhotos] = useState([]);
  const [photoFiles, setPhotoFiles] = useState([]); // To store File objects
  const [signatureDataUrl, setSignatureDataUrl] = useState(null);
  const [availableServices, setAvailableServices] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [isCameraMode, setIsCameraMode] = useState(false);
  const [stream, setStream] = useState(null);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        // Later, filter services by companyId: Servico.filter({ companyId })
        const services = await Servico.list(); 
        setAvailableServices(services);
      } catch (err) {
        console.error("Erro ao buscar serviços:", err);
        setError("Não foi possível carregar os serviços disponíveis. Tente novamente mais tarde.");
      }
    };
    fetchServices();
  }, [companyId]);

  // Calcula o preço total dos serviços selecionados
  const totalPrice = useMemo(() => {
    return formData.selectedServiceIds.reduce((total, serviceId) => {
      const service = availableServices.find(s => s.id === serviceId);
      return total + (service?.price || 0);
    }, 0);
  }, [formData.selectedServiceIds, availableServices]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleServiceToggle = (serviceId) => {
    setFormData(prev => {
      const newSelectedServiceIds = prev.selectedServiceIds.includes(serviceId)
        ? prev.selectedServiceIds.filter(id => id !== serviceId)
        : [...prev.selectedServiceIds, serviceId];
      return { ...prev, selectedServiceIds: newSelectedServiceIds };
    });
  };

  const handlePhotoUpload = (e) => {
    const files = Array.from(e.target.files);
    if (photos.length + files.length > MAX_PHOTOS) {
      alert('Você pode enviar no máximo ' + MAX_PHOTOS + ' fotos.');
      return;
    }
    const newPhotoFiles = [...photoFiles, ...files];
    setPhotoFiles(newPhotoFiles);

    const newPhotoPreviews = files.map(file => URL.createObjectURL(file));
    setPhotos(prev => [...prev, ...newPhotoPreviews]);
  };

  const startCamera = async () => {
    if (photos.length >= MAX_PHOTOS) {
      alert('Você já atingiu o máximo de ' + MAX_PHOTOS + ' fotos.');
      return;
    }
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment', // Usar câmera traseira por padrão
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      setStream(mediaStream);
      setIsCameraMode(true);
    } catch (err) {
      console.error('Erro ao acessar câmera:', err);
      setError('Não foi possível acessar a câmera. Verifique as permissões.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsCameraMode(false);
  };

  const capturePhoto = () => {
    if (!stream) return;

    const video = document.getElementById('camera-video');
    if (!video) {
      console.error("Video element not found.");
      return;
    }

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');

    // Define dimensões do canvas baseado no vídeo
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Desenha o frame atual do vídeo no canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Converte para blob e depois para file
    canvas.toBlob((blob) => {
      if (!blob) {
        console.error("Failed to capture blob from canvas.");
        return;
      }
      if (photos.length >= MAX_PHOTOS) {
        alert('Você já atingiu o máximo de ' + MAX_PHOTOS + ' fotos.');
        return;
      }

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const file = new File([blob], `foto-veiculo-${timestamp}.jpg`, { type: 'image/jpeg' });
      
      const newPhotoFiles = [...photoFiles, file];
      setPhotoFiles(newPhotoFiles);

      const photoUrl = URL.createObjectURL(blob);
      setPhotos(prev => [...prev, photoUrl]);

      // Parar a câmera após capturar
      stopCamera();
    }, 'image/jpeg', 0.8);
  };

  const removePhoto = (index) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
    setPhotoFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSignatureSave = (dataUrl) => {
    setSignatureDataUrl(dataUrl);
  };

  const dataURLtoFile = (dataurl, filename) => {
    let arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, {type:mime});
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    if (photoFiles.length < MIN_PHOTOS) {
      setError('Por favor, envie pelo menos ' + MIN_PHOTOS + ' fotos do veículo.');
      return;
    }
    if (!signatureDataUrl) {
      setError("Assinatura digital é obrigatória.");
      return;
    }
    if (formData.selectedServiceIds.length === 0) {
      setError("Selecione ao menos um serviço desejado.");
      return;
    }

    setIsLoading(true);
    try {
      // Checa se o usuário está logado para associar o ID
      let currentUserId = null;
      try {
        const user = await User.me();
        currentUserId = user.id;
      } catch (userError) {
        // Usuário não está logado, o que é permitido.
        console.log("Check-in sendo feito por um visitante não logado.");
      }

      // 1. Upload photos
      const uploadedPhotoUrls = [];
      for (const file of photoFiles) {
        const { file_url } = await UploadFile({ file });
        uploadedPhotoUrls.push(file_url);
      }

      // 2. Upload signature
      const signatureFile = dataURLtoFile(signatureDataUrl, `signature-${Date.now()}.png`);
      const { file_url: signature_file_url } = await UploadFile({ file: signatureFile });
      
      // 3. Prepare Checkin data
      const checkinData = {
        ...formData,
        companyId, // from context or params
        clientId: currentUserId, // Adiciona o ID do cliente se ele estiver logado
        photoUrls: uploadedPhotoUrls,
        signatureUrl: signature_file_url,
        vehicleYear: parseInt(formData.vehicleYear, 10),
        status: "pending_confirmation"
      };

      await Checkin.create(checkinData);
      setSuccess(true);
      // Optionally navigate away or clear form:
      // navigate(`/checkin-success/${newCheckin.id}`); 
    } catch (err) {
      console.error("Erro ao criar check-in:", err);
      setError('Erro ao submeter check-in: ' + (err.message || 'Por favor, verifique os dados e tente novamente.'));
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="bg-green-500 text-white p-6 rounded-t-lg">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-10 h-10" />
              <CardTitle className="text-2xl">Check-in Realizado com Sucesso!</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-6 text-center">
            <p className="text-gray-700 mb-4">
              Obrigado, {formData.clientName}! Seu check-in para o veículo de placa {formData.vehiclePlate} foi enviado para {workshopName}.
            </p>
            <p className="text-gray-600 text-sm">
              Em breve, a oficina entrará em contato para confirmar os detalhes.
            </p>
            <Button onClick={() => window.location.reload()} className="mt-6 w-full bg-green-600 hover:bg-green-700">
              Realizar Novo Check-in
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 py-4 sm:py-8 px-2 sm:px-4">
      <Card className="max-w-2xl mx-auto shadow-2xl">
        <CardHeader className="bg-blue-600 text-white p-4 sm:p-6 rounded-t-lg">
          <div className="flex items-center space-x-2 sm:space-x-3">
            <Car className="w-6 h-6 sm:w-8 sm:h-8" />
            <div>
              <CardTitle className="text-lg sm:text-2xl">Novo Check-in Digital</CardTitle>
              <p className="text-blue-100 text-xs sm:text-sm">{workshopName}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4 sm:p-6 space-y-6 sm:space-y-8">
          <form onSubmit={handleSubmit} className="space-y-6 sm:space-y-8">
            {/* Client Info */}
            <div className="space-y-3 sm:space-y-4 border-b pb-4 sm:pb-6">
              <h3 className="text-base sm:text-lg font-semibold text-gray-700 flex items-center">
                <UserIcon className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-blue-500"/>
                Dados do Cliente
              </h3>
              <div className="space-y-3 sm:space-y-4">
                <div>
                  <Label htmlFor="clientName" className="text-sm">Nome Completo</Label>
                  <Input 
                    id="clientName" 
                    name="clientName" 
                    value={formData.clientName} 
                    onChange={handleInputChange} 
                    required 
                    className="mt-1 text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="clientPhone" className="text-sm">Telefone / WhatsApp</Label>
                  <Input 
                    id="clientPhone" 
                    name="clientPhone" 
                    type="tel" 
                    value={formData.clientPhone} 
                    onChange={handleInputChange} 
                    required 
                    className="mt-1 text-base"
                  />
                </div>
              </div>
            </div>

            {/* Vehicle Info */}
            <div className="space-y-3 sm:space-y-4 border-b pb-4 sm:pb-6">
              <h3 className="text-base sm:text-lg font-semibold text-gray-700 flex items-center">
                <Car className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-blue-500"/>
                Dados do Veículo
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <Label htmlFor="vehiclePlate" className="text-sm">Placa</Label>
                  <Input 
                    id="vehiclePlate" 
                    name="vehiclePlate" 
                    value={formData.vehiclePlate} 
                    onChange={handleInputChange} 
                    required 
                    className="mt-1 text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="vehicleModel" className="text-sm">Modelo e Marca</Label>
                  <Input 
                    id="vehicleModel" 
                    name="vehicleModel" 
                    value={formData.vehicleModel} 
                    onChange={handleInputChange} 
                    required 
                    className="mt-1 text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="vehicleYear" className="text-sm">Ano</Label>
                  <Input 
                    id="vehicleYear" 
                    name="vehicleYear" 
                    type="number" 
                    value={formData.vehicleYear} 
                    onChange={handleInputChange} 
                    required 
                    className="mt-1 text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="vehicleColor" className="text-sm">Cor</Label>
                  <Input 
                    id="vehicleColor" 
                    name="vehicleColor" 
                    value={formData.vehicleColor} 
                    onChange={handleInputChange} 
                    required 
                    className="mt-1 text-base"
                  />
                </div>
              </div>
            </div>
            
            {/* Services - OTIMIZADO PARA MOBILE */}
            <div className="space-y-4 border-b pb-6">
              <h3 className="text-base sm:text-lg font-semibold text-gray-700 flex items-center">
                <Wrench className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-blue-500"/>
                Serviços Desejados
              </h3>
              {availableServices.length > 0 ? (
                <>
                  {/* MOBILE: Lista vertical, DESKTOP: Grid */}
                  <div className="space-y-3 sm:grid sm:grid-cols-2 sm:gap-4 sm:space-y-0 max-h-60 overflow-y-auto p-2 border rounded-md">
                    {availableServices.map(service => (
                      <div key={service.id} className="flex items-start space-x-3 p-3 sm:p-2 hover:bg-gray-50 rounded border sm:border-0">
                        <Checkbox
                          id={`service-${service.id}`}
                          checked={formData.selectedServiceIds.includes(service.id)}
                          onCheckedChange={() => handleServiceToggle(service.id)}
                          className="mt-1 flex-shrink-0"
                        />
                        <Label htmlFor={`service-${service.id}`} className="font-normal cursor-pointer flex-grow text-sm sm:text-base">
                          <div className="font-medium text-gray-900">{service.name}</div>
                          {service.description && (
                            <p className="text-xs sm:text-sm text-gray-500 mt-1">{service.description}</p>
                          )}
                          {service.price > 0 && (
                            <div className="flex items-center text-sm font-semibold text-blue-600 mt-2">
                               <DollarSign className="w-3 h-3 mr-1" />
                               {service.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </div>
                          )}
                        </Label>
                      </div>
                    ))}
                  </div>

                  {/* TOTAL E PAGAMENTO - OTIMIZADO PARA MOBILE */}
                  {totalPrice > 0 && (
                    <div className="mt-4 p-4 bg-blue-50 border border-blue-100 rounded-lg space-y-3">
                       {/* Total - Mobile responsivo */}
                       <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-1 sm:space-y-0">
                        <span className="text-base sm:text-lg font-semibold text-gray-800">Total Estimado:</span>
                        <span className="text-xl sm:text-2xl font-bold text-blue-700">
                          {totalPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </span>
                      </div>
                      
                      {/* Formas de Pagamento - Mobile responsivo */}
                      <div className="pt-2 border-t border-blue-200">
                        <p className="text-xs sm:text-sm text-gray-700 text-center sm:text-right">
                          <strong className="text-gray-800">💳 Formas de Pagamento:</strong>
                        </p>
                        <p className="text-xs sm:text-sm text-gray-600 text-center sm:text-right mt-1">
                          <span className="inline-block mr-2">📱 <strong>Pix</strong></span>
                          <span className="inline-block mr-2">💵 <strong>Dinheiro</strong></span>
                          <span className="inline-block">💳 <strong>Cartão em até 3x sem juros</strong></span>
                        </p>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-gray-500 text-center py-4">Carregando serviços...</p>
              )}
            </div>

            {/* Photos */}
            <div className="space-y-4 border-b pb-6">
              <h3 className="text-base sm:text-lg font-semibold text-gray-700 flex items-center">
                <ImageIcon className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-blue-500"/>
                Fotos do Veículo (mínimo {MIN_PHOTOS}, máximo {MAX_PHOTOS})
              </h3>
              
              {/* Câmera */}
              {isCameraMode && (
                <div className="space-y-4">
                  <video 
                    id="camera-video" 
                    autoPlay 
                    playsInline
                    ref={(video) => {
                      if (video && stream) {
                        video.srcObject = stream;
                      }
                    }}
                    className="w-full max-w-md mx-auto rounded-lg border"
                  />
                  <div className="flex justify-center gap-2">
                    <Button type="button" onClick={capturePhoto} className="bg-green-600 hover:bg-green-700">
                      <Camera className="w-4 h-4 mr-2" />
                      Capturar Foto
                    </Button>
                    <Button type="button" onClick={stopCamera} variant="outline">
                      Cancelar
                    </Button>
                  </div>
                </div>
              )}

              {/* Botões de ação */}
              {!isCameraMode && (
                <div className="flex gap-2 flex-wrap">
                  <Button type="button" onClick={startCamera} variant="outline" className="flex items-center gap-2">
                    <Camera className="w-4 h-4" />
                    Tirar Foto
                  </Button>
                  <Label htmlFor="photos" className="cursor-pointer">
                    <Button type="button" variant="outline" className="flex items-center gap-2" asChild>
                      <span>
                        <Upload className="w-4 h-4" />
                        Escolher Arquivos
                      </span>
                    </Button>
                  </Label>
                  <Input 
                    id="photos" 
                    type="file" 
                    multiple 
                    accept="image/*" 
                    onChange={handlePhotoUpload} 
                    className="hidden"
                  />
                </div>
              )}

              {/* Preview das fotos */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 mt-2">
                {photos.map((photoUrl, index) => (
                  <div key={index} className="relative group">
                    <img src={photoUrl} alt={`Veículo ${index + 1}`} className="w-full h-24 object-cover rounded-md border"/>
                    <Button 
                      type="button" 
                      size="sm" 
                      variant="destructive" 
                      onClick={() => removePhoto(index)} 
                      className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity p-1 h-6 w-6"
                    >
                      X
                    </Button>
                  </div>
                ))}
              </div>
              {photos.length > 0 && (
                <p className="text-sm text-gray-600">{photos.length} foto(s) selecionada(s).</p>
              )}
            </div>

            {/* Observations */}
            <div className="space-y-4 border-b pb-6">
              <h3 className="text-base sm:text-lg font-semibold text-gray-700 flex items-center">
                <MessageSquare className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-blue-500"/>
                Observações Adicionais
              </h3>
              <Textarea 
                id="observations" 
                name="observations" 
                value={formData.observations} 
                onChange={handleInputChange} 
                placeholder="Algum detalhe importante sobre o veículo ou serviço?" 
                className="mt-1"
              />
            </div>

            {/* Signature */}
            <div className="space-y-4">
              <h3 className="text-base sm:text-lg font-semibold text-gray-700">Assinatura Digital do Cliente</h3>
              <SignatureCanvas onSave={handleSignatureSave} width={550} height={200} signature={signatureDataUrl} />
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <CardFooter className="p-0 pt-4 sm:pt-6">
              <Button 
                type="submit" 
                disabled={isLoading} 
                className="w-full bg-green-600 hover:bg-green-700 text-base sm:text-lg py-3 sm:py-4"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 h-4 sm:h-5 sm:w-5 animate-spin" /> 
                    Processando...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 h-4 sm:h-5 sm:w-5" /> 
                    Enviar Check-in
                  </>
                )}
              </Button>
            </CardFooter>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
