
import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, CheckCircle, Star } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User } from '@/api/entities';

export default function Precos() {
  const navigate = useNavigate();

  const plans = [
    {
      id: 'basico',
      name: 'Básico',
      price: 'R$ 29',
      period: '/mês',
      description: 'Perfeito para oficinas pequenas ou em início de digitalização.',
      checkins: 'Até 100 check-ins/mês',
      features: [
        'Formulário de check-in digital',
        'Upload de até 5 fotos por veículo',
        'Assinatura digital do cliente',
        'Histórico básico de veículos',
        'Relatórios simples de check-ins',
        'Suporte por email'
      ],
      popular: false,
      bgColor: 'bg-gray-50',
      buttonClass: 'bg-gray-200 hover:bg-gray-300 text-gray-800'
    },
    {
      id: 'intermediario', 
      name: 'Intermediário',
      price: 'R$ 59',
      period: '/mês',
      description: 'Ideal para oficinas em crescimento que buscam mais controle e profissionalismo.',
      checkins: 'Até 300 check-ins/mês',
      features: [
        'Tudo do plano Básico, mais:',
        'Upload de até 10 fotos por veículo',
        'QR Code personalizado para check-in rápido',
        'Envio de comprovante por WhatsApp (manual)',
        'Histórico completo por placa',
        'Relatórios avançados (serviços, clientes)',
        'Suporte prioritário por email e chat'
      ],
      popular: true,
      bgColor: 'bg-blue-50',
      buttonClass: 'bg-blue-600 hover:bg-blue-700 text-white'
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 'R$ 99', 
      period: '/mês',
      description: 'Para oficinas que querem o máximo de automação e personalização.',
      checkins: 'Check-ins Ilimitados',
      features: [
        'Tudo do plano Intermediário, mais:',
        'Upload de fotos ilimitado por veículo',
        'Logo personalizado no formulário e QR Code',
        'Notificações automáticas por WhatsApp (status do serviço)',
        'Múltiplos usuários para equipe da oficina',
        'API para integrações com outros sistemas',
        'Suporte VIP 24/7 por telefone e WhatsApp'
      ],
      popular: false,
      bgColor: 'bg-purple-50',
      buttonClass: 'bg-purple-600 hover:bg-purple-700 text-white'
    }
  ];

  const handleStartTrial = (planId) => {
    const callbackUrl = `${window.location.origin}${createPageUrl('Settings')}?upgradeToPlan=${planId}`;
    User.loginWithRedirect(callbackUrl);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Home
            </Button>
          </Link>
        </div>
        
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Nossos Planos e Preços</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Escolha o plano perfeito para digitalizar sua oficina e impressionar seus clientes. Sem taxas ocultas, cancele quando quiser.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 items-stretch">
          {plans.map((plan) => (
            <Card key={plan.id} className={`relative flex flex-col border-2 ${plan.popular ? 'border-blue-500 shadow-2xl scale-105' : 'border-gray-200'} ${plan.bgColor}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-600 text-white px-4 py-1 text-sm">
                    <Star className="w-4 h-4 mr-1 fill-current" /> Mais Popular
                  </Badge>
                </div>
              )}
              <CardHeader className="text-center pt-10">
                <CardTitle className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</CardTitle>
                <p className="text-gray-600 text-sm h-12">{plan.description}</p>
                 <div className="my-4">
                    <span className="text-5xl font-bold text-gray-900">{plan.price}</span>
                    <span className="text-gray-600 ml-1">{plan.period}</span>
                  </div>
                  <p className="text-sm text-gray-500 font-semibold">{plan.checkins}</p>
              </CardHeader>
              <CardContent className="flex-grow p-8 space-y-4">
                <ul className="space-y-3 text-sm text-gray-700">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <div className="p-8 pt-0">
                 <Button 
                    className={`w-full text-lg py-3 ${plan.buttonClass}`}
                    onClick={() => handleStartTrial(plan.id)}
                  >
                    Começar Teste Grátis de 7 Dias
                  </Button>
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center mt-16 p-8 bg-white rounded-lg shadow-lg">
          <h3 className="text-2xl font-semibold text-gray-900 mb-3">Dúvidas sobre qual plano escolher?</h3>
          <p className="text-gray-600 mb-6">
            Nossa equipe está pronta para ajudar você a encontrar a solução ideal para sua oficina. Entre em contato conosco!
          </p>
          <Link to={createPageUrl("Contato")}>
            <Button size="lg" variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
              Falar com um Especialista
            </Button>
          </Link>
        </div>
        <p className="mt-6 text-center text-sm text-gray-500">
          (Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)
        </p>
      </div>
    </div>
  );
}
