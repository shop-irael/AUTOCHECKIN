
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Servico } from '@/api/entities';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Settings, 
  DollarSign,
  Clock,
  Search,
  Save,
  X
} from 'lucide-react';

export default function ServiceManagement() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingService, setEditingService] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    price: '',
    duration_minutes: 60 // Manter em minutos para salvar no DB
  });
  // Novos estados para o formulário de duração
  const [durationValue, setDurationValue] = useState(60);
  const [durationUnit, setDurationUnit] = useState('minutes');

  const companyId = "oficina-do-carlos-demo"; // Em produção, viria do contexto

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const servicesData = await Servico.list();
      // Filtrar por empresa em produção: Servico.filter({ companyId })
      setServices(servicesData.filter(s => s.companyId === companyId));
    } catch (error) {
      console.error('Erro ao carregar serviços:', error);
    } finally {
      setLoading(false);
    }
  };

  // Funções helper para conversão de tempo
  const convertMinutesToBestUnit = (minutes) => {
    if (minutes === null || minutes === undefined || minutes === '') return { value: '', unit: 'minutes' };
    const numMinutes = Number(minutes);
    if (isNaN(numMinutes)) return { value: '', unit: 'minutes' };

    if (numMinutes >= 1440 && numMinutes % 1440 === 0) {
      return { value: numMinutes / 1440, unit: 'days' };
    }
    if (numMinutes >= 60 && numMinutes % 60 === 0) {
      return { value: numMinutes / 60, unit: 'hours' };
    }
    return { value: numMinutes, unit: 'minutes' };
  };

  const getUnitLabel = (unit, value) => {
    const numericValue = Number(value);
    const singular = numericValue === 1;
    switch (unit) {
      case 'minutes': return singular ? 'minuto' : 'minutos';
      case 'hours': return singular ? 'hora' : 'horas';
      case 'days': return singular ? 'dia' : 'dias';
      default: return '';
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ 
      ...prev, 
      [name]: name === 'price' ? parseFloat(value) || '' : value 
    }));
  };

  const handleDurationChange = (value, unit) => {
    const numericValue = parseFloat(value) || 0;
    setDurationValue(numericValue);
    setDurationUnit(unit);

    let minutes = 0;
    if (unit === 'hours') {
      minutes = numericValue * 60;
    } else if (unit === 'days') {
      minutes = numericValue * 24 * 60;
    } else {
      minutes = numericValue;
    }
    setFormData(prev => ({ ...prev, duration_minutes: minutes }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const serviceData = {
        ...formData,
        companyId,
        price: formData.price ? parseFloat(formData.price) : undefined,
        duration_minutes: formData.duration_minutes ? parseInt(formData.duration_minutes) : undefined
      };

      if (editingService) {
        await Servico.update(editingService.id, serviceData);
      } else {
        await Servico.create(serviceData);
      }

      loadServices();
      resetForm();
    } catch (error) {
      console.error('Erro ao salvar serviço:', error);
    }
  };

  const handleEdit = (service) => {
    setEditingService(service);
    
    const { value, unit } = convertMinutesToBestUnit(service.duration_minutes);
    setDurationValue(value || '');
    setDurationUnit(unit);

    setFormData({
      name: service.name || '',
      description: service.description || '',
      category: service.category || '',
      price: service.price || '',
      duration_minutes: service.duration_minutes || 0
    });
    setShowForm(true);
  };

  const handleDelete = async (serviceId) => {
    if (window.confirm('Tem certeza que deseja excluir este serviço?')) {
      try {
        await Servico.delete(serviceId);
        loadServices();
      } catch (error) {
        console.error('Erro ao excluir serviço:', error);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      category: '',
      price: '',
      duration_minutes: 60
    });
    setDurationValue(60);
    setDurationUnit('minutes');
    setEditingService(null);
    setShowForm(false);
  };

  const filteredServices = services.filter(service =>
    service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    service.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const categories = [...new Set(services.map(s => s.category).filter(Boolean))];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gerenciar Serviços</h1>
          <p className="text-gray-600 mt-1">Configure os serviços oferecidos pela sua oficina</p>
        </div>
        <Button 
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Novo Serviço
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar serviços por nome ou categoria..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Categories Overview */}
      {categories.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Categorias</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {categories.map((category, index) => (
                <Badge key={index} variant="outline" className="px-3 py-1">
                  {category} ({services.filter(s => s.category === category).length})
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Services List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Serviços ({filteredServices.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse flex space-x-4 p-4 border rounded-lg">
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                  </div>
                  <div className="h-4 bg-gray-200 rounded w-20"></div>
                </div>
              ))}
            </div>
          ) : filteredServices.length === 0 ? (
            <div className="text-center py-8">
              <Settings className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">
                {searchTerm ? 'Nenhum serviço encontrado' : 'Nenhum serviço cadastrado ainda'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredServices.map((service) => (
                <div key={service.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-gray-900">{service.name}</h3>
                        {service.category && (
                          <Badge variant="outline">{service.category}</Badge>
                        )}
                      </div>
                      
                      {service.description && (
                        <p className="text-gray-600 text-sm mb-2">{service.description}</p>
                      )}
                      
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        {service.price != null && (
                          <span className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3" />
                            R$ {Number(service.price).toFixed(2)}
                          </span>
                        )}
                        {(service.duration_minutes !== null && service.duration_minutes !== undefined) && (
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                             {(() => {
                                const { value, unit } = convertMinutesToBestUnit(service.duration_minutes);
                                if (value === '' || value === 0) return 'Não definida';
                                return `${value} ${getUnitLabel(unit, value)}`;
                            })()}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(service)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(service.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Form Modal */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              {editingService ? 'Editar Serviço' : 'Novo Serviço'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nome do Serviço *</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Input
                  id="category"
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  placeholder="ex: Manutenção Preventiva"
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                placeholder="Descreva brevemente o serviço..."
                className="mt-1"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4 items-end">
              <div>
                <Label htmlFor="price">Preço (R$)</Label>
                <Input
                  id="price"
                  name="price"
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={handleInputChange}
                  placeholder="0.00"
                  className="mt-1"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label htmlFor="duration_value">Duração</Label>
                  <Input
                    id="duration_value"
                    name="duration_value"
                    type="number"
                    value={durationValue}
                    onChange={(e) => handleDurationChange(e.target.value, durationUnit)}
                    className="mt-1"
                    min="0"
                  />
                </div>
                 <div>
                  <Label htmlFor="duration_unit" className="text-white select-none">Unidade</Label>
                  <Select
                    value={durationUnit}
                    onValueChange={(newUnit) => handleDurationChange(durationValue, newUnit)}
                  >
                    <SelectTrigger id="duration_unit" className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="minutes">Minutos</SelectItem>
                      <SelectItem value="hours">Horas</SelectItem>
                      <SelectItem value="days">Dias</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={resetForm}>
                <X className="w-4 h-4 mr-2" />
                Cancelar
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" />
                {editingService ? 'Atualizar' : 'Criar'} Serviço
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
