import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { verifyCheckoutSession } from '@/api/functions';
import { CheckCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';

export default function PaymentSuccess() {
    const navigate = useNavigate();
    const location = useLocation();
    const [status, setStatus] = useState('verifying'); // verifying, success, error
    const [error, setError] = useState('');
    const [planId, setPlanId] = useState('');

    useEffect(() => {
        const urlParams = new URLSearchParams(location.search);
        const sessionId = urlParams.get('session_id');

        if (!sessionId) {
            setStatus('error');
            setError('ID da sessão de pagamento não encontrado.');
            return;
        }

        const verifySession = async () => {
            try {
                const { data, error: apiError } = await verifyCheckoutSession({ session_id: sessionId });
                
                if (apiError || data.error) {
                    throw new Error(apiError?.message || data.error || 'Falha na verificação.');
                }

                if (data.status === 'success') {
                    setStatus('success');
                    setPlanId(data.planId);
                    setTimeout(() => {
                        navigate(createPageUrl('Dashboard'));
                    }, 5000);
                } else {
                    throw new Error('Falha na verificação do pagamento.');
                }
            } catch (err) {
                setStatus('error');
                setError(err.message || 'Ocorreu um erro ao verificar seu pagamento.');
            }
        };

        verifySession();
    }, [location, navigate]);

    const renderContent = () => {
        switch (status) {
            case 'verifying':
                return (
                    <div className="text-center">
                        <Loader2 className="w-16 h-16 text-blue-500 mx-auto mb-4 animate-spin" />
                        <CardTitle className="text-2xl">Verificando Pagamento</CardTitle>
                        <p className="text-gray-600 mt-2">Aguarde um momento, estamos confirmando sua assinatura...</p>
                    </div>
                );
            case 'success':
                return (
                    <div className="text-center">
                        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                        <CardTitle className="text-2xl">Pagamento Aprovado!</CardTitle>
                        <p className="text-gray-600 mt-2">
                            Sua assinatura do plano <span className="font-bold capitalize">{planId}</span> foi ativada com sucesso.
                        </p>
                        <p className="text-sm text-gray-500 mt-4">Você será redirecionado para o painel em 5 segundos.</p>
                        <Link to={createPageUrl('Dashboard')}>
                            <Button className="mt-4">Ir para o Painel Agora</Button>
                        </Link>
                    </div>
                );
            case 'error':
                return (
                    <div className="text-center">
                         <CheckCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                        <CardTitle className="text-2xl">Erro na Verificação</CardTitle>
                        <p className="text-gray-600 mt-2">{error}</p>
                        <Link to={createPageUrl('Dashboard')}>
                            <Button className="mt-4">Voltar para o Painel</Button>
                        </Link>
                    </div>
                );
            default:
                return null;
        }
    };
    
    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
            <Card className="max-w-md w-full">
                <CardContent className="p-8">
                    {renderContent()}
                </CardContent>
            </Card>
        </div>
    );
}