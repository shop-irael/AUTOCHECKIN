import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { Loader2 } from 'lucide-react';

export default function PostLogin() {
    const navigate = useNavigate();
    const [status, setStatus] = useState('Verificando autenticação...');

    useEffect(() => {
        const attemptLoginRouting = async () => {
            console.log('PostLogin: Roteamento iniciado.');
            setStatus('Autenticando...');
            
            try {
                // Tenta buscar o usuário. A plataforma já deve ter estabelecido a sessão.
                const user = await User.me();
                
                if (user && user.id) {
                    console.log('PostLogin: Usuário autenticado.', user);
                    if (user.role === 'admin') {
                        setStatus('Redirecionando para o painel de admin...');
                        console.log('PostLogin: Redirecionando para Dashboard.');
                        navigate(createPageUrl('Dashboard'), { replace: true });
                    } else {
                        setStatus('Redirecionando para o painel do cliente...');
                        console.log('PostLogin: Redirecionando para ClientDashboard.');
                        navigate(createPageUrl('ClientDashboard'), { replace: true });
                    }
                } else {
                    // Isso não deveria acontecer se o login do Google foi bem sucedido.
                    // Pode ser um atraso na propagação da sessão.
                    throw new Error('Falha ao obter dados do usuário após o login.');
                }
            } catch (error) {
                console.error('PostLogin: Erro no roteamento.', error);
                setStatus('Erro. Redirecionando para a página inicial...');
                // Se falhar, volta para a Home page após um tempo para não ficar travado.
                setTimeout(() => {
                    navigate(createPageUrl('Home'), { replace: true });
                }, 2500);
            }
        };
        
        // Dá um pequeno tempo para a sessão ser estabelecida pela plataforma antes de tentar.
        const timer = setTimeout(attemptLoginRouting, 500);

        // Limpa o timer se o componente for desmontado.
        return () => clearTimeout(timer);

    }, [navigate]);

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
            <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
            <p className="mt-4 text-lg font-medium text-gray-700">{status}</p>
            <p className="mt-1 text-sm text-gray-500">Aguarde um instante...</p>
        </div>
    );
}