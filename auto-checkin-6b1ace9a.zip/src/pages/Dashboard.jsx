
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkin, Servico } from '@/api/entities';
import { 
  Car, 
  ClipboardList, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  TrendingUp,
  Calendar,
  Users,
  Eye,
  Download,
  Plus,
  ExternalLink
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Dashboard() {
  const [checkins, setCheckins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [exportLoading, setExportLoading] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    inService: 0,
    completed: 0,
    today: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const checkinsData = await Checkin.list('-created_date');
      setCheckins(checkinsData);
      
      // Calculate stats
      const today = new Date().toDateString();
      const todayCheckins = checkinsData.filter(c => 
        new Date(c.created_date).toDateString() === today
      );
      
      setStats({
        total: checkinsData.length,
        pending: checkinsData.filter(c => c.status === 'pending_confirmation').length,
        inService: checkinsData.filter(c => c.status === 'in_service').length,
        completed: checkinsData.filter(c => c.status === 'completed').length,
        today: todayCheckins.length
      });
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const exportReport = async () => {
    setExportLoading(true);
    try {
      // Preparar dados para exportação
      const reportData = [
        ['Data', 'Cliente', 'Telefone', 'Placa', 'Veículo', 'Status', 'Observações'],
        ...checkins.map(checkin => [
          format(new Date(checkin.created_date), 'dd/MM/yyyy HH:mm'),
          checkin.clientName || '',
          checkin.clientPhone || '',
          checkin.vehiclePlate || '',
          `${checkin.vehicleModel || ''} ${checkin.vehicleYear || ''}`.trim(),
          getStatusText(checkin.status),
          checkin.observations || ''
        ])
      ];

      // Criar CSV
      const csvContent = reportData
        .map(row => row.map(cell => `"${cell}"`).join(','))
        .join('\n');

      // Download do arquivo
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `relatorio-checkins-${format(new Date(), 'yyyy-MM-dd')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
    } catch (error) {
      console.error('Erro ao exportar relatório:', error);
      alert('Erro ao exportar relatório. Tente novamente.');
    } finally {
      setExportLoading(false);
    }
  };

  const openCheckinForm = () => {
    // Abrir formulário em nova aba para demonstração
    const companyId = "oficina-do-carlos-demo"; // This would typically come from user context or URL
    const checkinUrl = `${window.location.origin}${createPageUrl('CheckinForm', { companyId })}`;
    window.open(checkinUrl, '_blank');
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Visão geral dos check-ins da sua oficina</p>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={exportReport}
            disabled={exportLoading}
          >
            <Download className="w-4 h-4" />
            {exportLoading ? 'Exportando...' : 'Exportar Relatório'}
          </Button>
          <Button 
            className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
            onClick={openCheckinForm}
          >
            <Plus className="w-4 h-4" />
            Novo Check-in
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Total de Check-ins</p>
                <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
                <p className="text-sm text-gray-600 mt-1">
                  <TrendingUp className="w-4 h-4 inline mr-1 text-green-500" />
                  +12% este mês
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <ClipboardList className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Pendentes</p>
                <p className="text-3xl font-bold text-gray-900">{stats.pending}</p>
                <p className="text-sm text-gray-600 mt-1">Aguardando confirmação</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Em Serviço</p>
                <p className="text-3xl font-bold text-gray-900">{stats.inService}</p>
                <p className="text-sm text-gray-600 mt-1">Sendo executados</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Car className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Hoje</p>
                <p className="text-3xl font-bold text-gray-900">{stats.today}</p>
                <p className="text-sm text-gray-600 mt-1">Check-ins realizados</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Calendar className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Check-ins */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-xl font-bold">Check-ins Recentes</CardTitle>
          <Link to={createPageUrl('CheckinList')}>
            <Button variant="outline" size="sm">
              Ver Todos
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {checkins.length === 0 ? (
            <div className="text-center py-8">
              <ClipboardList className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">Nenhum check-in realizado ainda</p>
              <Button onClick={openCheckinForm} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Criar Primeiro Check-in
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {checkins.slice(0, 5).map((checkin) => (
                <div key={checkin.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Car className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-gray-900">{checkin.clientName}</p>
                        <Badge className={getStatusColor(checkin.status)}>
                          {getStatusText(checkin.status)}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">
                        {checkin.vehiclePlate} • {checkin.vehicleModel} {checkin.vehicleYear}
                      </p>
                      <p className="text-xs text-gray-500">
                        {format(new Date(checkin.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">
                      {checkin.selectedServiceIds?.length || 0} serviços
                    </span>
                    <Button variant="ghost" size="sm">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6">
        <Link to={createPageUrl('CheckinList')}>
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6 text-center">
              <ClipboardList className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Gerenciar Check-ins</h3>
              <p className="text-gray-600 text-sm mb-4">Visualize e gerencie todos os check-ins</p>
              <Button variant="outline" className="w-full">
                Acessar
              </Button>
            </CardContent>
          </Card>
        </Link>

        <Link to={createPageUrl('VehicleHistory')}>
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6 text-center">
              <Car className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Histórico de Veículos</h3>
              <p className="text-gray-600 text-sm mb-4">Consulte histórico por placa</p>
              <Button variant="outline" className="w-full">
                Consultar
              </Button>
            </CardContent>
          </Card>
        </Link>

        <Link to={createPageUrl('Reports')}>
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6 text-center">
              <Users className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-900 mb-2">Relatórios</h3>
              <p className="text-gray-600 text-sm mb-4">Gere relatórios detalhados</p>
              <Button variant="outline" className="w-full">
                Gerar
              </Button>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );

  function getStatusColor(status) {
    switch (status) {
      case 'pending_confirmation': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'confirmed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in_service': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  }

  function getStatusText(status) {
    switch (status) {
      case 'pending_confirmation': return 'Pendente';
      case 'confirmed': return 'Confirmado';
      case 'in_service': return 'Em Serviço';
      case 'completed': return 'Concluído';
      case 'cancelled': return 'Cancelado';
      default: return status;
    }
  }
}
