
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Company } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { User } from '@/api/entities';
import QRCodeGenerator from '../components/QRCodeGenerator';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import StripeCheckout from '../components/payments/StripeCheckout'; // Importar o novo componente de Checkout
import {
  Settings as SettingsIcon,
  Building2,
  CreditCard,
  QrCode,
  Star,
  Check,
  Crown,
  Upload,
  FileText,
  Edit3,
  ExternalLink,
  Globe,
  Loader2,
  X,
  MessageCircle
} from 'lucide-react';

export default function Settings() {
  const [activeTab, setActiveTab] = useState('company');
  const [company, setCompany] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [showStripeCheckout, setShowStripeCheckout] = useState(false); // NOVO: Estado para o modal de checkout do Stripe
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: ''
  });

  const companyId = "oficina-do-carlos-demo";

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    // Roda somente quando `company` é carregado/atualizado
    if (company) {
      const urlParams = new URLSearchParams(window.location.search);
      const planIdToUpgrade = urlParams.get('upgradeToPlan');

      if (planIdToUpgrade) {
        const planObject = plans.find(p => p.id === planIdToUpgrade);
        if (planObject) {
          // Abre o modal de checkout
          handlePlanChange(planObject);
          // Limpa a URL para evitar que o modal reabra em um refresh
          const newUrl = window.location.pathname;
          window.history.replaceState({}, document.title, newUrl);
        }
      }
    }
  }, [company]); // Dependência do useEffect

  const loadData = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);

      const mockCompany = {
        id: companyId,
        name: "Oficina do Carlos",
        email: "contato@oficinadocarlos.com",
        phone: "(11) 99999-0000",
        address: "Rua das Oficinas, 123 - São Paulo, SP",
        plan: "intermediario",
        planExpiresAt: "2025-02-01T00:00:00Z",
        checkinLimit: 300,
        checkinCount: 45,
        logoUrl: null
      };

      setCompany(mockCompany);
      setFormData({
        name: mockCompany.name || '',
        email: mockCompany.email || '',
        phone: mockCompany.phone || '',
        address: mockCompany.address || ''
      });
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const isAdmin = () => {
    return currentUser?.role === 'admin' || currentUser?.email === 'admin@base44.app';
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // await Company.update(companyId, formData);
      setCompany(prev => ({ ...prev, ...formData }));
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Informações salvas com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar:', error);
      alert('Erro ao salvar. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione apenas arquivos de imagem (PNG, JPG, etc.)');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      alert('O arquivo deve ter no máximo 2MB');
      return;
    }

    if (!isAdmin() && company?.plan !== 'pro') {
      alert('A funcionalidade de logo personalizado está disponível apenas para o Plano Pro.');
      return;
    }

    setUploadingLogo(true);
    try {
      const { file_url } = await UploadFile({ file });

      // await Company.update(companyId, { logoUrl: file_url });

      setCompany(prev => ({ ...prev, logoUrl: file_url }));

      alert('Logo enviado com sucesso!');
    } catch (error) {
      console.error('Erro ao enviar logo:', error);
      alert('Erro ao enviar logo. Tente novamente.');
    } finally {
      setUploadingLogo(false);
      event.target.value = '';
    }
  };

  const handlePlanChange = (plan) => {
    setSelectedPlan(plan);
    const currentPlan = plans.find(p => p.id === company?.plan);

    // Se for upgrade, usar Stripe checkout
    if (plan.price > (currentPlan?.price || 0)) {
      setShowStripeCheckout(true);
    } else {
      // Para downgrades ou planos gratuitos, usar modal de confirmação
      setShowPlanModal(true);
    }
  };

  // Confirma a mudança de plano (para downgrades ou planos gratuitos)
  const confirmPlanChange = async () => {
    if (!selectedPlan) return;

    try {
      // In a real app, this would process payment and update the plan
      // await Company.update(companyId, { plan: selectedPlan.id, checkinLimit: selectedPlan.checkins });

      // Update local state
      setCompany(prev => ({
        ...prev,
        plan: selectedPlan.id,
        checkinLimit: typeof selectedPlan.checkins === 'number' ? selectedPlan.checkins : 999999
      }));

      setShowPlanModal(false);
      alert(`Plano alterado para ${selectedPlan.name} com sucesso!`);
    } catch (error) {
      console.error('Erro ao alterar plano:', error);
      alert('Erro ao alterar plano. Tente novamente.');
    }
  };

  const handleStripeSuccess = () => {
    setShowStripeCheckout(false);
    alert(`Assinatura do plano ${selectedPlan.name} ativada com sucesso!`);
    // Recarregar dados da empresa
    loadData();
  };

  const plans = [
    {
      id: 'basico',
      name: 'Básico',
      price: 29.90,
      checkins: 100,
      features: [
        'Formulário de check-in digital',
        'Armazenamento de fotos',
        'Assinatura digital',
        'Relatórios básicos',
        'Suporte por email'
      ],
      color: 'gray'
    },
    {
      id: 'intermediario',
      name: 'Intermediário',
      price: 59.90,
      checkins: 300,
      features: [
        'Tudo do plano Básico',
        'Histórico completo por placa',
        'QR Code personalizado',
        'Envio por WhatsApp',
        'Relatórios avançados',
        'Suporte prioritário'
      ],
      color: 'blue',
      popular: true
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 99.90,
      checkins: 'Ilimitado',
      features: [
        'Tudo do plano Intermediário',
        'Logo personalizado',
        'Notificações WhatsApp',
        'Múltiplos usuários',
        'API para integrações',
        'Suporte 24/7'
      ],
      color: 'purple'
    }
  ];

  const contentPages = [
    {
      id: 'funcionalidades',
      title: 'Funcionalidades',
      description: 'Página que detalha as funcionalidades do AutoCheckin para seus clientes',
      url: createPageUrl('Funcionalidades'),
      editUrl: createPageUrl('EditFuncionalidades'),
      icon: <SettingsIcon className="w-5 h-5 text-blue-600" />,
      status: 'Publicado'
    },
    {
      id: 'precos',
      title: 'Preços e Planos',
      description: 'Página com informações de preços e planos da sua oficina',
      url: createPageUrl('Precos'),
      editUrl: createPageUrl('EditPrecos'),
      icon: <CreditCard className="w-5 h-5 text-blue-600" />,
      status: 'Publicado'
    },
    {
      id: 'sobre',
      title: 'Sobre Nós',
      description: 'História e informações sobre sua oficina',
      url: createPageUrl('Sobre'),
      editUrl: createPageUrl('EditSobre'),
      icon: <Building2 className="w-5 h-5 text-blue-600" />,
      status: 'Publicado'
    },
    {
      id: 'contato',
      title: 'Contato',
      description: 'Informações de contato da sua oficina',
      url: createPageUrl('Contato'),
      editUrl: createPageUrl('EditContato'),
      icon: <FileText className="w-5 h-5 text-blue-600" />,
      status: 'Publicado'
    },
    {
      id: 'whatsapp',
      title: 'Contato WhatsApp',
      description: 'Configure número e mensagens do WhatsApp',
      url: createPageUrl('WhatsApp'),
      editUrl: createPageUrl('EditWhatsApp'),
      icon: <MessageCircle className="w-5 h-5 text-green-600" />,
      status: 'Publicado'
    },
    {
      id: 'blog',
      title: 'Blog',
      description: 'Artigos e dicas sobre manutenção automotiva',
      url: createPageUrl('Blog'),
      editUrl: createPageUrl('EditBlog'),
      icon: <FileText className="w-5 h-5 text-blue-600" />,
      status: 'Publicado'
    },
    {
      id: 'demo',
      title: 'Demonstração',
      description: 'Página para agendamento de demonstrações',
      url: createPageUrl('Demo'),
      editUrl: createPageUrl('EditDemo'),
      icon: <Globe className="w-5 h-5 text-blue-600" />,
      status: 'Publicado'
    },
    {
      id: 'central-ajuda',
      title: 'Central de Ajuda',
      description: 'FAQ e suporte para seus clientes',
      url: createPageUrl('CentralAjuda'),
      editUrl: createPageUrl('EditCentralAjuda'),
      icon: <FileText className="w-5 h-5 text-blue-600" />,
      status: 'Publicado'
    }
  ];

  const tabs = [
    { id: 'company', label: 'Empresa', icon: Building2 },
    { id: 'plan', label: 'Plano & Cobrança', icon: CreditCard },
    { id: 'content', label: 'Gerenciar Conteúdo', icon: FileText },
    { id: 'qrcode', label: 'QR Code', icon: QrCode }
  ];

  if (loading) {
    return (
      <div className="p-6">
        <div className="space-y-6">
          <Card className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-gray-200 rounded w-1/3 mb-2"></div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="h-4 bg-gray-200 rounded mb-4 w-1/2"></div>
              <div className="h-10 bg-gray-200 rounded mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-4 w-1/2"></div>
              <div className="h-10 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Configurações</h1>
        <p className="text-gray-600 mt-1">
          Gerencie sua conta, configurações da oficina e conteúdo do site
          {isAdmin() && <span className="text-blue-600 font-medium"> (Modo Administrador)</span>}
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center gap-2 ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Company Tab */}
      {activeTab === 'company' && (
        <div className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                Informações da Empresa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nome da Oficina</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="phone">Telefone</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="address">Endereço Completo</Label>
                <Textarea
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className="mt-1"
                />
              </div>

              <div className="flex justify-end pt-4">
                <Button
                  onClick={handleSave}
                  disabled={saving}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {saving ? 'Salvando...' : 'Salvar Alterações'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Logo Upload */}
          <Card>
            <CardHeader>
              <CardTitle>Logotipo da Empresa</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                  {company?.logoUrl ? (
                    <img
                      src={company.logoUrl}
                      alt="Logo da empresa"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <Upload className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                <div>
                  <input
                    type="file"
                    id="logo-upload"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    onClick={() => document.getElementById('logo-upload').click()}
                    disabled={uploadingLogo}
                  >
                    {uploadingLogo ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        {company?.logoUrl ? 'Alterar Logo' : 'Enviar Logo'}
                      </>
                    )}
                  </Button>
                  <p className="text-sm text-gray-500 mt-1">
                    PNG ou JPG até 2MB
                    {!isAdmin() && company?.plan !== 'pro' && ' (disponível no Plano Pro)'}
                    {isAdmin() && ' (Modo Admin: sem restrições)'}
                  </p>
                  {!isAdmin() && company?.plan !== 'pro' && (
                    <p className="text-xs text-amber-600 mt-1">
                      ⚠️ Upgrade para o Plano Pro para usar logo personalizado
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Plan Tab */}
      {activeTab === 'plan' && (
        <div className="mt-6 space-y-6">
          {/* Current Plan */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-blue-600" />
                Plano Atual
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-3">
                    <Badge className="bg-blue-600 text-white text-lg px-3 py-1">
                      {company?.plan === 'basico' ? 'Básico' :
                       company?.plan === 'intermediario' ? 'Intermediário' : 'Pro'}
                    </Badge>
                    <span className="text-2xl font-bold">
                      R$ {company?.plan === 'basico' ? '29,90' :
                           company?.plan === 'intermediario' ? '59,90' : '99,90'}/mês
                    </span>
                  </div>
                  <p className="text-gray-600 mt-2">
                    {company?.checkinCount || 0} de {company?.checkinLimit || 0} check-ins utilizados este mês
                  </p>
                  <div className="w-64 bg-gray-200 rounded-full h-2 mt-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{
                        width: `${Math.min(100, ((company?.checkinCount || 0) / (company?.checkinLimit || 1)) * 100)}%`
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Available Plans */}
          <div className="grid md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <Card key={plan.id} className={`relative ${plan.popular ? 'ring-2 ring-blue-500' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-600 text-white">
                      <Star className="w-3 h-3 mr-1" />
                      Mais Popular
                    </Badge>
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="text-center">
                    <div className="text-2xl font-bold">{plan.name}</div>
                    <div className="flex items-baseline justify-center gap-1 mt-2">
                      <span className="text-3xl font-bold">R$ {plan.price.toLocaleString('pt-BR')}</span>
                      <span className="text-gray-600">/mês</span>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {typeof plan.checkins === 'number' ? `${plan.checkins} check-ins/mês` : plan.checkins}
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full ${
                      company?.plan === plan.id
                        ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                        : plan.popular
                          ? 'bg-blue-600 hover:bg-blue-700 text-white'
                          : 'bg-gray-900 hover:bg-gray-800 text-white'
                    }`}
                    disabled={company?.plan === plan.id}
                    onClick={() => handlePlanChange(plan)}
                  >
                    {company?.plan === plan.id ? 'Plano Atual' : 'Selecionar Plano'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Content Management Tab */}
      {activeTab === 'content' && (
        <div className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Gerenciamento de Conteúdo
              </CardTitle>
              <p className="text-gray-600">
                Personalize as páginas públicas do seu site com informações específicas da sua oficina
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {contentPages.map((page) => (
                  <div key={page.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        {React.cloneElement(page.icon, { className: "w-5 h-5 text-blue-700" })}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{page.title}</h3>
                        <p className="text-sm text-gray-600">{page.description}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={page.status === 'Publicado' ? 'default' : 'outline'} className={`text-xs ${page.status === 'Publicado' ? 'bg-green-100 text-green-700 border-green-200' : ''}`}>
                            {page.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Link to={page.url} target="_blank" rel="noopener noreferrer">
                        <Button variant="ghost" size="sm" title="Visualizar página">
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </Link>
                      <Link to={page.editUrl}>
                        <Button variant="outline" size="sm" className="flex items-center gap-2">
                          <Edit3 className="w-4 h-4" />
                          Editar
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-200">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center mt-0.5">
                  <FileText className="w-3 h-3 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-amber-900 mb-2">Como funciona a edição de conteúdo</h3>
                  <ul className="text-sm text-amber-800 space-y-1">
                    <li>• Clique em "Editar" ao lado de cada página para personalizar o conteúdo</li>
                    <li>• Adicione informações específicas da sua oficina (endereço, telefone, história, etc.)</li>
                    <li>• As alterações ficam visíveis imediatamente para seus clientes após salvar</li>
                    <li>• Use "Visualizar" para ver como a página aparece publicamente</li>
                  </ul>
                  <p className="text-xs text-amber-700 mt-3">
                    💡 Dica: Mantenha as informações sempre atualizadas para passar mais confiança aos seus clientes
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* QR Code Tab */}
      {activeTab === 'qrcode' && (
        <div className="mt-6">
          <QRCodeGenerator />
        </div>
      )}

      {/* Plan Change Confirmation Modal (for downgrades/free) */}
      <Dialog open={showPlanModal} onOpenChange={setShowPlanModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar Alteração de Plano</DialogTitle>
            <DialogDescription>
              Você está prestes a alterar seu plano para {selectedPlan?.name}.
            </DialogDescription>
          </DialogHeader>

          {selectedPlan && (
            <div className="space-y-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <h3 className="text-lg font-semibold text-blue-900">
                  Plano {selectedPlan.name}
                </h3>
                <p className="text-2xl font-bold text-blue-600">
                  R$ {selectedPlan.price.toLocaleString('pt-BR')}/mês
                </p>
                <p className="text-sm text-blue-700">
                  {typeof selectedPlan.checkins === 'number' ? `${selectedPlan.checkins} check-ins/mês` : selectedPlan.checkins}
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">O que está incluído:</h4>
                <ul className="space-y-1">
                  {selectedPlan.features.slice(0, 3).map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm">
                      <Check className="w-3 h-3 text-green-500" />
                      {feature}
                    </li>
                  ))}
                  {selectedPlan.features.length > 3 && (
                    <li className="text-sm text-gray-500">
                      + {selectedPlan.features.length - 3} outras funcionalidades
                    </li>
                  )}
                </ul>
              </div>

              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => setShowPlanModal(false)} className="flex-1">
                  <X className="w-4 h-4 mr-2" />
                  Cancelar
                </Button>
                <Button onClick={confirmPlanChange} className="flex-1 bg-blue-600 hover:bg-blue-700">
                  Confirmar Alteração
                </Button>
              </div>

              <p className="text-xs text-gray-500 text-center">
                {isAdmin() ?
                  'Modo administrador: alteração será simulada' :
                  'A cobrança será ajustada no próximo ciclo de faturamento'
                }
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Stripe Checkout Modal */}
      <Dialog open={showStripeCheckout} onOpenChange={setShowStripeCheckout}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Finalizar Assinatura</DialogTitle>
            <DialogDescription>
              Você será redirecionado para o checkout seguro do Stripe
            </DialogDescription>
          </DialogHeader>
          {selectedPlan && (
            <StripeCheckout
              plan={selectedPlan}
              companyId={companyId}
              onClose={() => setShowStripeCheckout(false)}
              onSuccess={handleStripeSuccess}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
