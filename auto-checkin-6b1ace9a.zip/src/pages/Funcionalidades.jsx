import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function Funcionalidades() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Home
            </Button>
          </Link>
        </div>
        <div className="bg-white p-8 sm:p-12 shadow-xl rounded-lg">
          <h1 className="text-4xl font-bold text-gray-900 mb-8 border-b pb-4">Funcionalidades do AutoCheckin</h1>
          
          <section className="mb-10">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">Check-in Digital Inteligente</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              Transforme a recepção da sua oficina com nosso sistema de check-in 100% digital. Clientes podem preencher todos os dados do veículo e serviços desejados diretamente pelo celular, antes mesmo de chegar à oficina ou no local através de um QR Code.
            </p>
            <ul className="list-disc list-inside text-gray-700 space-y-1 pl-4">
              <li>Formulário personalizável com os campos que sua oficina precisa.</li>
              <li>Upload de fotos do veículo para documentar avarias e estado de conservação.</li>
              <li>Assinatura digital do cliente direto na tela, com validade jurídica.</li>
              <li>Eliminação de papelada, erros de digitação e retrabalho.</li>
            </ul>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">Histórico Completo por Veículo</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              Cada check-in fica vinculado à placa do veículo, criando um prontuário detalhado e de fácil acesso. Consulte todo o histórico de serviços, observações, fotos e assinaturas de forma organizada.
            </p>
            <ul className="list-disc list-inside text-gray-700 space-y-1 pl-4">
              <li>Busca rápida por placa para acesso imediato ao histórico.</li>
              <li>Visão cronológica de todas as passagens do veículo pela oficina.</li>
              <li>Identifique clientes recorrentes e padrões de manutenção.</li>
            </ul>
          </section>
          
          <section className="mb-10">
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">Painel de Gestão e Relatórios</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              Acompanhe em tempo real todos os check-ins, status dos serviços e indicadores chave da sua oficina através de um painel intuitivo. Gere relatórios detalhados para tomada de decisão estratégica.
            </p>
            <ul className="list-disc list-inside text-gray-700 space-y-1 pl-4">
              <li>Dashboard com visão geral de check-ins pendentes, em serviço e concluídos.</li>
              <li>Relatórios de produtividade, serviços mais realizados e faturamento estimado.</li>
              <li>Exportação de dados em formatos CSV/Excel para análises personalizadas.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-blue-700 mb-4">QR Code Personalizado e Links Diretos</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              Facilite o acesso ao check-in para seus clientes. Gere um QR Code exclusivo para sua oficina ou compartilhe um link direto por WhatsApp, Email ou Redes Sociais.
            </p>
             <ul className="list-disc list-inside text-gray-700 space-y-1 pl-4">
              <li>QR Code pronto para impressão e exibição na recepção.</li>
              <li>Link direto para o formulário de check-in da sua empresa.</li>
              <li>Personalização com logo da oficina (Planos Pro).</li>
            </ul>
          </section>

          <div className="mt-12 text-center border-t pt-8">
            <p className="text-gray-600 text-lg">
              Pronto para modernizar sua oficina com essas e muitas outras funcionalidades?
            </p>
            <Link to={createPageUrl("Home")} state={{ scrollTo: 'precos' }}>
                <Button size="lg" className="mt-4 bg-blue-600 hover:bg-blue-700">
                    Ver Planos e Preços
                </Button>
            </Link>
          </div>
           <p className="mt-6 text-sm text-gray-500">
            (Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)
          </p>
        </div>
      </div>
    </div>
  );
}