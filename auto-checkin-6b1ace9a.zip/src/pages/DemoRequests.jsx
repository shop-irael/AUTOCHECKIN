
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog"; // Added DialogClose
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label"; // Ensure Label is imported from shadcn/ui
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DemoRequest } from '@/api/entities';
import { 
  Calendar, 
  Users, 
  Mail, 
  Phone, 
  Building, 
  Eye, 
  Edit, 
  Download,
  MessageCircle,
  CheckCircle,
  Clock,
  X
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function DemoRequests() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [editNotes, setEditNotes] = useState('');
  const [newStatus, setNewStatus] = useState('');

  useEffect(() => {
    loadRequests();
  }, []);

  const loadRequests = async () => {
    try {
      const requestsData = await DemoRequest.list('-created_date');
      setRequests(requestsData);
    } catch (error) {
      console.error('Erro ao carregar solicitações:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (request) => {
    setSelectedRequest(request);
    setEditNotes(request.notes || '');
    setNewStatus(request.status);
    setShowModal(true);
  };

  const handleUpdateRequest = async () => {
    if (!selectedRequest) return;

    try {
      await DemoRequest.update(selectedRequest.id, {
        status: newStatus,
        notes: editNotes
      });
      
      // Update local state
      setRequests(prev => prev.map(req => 
        req.id === selectedRequest.id 
          ? { ...req, status: newStatus, notes: editNotes }
          : req
      ));
      
      setShowModal(false);
      alert('Solicitação atualizada com sucesso!');
    } catch (error) {
      console.error('Erro ao atualizar solicitação:', error);
      alert('Erro ao atualizar. Tente novamente.');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'contacted': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'demo_scheduled': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'demo_completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'converted': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'not_interested': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'contacted': return 'Contatado';
      case 'demo_scheduled': return 'Demo Agendada';
      case 'demo_completed': return 'Demo Realizada';
      case 'converted': return 'Convertido';
      case 'not_interested': return 'Não Interessado';
      default: return status;
    }
  };

  const exportRequests = () => {
    const csvContent = [
      ['Data', 'Nome', 'Email', 'Telefone', 'Oficina', 'Status', 'Comentários'],
      ...requests.map(request => [
        format(new Date(request.created_date), 'dd/MM/yyyy HH:mm'),
        request.name,
        request.email,
        request.phone,
        request.companyName || '',
        getStatusText(request.status),
        request.comments || ''
      ])
    ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `demo-requests-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const pendingCount = requests.filter(req => req.status === 'pending').length;
  const contactedCount = requests.filter(req => req.status === 'contacted').length;
  const convertedCount = requests.filter(req => req.status === 'converted').length;

  if (loading) {
    return (
      <div className="p-6">
        <div className="space-y-6">
          <Card className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-8 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Solicitações de Demonstração</h1>
          <p className="text-gray-600 mt-1">Gerencie leads e agendamentos de demonstração</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="flex items-center gap-2" onClick={exportRequests}>
            <Download className="w-4 h-4" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total</p>
                <p className="text-2xl font-bold">{requests.length}</p>
              </div>
              <Calendar className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pendentes</p>
                <p className="text-2xl font-bold text-yellow-600">{pendingCount}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Contatados</p>
                <p className="text-2xl font-bold text-blue-600">{contactedCount}</p>
              </div>
              <MessageCircle className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Convertidos</p>
                <p className="text-2xl font-bold text-green-600">{convertedCount}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Requests List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Solicitações ({requests.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {requests.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Nenhuma solicitação de demonstração encontrada</p>
            </div>
          ) : (
            <div className="space-y-4">
              {requests.map((request) => (
                <div key={request.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-gray-900">{request.name}</h3>
                        <Badge className={getStatusColor(request.status)}>
                          {getStatusText(request.status)}
                        </Badge>
                      </div>
                      
                      <div className="grid md:grid-cols-3 gap-2 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          {request.email}
                        </div>
                        <div className="flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {request.phone}
                        </div>
                        {request.companyName && (
                          <div className="flex items-center gap-1">
                            <Building className="w-3 h-3" />
                            {request.companyName}
                          </div>
                        )}
                      </div>
                      
                      <p className="text-xs text-gray-500 mt-1">
                        {format(new Date(request.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <a 
                        href={`mailto:${request.email}`}
                        className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                        title="Enviar email"
                      >
                        <Mail className="w-4 h-4" />
                      </a>
                      <a 
                        href={`https://wa.me/${request.phone.replace(/\D/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 text-gray-400 hover:text-green-600 transition-colors"
                        title="WhatsApp"
                      >
                        <MessageCircle className="w-4 h-4" />
                      </a>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleViewDetails(request)}
                        className="flex items-center gap-2"
                      >
                        <Eye className="w-4 h-4" />
                        Ver Detalhes
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Detalhes */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader className="relative">
            <DialogTitle className="flex items-center gap-2 pr-8">
              <Edit className="w-5 h-5" />
              Gerenciar Solicitação - {selectedRequest?.name}
            </DialogTitle>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setShowModal(false)}
              className="absolute right-0 top-0 h-6 w-6 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Fechar</span>
            </Button>
          </DialogHeader>
          
          {selectedRequest && (
            <div className="space-y-4 py-2">
              {/* Informações do Lead */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Informações do Lead</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-3">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Nome</Label>
                    <p className="text-gray-900">{selectedRequest.name}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Email</Label>
                    <p className="text-gray-900">{selectedRequest.email}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Telefone</Label>
                    <p className="text-gray-900">{selectedRequest.phone}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Oficina</Label>
                    <p className="text-gray-900">{selectedRequest.companyName || 'Não informado'}</p>
                  </div>
                  {selectedRequest.comments && (
                    <div className="md:col-span-2">
                      <Label className="text-sm font-medium text-gray-500">Comentários</Label>
                      <p className="text-gray-900">{selectedRequest.comments}</p>
                    </div>
                  )}
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Data da Solicitação</Label>
                    <p className="text-gray-900">
                      {format(new Date(selectedRequest.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Gerenciamento */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Gerenciar Lead</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <Label htmlFor="status">Status</Label>
                    <Select value={newStatus} onValueChange={setNewStatus}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pendente</SelectItem>
                        <SelectItem value="contacted">Contatado</SelectItem>
                        <SelectItem value="demo_scheduled">Demo Agendada</SelectItem>
                        <SelectItem value="demo_completed">Demo Realizada</SelectItem>
                        <SelectItem value="converted">Convertido</SelectItem>
                        <SelectItem value="not_interested">Não Interessado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="notes">Anotações Internas</Label>
                    <Textarea
                      id="notes"
                      value={editNotes}
                      onChange={(e) => setEditNotes(e.target.value)}
                      placeholder="Adicione anotações sobre o contato, agendamentos, etc."
                      className="mt-1 h-20"
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-end gap-3 pt-2">
                <Button variant="outline" onClick={() => setShowModal(false)}>
                  <X className="w-4 h-4 mr-2" />
                  Cancelar
                </Button>
                <Button onClick={handleUpdateRequest} className="bg-blue-600 hover:bg-blue-700">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Salvar Alterações
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
