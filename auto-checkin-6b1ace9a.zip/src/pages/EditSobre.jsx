
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Eye, Users, Target, Building, Trash2, PlusCircle } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function EditSobre() {
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    pageTitle: "Sobre o AutoCheckin",
    pageSubtitle: "Conheça a história e a equipe por trás da solução que está modernizando oficinas em todo o Brasil.",
    
    section1Title: "Nossa História",
    section1Content: "O AutoCheckin nasceu da paixão por tecnologia e da observação das necessidades do setor automotivo. Vimos oficinas talentosas perdendo tempo e eficiência com processos manuais de check-in, e decidimos criar uma solução simples, poderosa e acessível para transformar essa realidade. Desde [Ano de Fundação], nossa missão é empoderar oficinas com ferramentas digitais que otimizem o atendimento e melhorem a experiência do cliente.",
    
    section2Title: "Nossa Missão",
    section2Content: "Simplificar a gestão de check-ins em oficinas automotivas através de uma plataforma digital intuitiva, eficiente e confiável, ajudando nossos parceiros a economizar tempo, reduzir custos e oferecer um serviço excepcional aos seus clientes.",
    
    section3Title: "Nossa Visão",
    section3Content: "Ser a principal referência em soluções de check-in digital para o setor automotivo na América Latina, impulsionando a transformação digital de milhares de oficinas e contribuindo para um ecossistema mais moderno e conectado.",
    
    section4Title: "Nossos Valores",
    section4Values: [
      { title: "Inovação", description: "Buscamos constantemente novas formas de melhorar nossos produtos e serviços." },
      { title: "Foco no Cliente", description: "Nossos clientes estão no centro de tudo o que fazemos." },
      { title: "Simplicidade", description: "Acreditamos que a tecnologia deve ser fácil de usar e acessível a todos." },
      { title: "Parceria", description: "Construímos relações de longo prazo com nossas oficinas parceiras." },
      { title: "Transparência", description: "Agimos com integridade e clareza em todas as nossas interações." }
    ],

    teamSectionTitle: "Conheça Nossa Equipe (Opcional)",
    teamSectionDescription: "Uma breve apresentação dos fundadores ou membros chave da equipe.",
    // Você pode adicionar uma estrutura para membros da equipe se necessário
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleValueChange = (index, field, value) => {
    const newValues = [...formData.section4Values];
    newValues[index][field] = value;
    setFormData(prev => ({ ...prev, section4Values: newValues }));
  };

  const addValue = () => {
    setFormData(prev => ({
      ...prev,
      section4Values: [...prev.section4Values, { title: "", description: "" }]
    }));
  };

  const removeValue = (index) => {
    const newValues = [...formData.section4Values];
    newValues.splice(index, 1);
    setFormData(prev => ({ ...prev, section4Values: newValues }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Simulação de salvamento
      // await ContentPage.update('sobre', formData);
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Página Sobre Nós salva com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar página Sobre Nós:', error);
      alert('Erro ao salvar. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Settings")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Configurações
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Editar Página "Sobre Nós"</h1>
            <p className="text-gray-600 mt-1">Compartilhe a história e os valores da sua empresa</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to={createPageUrl("Sobre")} target="_blank">
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visualizar
            </Button>
          </Link>
          <Button 
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </Button>
        </div>
      </div>

      {/* Page Header Content */}
      <Card>
        <CardHeader>
          <CardTitle>Conteúdo Geral da Página</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="pageTitle">Título Principal</Label>
            <Input id="pageTitle" name="pageTitle" value={formData.pageTitle} onChange={handleInputChange} />
          </div>
          <div>
            <Label htmlFor="pageSubtitle">Subtítulo</Label>
            <Textarea id="pageSubtitle" name="pageSubtitle" value={formData.pageSubtitle} onChange={handleInputChange} rows={2}/>
          </div>
        </CardContent>
      </Card>

      {/* Sections Editor */}
      <div className="grid lg:grid-cols-1 gap-6">
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Building className="w-5 h-5"/> Nossa História</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="section1Title">Título da Seção</Label>
              <Input id="section1Title" name="section1Title" value={formData.section1Title} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="section1Content">Conteúdo</Label>
              <Textarea id="section1Content" name="section1Content" value={formData.section1Content} onChange={handleInputChange} rows={5}/>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Target className="w-5 h-5"/> Nossa Missão</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="section2Title">Título da Seção</Label>
              <Input id="section2Title" name="section2Title" value={formData.section2Title} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="section2Content">Conteúdo</Label>
              <Textarea id="section2Content" name="section2Content" value={formData.section2Content} onChange={handleInputChange} rows={3}/>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Eye className="w-5 h-5"/> Nossa Visão</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="section3Title">Título da Seção</Label>
              <Input id="section3Title" name="section3Title" value={formData.section3Title} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="section3Content">Conteúdo</Label>
              <Textarea id="section3Content" name="section3Content" value={formData.section3Content} onChange={handleInputChange} rows={3}/>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Users className="w-5 h-5"/> Nossos Valores</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="section4Title">Título da Seção</Label>
              <Input id="section4Title" name="section4Title" value={formData.section4Title} onChange={handleInputChange} />
            </div>
            {formData.section4Values.map((valueItem, index) => (
              <div key={index} className="p-3 border rounded-md space-y-2">
                <div className="flex justify-between items-center">
                  <Label>Valor {index + 1}</Label>
                  <Button variant="ghost" size="sm" onClick={() => removeValue(index)} className="text-red-500 hover:text-red-700">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                <div>
                  <Label htmlFor={`valueTitle-${index}`}>Título do Valor</Label>
                  <Input id={`valueTitle-${index}`} value={valueItem.title} onChange={(e) => handleValueChange(index, 'title', e.target.value)} />
                </div>
                <div>
                  <Label htmlFor={`valueDescription-${index}`}>Descrição do Valor</Label>
                  <Textarea id={`valueDescription-${index}`} value={valueItem.description} onChange={(e) => handleValueChange(index, 'description', e.target.value)} rows={2}/>
                </div>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={addValue} className="mt-2 flex items-center gap-1">
              <PlusCircle className="w-3 h-3"/> Adicionar Valor
            </Button>
          </CardContent>
        </Card>

         <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Users className="w-5 h-5"/> Equipe (Opcional)</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="teamSectionTitle">Título da Seção</Label>
              <Input id="teamSectionTitle" name="teamSectionTitle" value={formData.teamSectionTitle} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="teamSectionDescription">Descrição</Label>
              <Textarea id="teamSectionDescription" name="teamSectionDescription" value={formData.teamSectionDescription} onChange={handleInputChange} rows={3} placeholder="Apresente sua equipe aqui..."/>
            </div>
            {/* Adicionar campos para membros da equipe aqui, se necessário */}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
