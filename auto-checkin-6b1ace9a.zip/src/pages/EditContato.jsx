import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Eye, Phone, Mail, MapPin, MessageCircle } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function EditContato() {
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    companyName: "AutoCheckin Soluções Digitais",
    phone: "(11) 5555-4444",
    whatsapp: "(11) 99999-8888",
    email: "contato@autocheckin.com.br",
    address: "Rua da Tecnologia, 123, Sala 45, Bairro Inovação, São Paulo - SP, CEP 01010-010",
    businessHours: "Segunda a Sexta, das 9h às 18h",
    pageTitle: "Entre em Contato",
    pageSubtitle: "Estamos aqui para ajudar! Escolha a melhor forma de falar conosco.",
    formSectionTitle: "Mensagem Rápida",
    formSectionDescription: "Prefere enviar uma mensagem diretamente pela página de email?",
    additionalInfo: "Para dúvidas, sugestões ou propostas comerciais, nosso formulário de email é o canal mais indicado para um registro detalhado."
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Aqui você salvaria os dados usando uma entidade ou integração
      // await ContentPage.update('contato', formData);
      
      // Simulação de salvamento
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Informações de contato salvas com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar:', error);
      alert('Erro ao salvar informações. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Settings")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Configurações
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Editar Página de Contato</h1>
            <p className="text-gray-600 mt-1">Configure as informações de contato da sua oficina</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to={createPageUrl("Contato")} target="_blank">
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visualizar
            </Button>
          </Link>
          <Button 
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </Button>
        </div>
      </div>

      {/* Content Form */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Cabeçalho da Página</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="pageTitle">Título da Página</Label>
              <Input
                id="pageTitle"
                name="pageTitle"
                value={formData.pageTitle}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="pageSubtitle">Subtítulo</Label>
              <Input
                id="pageSubtitle"
                name="pageSubtitle"
                value={formData.pageSubtitle}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="companyName">Nome da Empresa</Label>
              <Input
                id="companyName"
                name="companyName"
                value={formData.companyName}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Informações de Contato
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="phone">Telefone Fixo</Label>
              <Input
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className="mt-1"
                placeholder="(11) 1234-5678"
              />
            </div>
            <div>
              <Label htmlFor="whatsapp">WhatsApp</Label>
              <Input
                id="whatsapp"
                name="whatsapp"
                value={formData.whatsapp}
                onChange={handleInputChange}
                className="mt-1"
                placeholder="(11) 99999-9999"
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                className="mt-1"
                placeholder="contato@suaoficina.com"
              />
            </div>
            <div>
              <Label htmlFor="businessHours">Horário de Atendimento</Label>
              <Input
                id="businessHours"
                name="businessHours"
                value={formData.businessHours}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Endereço
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div>
              <Label htmlFor="address">Endereço Completo</Label>
              <Textarea
                id="address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                className="mt-1"
                rows={3}
                placeholder="Rua, número, bairro, cidade, estado, CEP"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Seção de Mensagem Rápida</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="formSectionTitle">Título da Seção</Label>
              <Input
                id="formSectionTitle"
                name="formSectionTitle"
                value={formData.formSectionTitle}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="formSectionDescription">Descrição</Label>
              <Textarea
                id="formSectionDescription"
                name="formSectionDescription"
                value={formData.formSectionDescription}
                onChange={handleInputChange}
                className="mt-1"
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="additionalInfo">Informações Adicionais</Label>
              <Textarea
                id="additionalInfo"
                name="additionalInfo"
                value={formData.additionalInfo}
                onChange={handleInputChange}
                className="mt-1"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Preview Card */}
      <Card className="bg-green-50 border-green-200">
        <CardContent className="p-6">
          <h3 className="font-semibold text-green-900 mb-3">📱 Preview das Informações</h3>
          <div className="grid md:grid-cols-2 gap-6 text-sm">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-green-600" />
                <span>{formData.phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-green-600" />
                <span>{formData.whatsapp}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-green-600" />
                <span>{formData.email}</span>
              </div>
            </div>
            <div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-green-600 mt-0.5" />
                <span>{formData.address}</span>
              </div>
              <p className="text-green-700 mt-2 text-xs">
                Horário: {formData.businessHours}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Instructions Card */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-6">
          <h3 className="font-semibold text-blue-900 mb-2">📋 Instruções de Preenchimento</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• <strong>Telefone e WhatsApp:</strong> Use o formato (XX) XXXXX-XXXX</li>
            <li>• <strong>Email:</strong> Certifique-se de que o email está correto e funcionando</li>
            <li>• <strong>Endereço:</strong> Inclua informações completas para facilitar a localização</li>
            <li>• <strong>Horário:</strong> Seja claro sobre quando sua oficina está disponível</li>
            <li>• <strong>Teste:</strong> Verifique se os links de WhatsApp e email funcionam corretamente</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}