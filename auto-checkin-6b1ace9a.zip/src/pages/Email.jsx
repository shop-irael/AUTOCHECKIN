import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Mail, Send } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";


export default function Email() {
  const emailContato = "contato@autocheckin.com.br"; // Substitua pelo email real

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aqui você pode adicionar lógica para enviar o email usando uma integração
    // ou simplesmente abrir o cliente de email do usuário.
    const formData = new FormData(e.target);
    const subject = formData.get('subject');
    const body = `Nome: ${formData.get('name')}\nEmail: ${formData.get('email')}\nTelefone: ${formData.get('phone')}\n\nMensagem:\n${formData.get('message')}`;
    window.location.href = `mailto:${emailContato}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    alert("Seu cliente de email será aberto para enviar a mensagem.");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-indigo-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Home
            </Button>
          </Link>
        </div>
        <Card className="shadow-xl">
            <CardHeader className="text-center bg-gray-50 rounded-t-lg py-8">
                 <Mail className="w-16 h-16 text-indigo-600 mx-auto mb-4" />
                <CardTitle className="text-3xl font-bold text-gray-900">Entre em Contato por Email</CardTitle>
                <p className="text-gray-600 mt-2">
                    Tem alguma dúvida, sugestão ou precisa de suporte? Preencha o formulário abaixo ou envie um email diretamente para <strong className="text-indigo-700">{emailContato}</strong>.
                </p>
            </CardHeader>
            <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid sm:grid-cols-2 gap-6">
                        <div>
                            <Label htmlFor="name" className="font-medium">Seu Nome</Label>
                            <Input id="name" name="name" type="text" required className="mt-1" placeholder="Nome Completo"/>
                        </div>
                        <div>
                            <Label htmlFor="email" className="font-medium">Seu Email</Label>
                            <Input id="email" name="email" type="email" required className="mt-1" placeholder="seu@email.com"/>
                        </div>
                    </div>
                    <div>
                        <Label htmlFor="phone" className="font-medium">Seu Telefone (Opcional)</Label>
                        <Input id="phone" name="phone" type="tel" className="mt-1" placeholder="(XX) XXXXX-XXXX"/>
                    </div>
                     <div>
                        <Label htmlFor="subject" className="font-medium">Assunto</Label>
                        <Input id="subject" name="subject" type="text" required className="mt-1" placeholder="Dúvida sobre planos"/>
                    </div>
                    <div>
                        <Label htmlFor="message" className="font-medium">Sua Mensagem</Label>
                        <Textarea id="message" name="message" rows={5} required className="mt-1" placeholder="Descreva sua solicitação aqui..."/>
                    </div>
                    <Button type="submit" size="lg" className="w-full bg-indigo-600 hover:bg-indigo-700 text-lg py-3 flex items-center gap-2">
                        <Send className="w-5 h-5" />
                        Enviar Mensagem
                    </Button>
                </form>
            </CardContent>
        </Card>
        <p className="mt-8 text-center text-sm text-gray-500">
            (Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)
        </p>
      </div>
    </div>
  );
}