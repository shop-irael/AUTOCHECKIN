
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle,
  Car,
  Smartphone,
  BarChart3,
  Shield,
  Clock,
  Users,
  Star,
  ArrowRight,
  Play,
  CheckIcon,
  PhoneCall,
  MessageCircle,
  User,
  LayoutDashboard
} from "lucide-react";
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User as UserEntity } from '@/api/entities';
import { WhatsAppConfig } from '@/api/entities';

export default function Home() {
  const [selectedPlan, setSelectedPlan] = useState('intermediario');
  const navigate = useNavigate();
  const [whatsappConfig, setWhatsappConfig] = useState({
    phoneNumber: "5511999998888",
    defaultMessage: "Olá! Visitei o site do AutoCheckin e gostaria de mais informações.",
    whatsappLink: ""
  });

  const companyId = "oficina-do-carlos-demo";

  useEffect(() => {
    const loadWhatsAppConfig = async () => {
      try {
        const configs = await WhatsAppConfig.filter({ companyId });
        
        if (configs.length > 0) {
          const config = configs[0];
          const whatsappLink = `https://wa.me/${config.phoneNumber}?text=${encodeURIComponent(config.defaultMessage)}`;
          
          setWhatsappConfig({
            phoneNumber: config.phoneNumber,
            defaultMessage: config.defaultMessage,
            whatsappLink
          });
        } else {
          const defaultConfig = {
            phoneNumber: "5511999998888",
            defaultMessage: "Olá! Visitei o site do AutoCheckin e gostaria de mais informações."
          };
          
          const whatsappLink = `https://wa.me/${defaultConfig.phoneNumber}?text=${encodeURIComponent(defaultConfig.defaultMessage)}`;
          
          setWhatsappConfig({
            ...defaultConfig,
            whatsappLink
          });
        }
      } catch (error) {
        console.error('Erro ao carregar configurações do WhatsApp:', error);
      }
    };

    loadWhatsAppConfig();
    
    const checkAuthAndRedirect = async () => {
      try {
        const user = await UserEntity.me();
        if (user && user.id) {
          console.log('Home: Usuário já logado, redirecionando...', user);
          if (user.role === 'admin') {
            navigate(createPageUrl('Dashboard'), { replace: true });
          } else {
            navigate(createPageUrl('ClientDashboard'), { replace: true });
          }
        }
      } catch (error) {
        console.log('Home: Nenhum usuário logado, exibindo a página inicial.');
      }
    };

    checkAuthAndRedirect();
  }, [navigate, companyId]);

  const handleLogin = async () => {
    try {
      console.log('Home: Iniciando processo de login...');
      const callbackUrl = window.location.origin + createPageUrl('PostLogin');
      await UserEntity.loginWithRedirect(callbackUrl);
    } catch (error) {
      console.error('Home: Erro no login:', error);
      alert('Erro ao fazer login. Tente novamente.');
    }
  };

  const handleStartTrial = (planId) => {
    const callbackUrl = `${window.location.origin}${createPageUrl('Settings')}?upgradeToPlan=${planId}`;
    UserEntity.loginWithRedirect(callbackUrl);
  };

  const features = [
    {
      icon: <Smartphone className="w-8 h-8 text-blue-600" />,
      title: "Check-in Digital",
      description: "Clientes preenchem formulários via QR Code ou link, eliminando papelada e erros manuais."
    },
    {
      icon: <Car className="w-8 h-8 text-blue-600" />,
      title: "Histórico por Veículo",
      description: "Todo histórico de serviços fica vinculado à placa, criando um prontuário completo do veículo."
    },
    {
      icon: <BarChart3 className="w-8 h-8 text-blue-600" />,
      title: "Relatórios Inteligentes",
      description: "Dashboard com métricas, relatórios em PDF/Excel e insights para sua oficina crescer."
    },
    {
      icon: <Shield className="w-8 h-8 text-blue-600" />,
      title: "Assinatura Digital",
      description: "Documentação legal com assinatura eletrônica e upload de fotos do veículo."
    }
  ];

  const benefits = [
    "Elimina erros de recepção manual",
    "Aumenta profissionalismo da oficina",
    "Organiza histórico de todos os veículos",
    "Reduz tempo de atendimento em 70%",
    "Melhora experiência do cliente",
    "Gera relatórios automáticos"
  ];

  const plans = [
    {
      id: 'basico',
      name: 'Básico',
      price: 'R$ 29',
      period: '/mês',
      description: 'Perfeito para oficinas pequenas',
      checkins: '100 check-ins/mês',
      features: [
        'Formulário de check-in digital',
        'Armazenamento de fotos',
        'Assinatura digital',
        'Relatórios básicos',
        'Suporte por email'
      ],
      popular: false
    },
    {
      id: 'intermediario',
      name: 'Intermediário',
      price: 'R$ 59',
      period: '/mês',
      description: 'Ideal para oficinas em crescimento',
      checkins: '300 check-ins/mês',
      features: [
        'Tudo do plano Básico',
        'Histórico completo por placa',
        'QR Code personalizado',
        'Envio por WhatsApp',
        'Relatórios avançados',
        'Suporte prioritário'
      ],
      popular: true
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 'R$ 99',
      period: '/mês',
      description: 'Para oficinas que querem o máximo',
      checkins: 'Check-ins ilimitados',
      features: [
        'Tudo do plano Intermediário',
        'Logo personalizado',
        'Notificações WhatsApp',
        'Múltiplos usuários',
        'API para integrações',
        'Suporte 24/7'
      ],
      popular: false
    }
  ];

  const testimonials = [
    {
      name: "Carlos Silva",
      business: "Auto Center Silva",
      text: "O AutoCheckin transformou nossa recepção. Antes perdiamos 30 minutos por cliente, agora são apenas 5 minutos.",
      rating: 5
    },
    {
      name: "Marina Santos",
      business: "Oficina Rapidex",
      text: "Nossos clientes adoram a praticidade. O profissionalismo aumentou muito e conseguimos mais indicações.",
      rating: 5
    }
  ];

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const openWhatsApp = () => {
    if (whatsappConfig.whatsappLink) {
      window.open(whatsappConfig.whatsappLink, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header Fixo */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-100 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
                <Car className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-gray-900">AutoCheckin</h1>
                <p className="text-xs text-gray-500 hidden sm:block">Digitalize sua oficina</p>
              </div>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2">
              <Button
                variant="ghost"
                className="hidden lg:inline-flex text-sm"
                onClick={() => scrollToSection('como-funciona')}
              >
                Como Funciona
              </Button>
              <Button
                variant="ghost"
                className="hidden lg:inline-flex text-sm"
                onClick={() => scrollToSection('precos')}
              >
                Preços
              </Button>
              
              <Button variant="outline" onClick={handleLogin} className="text-xs px-2 py-1 sm:text-sm sm:px-3 sm:py-2">
                <User className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                <span className="hidden sm:inline">Login / </span>Painel
              </Button>
              <Button
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-2 py-1 sm:text-sm sm:px-3 sm:py-2"
                onClick={() => handleStartTrial('intermediario')}
              >
                <span className="hidden sm:inline">Teste </span>7 Dias
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="hero" className="pt-20 sm:pt-24 pb-12 sm:pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 via-white to-blue-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="space-y-6 sm:space-y-8 text-center lg:text-left">
              <div>
                <Badge className="bg-blue-100 text-blue-700 border-blue-200 mb-4 text-xs sm:text-sm">
                  🚀 Revolucione sua oficina
                </Badge>
                <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Check-in Digital
                  <span className="text-blue-600 block">Profissional</span>
                  para Oficinas
                </h1>
                <p className="text-base sm:text-lg lg:text-xl text-gray-600 mt-4 sm:mt-6 leading-relaxed">
                  Elimine papelada, aumente eficiência e impressione seus clientes com
                  check-ins digitais via QR Code. Histórico completo de cada veículo na palma da mão.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center lg:justify-start">
                <Button
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 sm:px-8 sm:py-4 text-base sm:text-lg w-full sm:w-auto"
                  onClick={() => handleStartTrial('intermediario')}
                >
                  <Play className="w-4 h-4 sm:w-5 h-5 mr-2" />
                  Começar Agora
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="px-6 py-3 sm:px-8 sm:py-4 text-base sm:text-lg border-2 w-full sm:w-auto"
                  onClick={openWhatsApp}
                  disabled={!whatsappConfig.whatsappLink}
                >
                  <MessageCircle className="w-4 h-4 sm:w-5 h-5 mr-2" />
                  Falar no WhatsApp
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-2 sm:space-y-0 sm:space-x-6 text-xs sm:text-sm text-gray-500">
                <div className="flex items-center space-x-1">
                  <CheckIcon className="w-3 h-3 sm:w-4 h-4 text-green-500" />
                  <span>Sem cartão de crédito</span>
                </div>
                <div className="flex items-center space-x-1">
                  <CheckIcon className="w-3 h-3 sm:w-4 h-4 text-green-500" />
                  <span>Cancele quando quiser</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-3xl p-8 shadow-2xl transform rotate-2">
                <div className="bg-white rounded-2xl p-6 transform -rotate-2">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-900">Novo Check-in</h3>
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <Car className="w-4 h-4 text-blue-600" />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-sm text-gray-500">Placa do Veículo</label>
                        <div className="mt-1 p-3 bg-gray-50 rounded-lg font-mono">ABC-1234</div>
                      </div>

                      <div>
                        <label className="text-sm text-gray-500">Serviços</label>
                        <div className="mt-1 space-y-2">
                          <div className="flex items-center space-x-2">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="text-sm">Troca de óleo</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="text-sm">Revisão de freios</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="text-sm text-gray-500">Fotos do Veículo</label>
                        <div className="mt-1 grid grid-cols-3 gap-2">
                          {[1,2,3].map(i => (
                            <div key={i} className="aspect-square bg-gray-200 rounded-lg flex items-center justify-center">
                              <Car className="w-6 h-6 text-gray-400" />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="como-funciona" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Como Funciona o AutoCheckin
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Funcionalidades pensadas especificamente para modernizar
              o atendimento da sua oficina automotiva
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 mx-auto mb-6 bg-blue-50 rounded-2xl flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="beneficios" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Transforme sua oficina em
                <span className="text-blue-600"> referência</span>
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Oficinas que usam o AutoCheckin economizam tempo,
                reduzem erros e conquistam mais clientes satisfeitos.
              </p>

              <div className="grid sm:grid-cols-2 gap-4 mb-8">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckIcon className="w-4 h-4 text-green-600" />
                    </div>
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>

              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700 text-white"
                onClick={() => handleStartTrial('intermediario')}
              >
                Começar Agora
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            <div className="relative">
              <div className="bg-white rounded-2xl shadow-2xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Resultados Reais</h3>
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl">
                    <div>
                      <p className="text-sm text-green-600 font-medium">Tempo de Atendimento</p>
                      <p className="text-2xl font-bold text-green-700">-70%</p>
                    </div>
                    <Clock className="w-8 h-8 text-green-600" />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
                    <div>
                      <p className="text-sm text-blue-600 font-medium">Satisfação do Cliente</p>
                      <p className="text-2xl font-bold text-blue-700">+95%</p>
                    </div>
                    <Users className="w-8 h-8 text-blue-600" />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-purple-50 rounded-xl">
                    <div>
                      <p className="text-sm text-purple-600 font-medium">Erros de Recepção</p>
                      <p className="text-2xl font-bold text-purple-700">-85%</p>
                    </div>
                    <Shield className="w-8 h-8 text-purple-600" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="depoimentos" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              O que dizem nossos clientes
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 text-lg mb-6 italic">"{testimonial.text}"</p>
                  <div>
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-gray-600">{testimonial.business}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="precos" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Planos que cabem no seu bolso
            </h2>
            <p className="text-xl text-gray-600">
              Escolha o plano ideal para o tamanho da sua oficina
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <Card key={plan.id} className={`relative border-2 ${plan.popular ? 'border-blue-500 shadow-2xl scale-105' : 'border-gray-200'}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-600 text-white px-4 py-1">
                      Mais Popular
                    </Badge>
                  </div>
                )}
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                    <p className="text-gray-600 mb-4">{plan.description}</p>
                    <div className="flex items-baseline justify-center">
                      <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                      <span className="text-gray-600 ml-1">{plan.period}</span>
                    </div>
                    <p className="text-sm text-gray-500 mt-2">{plan.checkins}</p>
                  </div>

                  <Button
                    className={`w-full ${plan.popular ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-900'}`}
                    size="lg"
                    onClick={() => handleStartTrial(plan.id)}
                  >
                    Começar Teste Grátis
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">
              Todos os planos incluem teste grátis de 7 dias • Cancele quando quiser
            </p>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section id="teste-gratis" className="py-20 px-4 sm:px-6 lg:px-8 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Pronto para modernizar sua oficina?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Junte-se a centenas de oficinas que já transformaram seu atendimento
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg"
              onClick={() => handleStartTrial('intermediario')}
            >
              <Play className="w-5 h-5 mr-2" />
              Começar Agora
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg"
              onClick={openWhatsApp}
              disabled={!whatsappConfig.whatsappLink}
            >
              <PhoneCall className="w-5 h-5 mr-2" />
              Falar com Especialista
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Car className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">AutoCheckin</span>
              </div>
              <p className="text-gray-400">
                Digitalizando oficinas automotivas em todo o Brasil.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Produto</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link to={createPageUrl("Funcionalidades")} className="hover:text-white">Funcionalidades</Link></li>
                <li><Link to={createPageUrl("Precos")} className="hover:text-white">Preços</Link></li>
                <li><Link to={createPageUrl("Demo")} className="hover:text-white">Demo</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link to={createPageUrl("CentralAjuda")} className="hover:text-white">Central de Ajuda</Link></li>
                <li><button onClick={openWhatsApp} className="hover:text-white text-left">WhatsApp</button></li>
                <li><Link to={createPageUrl("Contato")} className="hover:text-white">Contato</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Empresa</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link to={createPageUrl("Sobre")} className="hover:text-white">Sobre</Link></li>
                <li><Link to={createPageUrl("Blog")} className="hover:text-white">Blog</Link></li>
                <li><Link to={createPageUrl("Contato")} className="hover:text-white">Contato</Link></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} AutoCheckin. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
