import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Eye, MessageCircle, Copy, Phone, Globe } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { WhatsAppConfig } from '@/api/entities';

export default function EditWhatsApp() {
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [configId, setConfigId] = useState(null);
  const [formData, setFormData] = useState({
    pageTitle: "Fale Conosco no WhatsApp",
    pageDescription: "Nossa equipe de especialistas está pronta para te atender! Clique no botão abaixo para iniciar uma conversa ou adicione nosso número.",
    phoneNumber: "5511999998888",
    phoneDisplayNumber: "+55 (11) 99999-8888",
    buttonText: "Iniciar Conversa Agora",
    businessHours: "Segunda a Sexta, das 9h às 18h",
    defaultMessage: "Olá! Gostaria de mais informações sobre o AutoCheckin.",
    additionalInfo: "(Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)"
  });

  const companyId = "oficina-do-carlos-demo"; // Em produção, viria do contexto/usuário logado

  useEffect(() => {
    loadWhatsAppConfig();
  }, []);

  const loadWhatsAppConfig = async () => {
    try {
      setLoading(true);
      
      // Buscar configuração existente para esta empresa
      const configs = await WhatsAppConfig.filter({ companyId });
      
      if (configs.length > 0) {
        const config = configs[0];
        setConfigId(config.id);
        setFormData({
          pageTitle: config.pageTitle || "Fale Conosco no WhatsApp",
          pageDescription: config.pageDescription || "Nossa equipe de especialistas está pronta para te atender! Clique no botão abaixo para iniciar uma conversa ou adicione nosso número.",
          phoneNumber: config.phoneNumber || "5511999998888",
          phoneDisplayNumber: config.phoneDisplayNumber || "+55 (11) 99999-8888",
          buttonText: config.buttonText || "Iniciar Conversa Agora",
          businessHours: config.businessHours || "Segunda a Sexta, das 9h às 18h",
          defaultMessage: config.defaultMessage || "Olá! Gostaria de mais informações sobre o AutoCheckin.",
          additionalInfo: config.additionalInfo || "(Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)"
        });
      }
    } catch (error) {
      console.error('Erro ao carregar configurações do WhatsApp:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const formatPhoneNumber = (phone) => {
    const cleanPhone = phone.replace(/\D/g, '');
    
    if (cleanPhone.startsWith('55') && cleanPhone.length === 13) {
      const countryCode = cleanPhone.slice(0, 2);
      const areaCode = cleanPhone.slice(2, 4);
      const firstPart = cleanPhone.slice(4, 9);
      const secondPart = cleanPhone.slice(9, 13);
      return `+${countryCode} (${areaCode}) ${firstPart}-${secondPart}`;
    }
    
    return phone;
  };

  const handlePhoneChange = (e) => {
    const { value } = e.target;
    const cleanValue = value.replace(/\D/g, '');
    const formattedValue = formatPhoneNumber(cleanValue);
    
    setFormData(prev => ({
      ...prev,
      phoneNumber: cleanValue,
      phoneDisplayNumber: formattedValue
    }));
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(formData.phoneDisplayNumber)
      .then(() => alert("Número copiado para a área de transferência!"))
      .catch(err => console.error('Erro ao copiar:', err));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const configData = {
        ...formData,
        companyId
      };

      if (configId) {
        // Atualizar configuração existente
        await WhatsAppConfig.update(configId, configData);
        console.log('Configuração WhatsApp atualizada:', configId);
      } else {
        // Criar nova configuração
        const newConfig = await WhatsAppConfig.create(configData);
        setConfigId(newConfig.id);
        console.log('Nova configuração WhatsApp criada:', newConfig.id);
      }
      
      alert('Configurações do WhatsApp salvas com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar configurações do WhatsApp:', error);
      alert('Erro ao salvar configurações. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  const whatsappLink = `https://wa.me/${formData.phoneNumber}?text=${encodeURIComponent(formData.defaultMessage)}`;

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando configurações...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Settings")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Configurações
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Editar Contato WhatsApp</h1>
            <p className="text-gray-600 mt-1">Configure as informações de contato via WhatsApp</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to={createPageUrl("WhatsApp")} target="_blank">
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visualizar
            </Button>
          </Link>
          <Button 
            onClick={handleSave}
            disabled={saving}
            className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </Button>
        </div>
      </div>

      {/* Content Form */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Conteúdo da Página</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="pageTitle">Título da Página</Label>
              <Input
                id="pageTitle"
                name="pageTitle"
                value={formData.pageTitle}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="pageDescription">Descrição Principal</Label>
              <Textarea
                id="pageDescription"
                name="pageDescription"
                value={formData.pageDescription}
                onChange={handleInputChange}
                className="mt-1"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="buttonText">Texto do Botão Principal</Label>
              <Input
                id="buttonText"
                name="buttonText"
                value={formData.buttonText}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="defaultMessage">Mensagem Padrão (enviada automaticamente)</Label>
              <Textarea
                id="defaultMessage"
                name="defaultMessage"
                value={formData.defaultMessage}
                onChange={handleInputChange}
                className="mt-1"
                rows={2}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Informações de Contato
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="phoneNumber">Número do WhatsApp</Label>
              <Input
                id="phoneNumber"
                name="phoneNumber"
                value={formData.phoneNumber}
                onChange={handlePhoneChange}
                className="mt-1"
                placeholder="5511999998888"
              />
              <p className="text-xs text-gray-500 mt-1">
                Digite apenas números (ex: 5511999998888 para +55 11 99999-8888)
              </p>
            </div>
            <div>
              <Label>Número Formatado (Preview)</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input
                  value={formData.phoneDisplayNumber}
                  readOnly
                  className="flex-1 bg-gray-50"
                />
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={copyToClipboard}
                  title="Copiar número"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div>
              <Label htmlFor="businessHours">Horário de Atendimento</Label>
              <Input
                id="businessHours"
                name="businessHours"
                value={formData.businessHours}
                onChange={handleInputChange}
                className="mt-1"
                placeholder="Segunda a Sexta, das 9h às 18h"
              />
            </div>
            <div>
              <Label htmlFor="additionalInfo">Informação Adicional (rodapé)</Label>
              <Textarea
                id="additionalInfo"
                name="additionalInfo"
                value={formData.additionalInfo}
                onChange={handleInputChange}
                className="mt-1"
                rows={2}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Preview Card */}
      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <MessageCircle className="w-5 h-5" />
            Preview do WhatsApp
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-white p-6 rounded-lg shadow-sm max-w-md mx-auto text-center">
            <MessageCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 mb-3">{formData.pageTitle}</h2>
            <p className="text-gray-700 mb-6 text-sm">{formData.pageDescription}</p>
            
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button className="w-full bg-green-500 hover:bg-green-600 text-white mb-4">
                {formData.buttonText}
              </Button>
            </a>

            <div className="mb-4">
              <p className="text-gray-600 mb-2 text-sm">Ou adicione nosso número:</p>
              <div className="flex items-center justify-center gap-2 p-2 bg-gray-100 rounded">
                <span className="font-mono text-green-700 text-sm">{formData.phoneDisplayNumber}</span>
              </div>
            </div>
            
            <p className="text-xs text-gray-500">{formData.businessHours}</p>
          </div>
        </CardContent>
      </Card>

      {/* Status Card */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-blue-900">Status da Configuração</h3>
              <p className="text-sm text-blue-700">
                {configId ? `Configuração existente (ID: ${configId.slice(-8)})` : 'Nova configuração será criada'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-blue-600">Empresa: {companyId}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Instructions Card */}
      <Card className="bg-amber-50 border-amber-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center mt-0.5">
              <Globe className="w-4 h-4 text-amber-600" />
            </div>
            <div>
              <h3 className="font-semibold text-amber-900 mb-2">Configuração da Página Inicial</h3>
              <p className="text-sm text-amber-800">
                As informações de contato salvas aqui (número de WhatsApp e mensagem padrão) serão usadas para o botão <strong className="font-medium">"Falar no WhatsApp"</strong> na página inicial do site.
              </p>
              <p className="text-xs text-amber-700 mt-2">
                Esta configuração é específica para sua empresa e será persistida no banco de dados.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}