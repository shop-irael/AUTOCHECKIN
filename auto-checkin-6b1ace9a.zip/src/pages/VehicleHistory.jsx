import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"; // Added Dialog
import { Checkin, Servico } from '@/api/entities';
import { 
  Search, 
  Car, 
  Calendar,
  Settings,
  FileText,
  MapPin,
  Phone,
  Eye,
  User, // Added User icon
  Image as ImageIcon, // Added ImageIcon
  Edit as EditIcon, // Added EditIcon (renamed to avoid conflict with Edit from lucide-react)
  X // Added X icon
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Label } from "@/components/ui/label"; // Added Label

export default function VehicleHistory() {
  const [checkins, setCheckins] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchPlate, setSearchPlate] = useState('');
  const [vehicleHistory, setVehicleHistory] = useState([]);
  const [selectedCheckinDetails, setSelectedCheckinDetails] = useState(null); // State for modal
  const [showDetailsModal, setShowDetailsModal] = useState(false); // State for modal visibility

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [checkinsData, servicesData] = await Promise.all([
        Checkin.list('-created_date'),
        Servico.list()
      ]);
      setCheckins(checkinsData);
      setServices(servicesData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchVehicle = () => {
    if (!searchPlate.trim()) {
      setVehicleHistory([]);
      return;
    }

    const history = checkins.filter(checkin => 
      checkin.vehiclePlate.toLowerCase().includes(searchPlate.toLowerCase())
    );
    setVehicleHistory(history);
  };

  const handleViewDetails = (checkin) => { // Function to open modal
    setSelectedCheckinDetails(checkin);
    setShowDetailsModal(true);
  };

  const getServiceNames = (serviceIds) => {
    if (!serviceIds || serviceIds.length === 0) return 'Nenhum serviço';
    return serviceIds
      .map(id => services.find(s => s.id === id)?.name || 'Serviço não encontrado')
      .join(', ');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending_confirmation': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'confirmed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in_service': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'pending_confirmation': return 'Pendente';
      case 'confirmed': return 'Confirmado';
      case 'in_service': return 'Em Serviço';
      case 'completed': return 'Concluído';
      case 'cancelled': return 'Cancelado';
      default: return status;
    }
  };

  const getVehicleInfo = () => {
    if (vehicleHistory.length === 0) return null;
    const latest = vehicleHistory[0];
    return {
      plate: latest.vehiclePlate,
      model: latest.vehicleModel,
      year: latest.vehicleYear,
      color: latest.vehicleColor,
      totalVisits: vehicleHistory.length,
      lastVisit: latest.created_date
    };
  };

  const vehicleInfo = getVehicleInfo();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Histórico de Veículos</h1>
        <p className="text-gray-600 mt-1">Consulte todo o histórico de check-ins por placa do veículo</p>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Digite a placa do veículo (ex: ABC-1234)"
                  value={searchPlate}
                  onChange={(e) => setSearchPlate(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && searchVehicle()}
                  className="pl-10"
                />
              </div>
            </div>
            <Button onClick={searchVehicle} className="bg-blue-600 hover:bg-blue-700">
              <Search className="w-4 h-4 mr-2" />
              Buscar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Vehicle Summary */}
      {vehicleInfo && (
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Car className="w-5 h-5" />
              Resumo do Veículo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <MapPin className="w-8 h-8 text-blue-600" />
                </div>
                <p className="text-sm text-gray-500">Placa</p>
                <p className="font-bold text-lg">{vehicleInfo.plate}</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Car className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-sm text-gray-500">Veículo</p>
                <p className="font-bold text-lg">{vehicleInfo.model}</p>
                <p className="text-sm text-gray-600">{vehicleInfo.year} • {vehicleInfo.color}</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <FileText className="w-8 h-8 text-purple-600" />
                </div>
                <p className="text-sm text-gray-500">Total de Visitas</p>
                <p className="font-bold text-lg">{vehicleInfo.totalVisits}</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Calendar className="w-8 h-8 text-orange-600" />
                </div>
                <p className="text-sm text-gray-500">Última Visita</p>
                <p className="font-bold text-lg">
                  {format(new Date(vehicleInfo.lastVisit), "dd/MM/yy", { locale: ptBR })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* History Results */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Histórico de Check-ins {vehicleHistory.length > 0 && `(${vehicleHistory.length})`}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!searchPlate && (
            <div className="text-center py-12">
              <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Busque por uma placa</h3>
              <p className="text-gray-500">Digite a placa do veículo para ver todo o histórico de check-ins</p>
            </div>
          )}

          {searchPlate && vehicleHistory.length === 0 && (
            <div className="text-center py-12">
              <Car className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum histórico encontrado</h3>
              <p className="text-gray-500">Não há check-ins registrados para a placa "{searchPlate}"</p>
            </div>
          )}

          {vehicleHistory.length > 0 && (
            <div className="space-y-4">
              {vehicleHistory.map((checkin, index) => (
                <div key={checkin.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-sm font-bold text-blue-600">
                          {vehicleHistory.length - index}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-gray-900">{checkin.clientName}</h3>
                            <Badge className={getStatusColor(checkin.status)}>
                              {getStatusText(checkin.status)}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                            {checkin.clientPhone}
                          </p>
                        </div>
                      </div>
                      
                      <div className="pl-11 space-y-2">
                        <p className="text-sm text-gray-600 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(checkin.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                        </p>
                        <p className="text-sm text-gray-600 flex items-start gap-1">
                          <Settings className="w-3 h-3 mt-0.5" />
                          <span>{getServiceNames(checkin.selectedServiceIds)}</span>
                        </p>
                        {checkin.observations && (
                          <p className="text-sm text-gray-500 italic">
                            "{checkin.observations.substring(0, 150)}{checkin.observations.length > 150 ? '...' : ''}"
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="ml-4">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleViewDetails(checkin)} // Call handleViewDetails on click
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Ver Detalhes
                      </Button>
                    </div>
                  </div>

                  {/* Timeline connector */}
                  {index < vehicleHistory.length - 1 && (
                    <div className="ml-4 mt-4 h-4 border-l-2 border-gray-200"></div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Detalhes do Check-in */}
      <Dialog open={showDetailsModal} onOpenChange={setShowDetailsModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader className="relative">
            <DialogTitle className="flex items-center gap-2 pr-8">
              <FileText className="w-5 h-5" />
              Detalhes do Check-in - {selectedCheckinDetails?.clientName}
            </DialogTitle>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setShowDetailsModal(false)}
              className="absolute right-0 top-0 h-6 w-6 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Fechar</span>
            </Button>
          </DialogHeader>
          
          {selectedCheckinDetails && (
            <div className="space-y-6 py-2">
              {/* Informações do Cliente */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <User className="w-5 h-5" />
                    Dados do Cliente
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Nome</Label>
                    <p className="text-gray-900">{selectedCheckinDetails.clientName}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Telefone</Label>
                    <p className="text-gray-900">{selectedCheckinDetails.clientPhone}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Informações do Veículo */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Car className="w-5 h-5" />
                    Dados do Veículo
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Placa</Label>
                    <p className="text-gray-900 font-mono">{selectedCheckinDetails.vehiclePlate}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Modelo</Label>
                    <p className="text-gray-900">{selectedCheckinDetails.vehicleModel}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Ano</Label>
                    <p className="text-gray-900">{selectedCheckinDetails.vehicleYear}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Cor</Label>
                    <p className="text-gray-900">{selectedCheckinDetails.vehicleColor}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Serviços Solicitados */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Settings className="w-5 h-5" />
                    Serviços Solicitados
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedCheckinDetails.selectedServiceIds && selectedCheckinDetails.selectedServiceIds.length > 0 ? (
                    <div className="space-y-2">
                      {getServiceNames(selectedCheckinDetails.selectedServiceIds).map((serviceName, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          <span>{serviceName}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500">Nenhum serviço selecionado</p>
                  )}
                </CardContent>
              </Card>

              {/* Fotos do Veículo */}
              {selectedCheckinDetails.photoUrls && selectedCheckinDetails.photoUrls.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <ImageIcon className="w-5 h-5" />
                      Fotos do Veículo ({selectedCheckinDetails.photoUrls.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {selectedCheckinDetails.photoUrls.map((photoUrl, index) => (
                        <div key={index} className="aspect-square">
                          <img 
                            src={photoUrl} 
                            alt={`Foto ${index + 1}`}
                            className="w-full h-full object-cover rounded-lg border hover:scale-105 transition-transform cursor-pointer"
                            onClick={() => window.open(photoUrl, '_blank')}
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Assinatura */}
              {selectedCheckinDetails.signatureUrl && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <EditIcon className="w-5 h-5" /> {/* Renomeado para EditIcon */}
                      Assinatura Digital
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="border rounded-lg p-4 bg-gray-50 inline-block">
                      <img 
                        src={selectedCheckinDetails.signatureUrl} 
                        alt="Assinatura"
                        className="max-w-xs h-auto"
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Observações */}
              {selectedCheckinDetails.observations && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <FileText className="w-5 h-5" />
                      Observações
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">{selectedCheckinDetails.observations}</p>
                  </CardContent>
                </Card>
              )}

              {/* Informações do Check-in */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Calendar className="w-5 h-5" />
                    Informações do Check-in
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Status</Label>
                    <div className="mt-1">
                      <Badge className={getStatusColor(selectedCheckinDetails.status)}>
                        {getStatusText(selectedCheckinDetails.status)}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Data do Check-in</Label>
                    <p className="text-gray-900">
                      {format(new Date(selectedCheckinDetails.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}