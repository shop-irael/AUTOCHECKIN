import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Eye } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function EditFuncionalidades() {
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    title: "Funcionalidades do AutoCheckin",
    subtitle: "Transforme a recepção da sua oficina com tecnologia digital",
    section1Title: "Check-in Digital Inteligente",
    section1Content: "Transforme a recepção da sua oficina com nosso sistema de check-in 100% digital. Clientes podem preencher todos os dados do veículo e serviços desejados diretamente pelo celular, antes mesmo de chegar à oficina ou no local através de um QR Code.",
    section1Items: "• Formulário personalizável com os campos que sua oficina precisa\n• Upload de fotos do veículo para documentar avarias\n• Assinatura digital do cliente direto na tela\n• Eliminação de papelada, erros de digitação e retrabalho",
    section2Title: "Histórico Completo por Veículo",
    section2Content: "Cada check-in fica vinculado à placa do veículo, criando um prontuário detalhado e de fácil acesso. Consulte todo o histórico de serviços, observações, fotos e assinaturas de forma organizada.",
    section2Items: "• Busca rápida por placa para acesso imediato ao histórico\n• Visão cronológica de todas as passagens do veículo\n• Identifique clientes recorrentes e padrões de manutenção",
    section3Title: "Painel de Gestão e Relatórios",
    section3Content: "Acompanhe em tempo real todos os check-ins, status dos serviços e indicadores chave da sua oficina através de um painel intuitivo.",
    section3Items: "• Dashboard com visão geral de check-ins pendentes\n• Relatórios de produtividade e faturamento estimado\n• Exportação de dados em formatos CSV/Excel",
    ctaText: "Pronto para modernizar sua oficina com essas funcionalidades?"
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Aqui você salvaria os dados usando uma entidade ou integração
      // await ContentPage.update('funcionalidades', formData);
      
      // Simulação de salvamento
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Conteúdo salvo com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar:', error);
      alert('Erro ao salvar conteúdo. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Settings")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Configurações
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Editar Página de Funcionalidades</h1>
            <p className="text-gray-600 mt-1">Personalize o conteúdo da página de funcionalidades para sua oficina</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to={createPageUrl("Funcionalidades")} target="_blank">
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visualizar
            </Button>
          </Link>
          <Button 
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </Button>
        </div>
      </div>

      {/* Content Form */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Cabeçalho da Página</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="title">Título Principal</Label>
              <Input
                id="title"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="subtitle">Subtítulo</Label>
              <Textarea
                id="subtitle"
                name="subtitle"
                value={formData.subtitle}
                onChange={handleInputChange}
                className="mt-1"
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="ctaText">Texto da Chamada para Ação</Label>
              <Input
                id="ctaText"
                name="ctaText"
                value={formData.ctaText}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Seção 1 - Check-in Digital</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="section1Title">Título da Seção</Label>
              <Input
                id="section1Title"
                name="section1Title"
                value={formData.section1Title}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="section1Content">Descrição</Label>
              <Textarea
                id="section1Content"
                name="section1Content"
                value={formData.section1Content}
                onChange={handleInputChange}
                className="mt-1"
                rows={4}
              />
            </div>
            <div>
              <Label htmlFor="section1Items">Lista de Itens (um por linha)</Label>
              <Textarea
                id="section1Items"
                name="section1Items"
                value={formData.section1Items}
                onChange={handleInputChange}
                className="mt-1"
                rows={4}
                placeholder="• Item 1&#10;• Item 2&#10;• Item 3"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Seção 2 - Histórico de Veículos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="section2Title">Título da Seção</Label>
              <Input
                id="section2Title"
                name="section2Title"
                value={formData.section2Title}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="section2Content">Descrição</Label>
              <Textarea
                id="section2Content"
                name="section2Content"
                value={formData.section2Content}
                onChange={handleInputChange}
                className="mt-1"
                rows={4}
              />
            </div>
            <div>
              <Label htmlFor="section2Items">Lista de Itens (um por linha)</Label>
              <Textarea
                id="section2Items"
                name="section2Items"
                value={formData.section2Items}
                onChange={handleInputChange}
                className="mt-1"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Seção 3 - Relatórios</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="section3Title">Título da Seção</Label>
              <Input
                id="section3Title"
                name="section3Title"
                value={formData.section3Title}
                onChange={handleInputChange}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="section3Content">Descrição</Label>
              <Textarea
                id="section3Content"
                name="section3Content"
                value={formData.section3Content}
                onChange={handleInputChange}
                className="mt-1"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="section3Items">Lista de Itens (um por linha)</Label>
              <Textarea
                id="section3Items"
                name="section3Items"
                value={formData.section3Items}
                onChange={handleInputChange}
                className="mt-1"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Instructions Card */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-6">
          <h3 className="font-semibold text-blue-900 mb-2">💡 Dicas para edição</h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Use linguagem simples e direta para explicar as funcionalidades</li>
            <li>• Foque nos benefícios específicos para sua oficina</li>
            <li>• Mantenha as listas organizadas com • ou números</li>
            <li>• Teste regularmente como o conteúdo aparece na página pública</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}