import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Phone, Mail, MapPin, MessageCircle } from "lucide-react"; // Adicionado MessageCircle
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Contato() {
  const empresa = {
    nome: "AutoCheckin Soluções Digitais",
    telefone: "(11) 5555-4444", // Substituir
    linkTelefone: "tel:+551155554444",
    whatsapp: "(11) 99999-8888", // Substituir
    linkWhatsApp: `https://wa.me/5511999998888?text=${encodeURIComponent("Olá! Visitei a página de Contato do AutoCheckin e gostaria de mais informações.")}`,
    email: "contato@autocheckin.com.br", // Substituir
    linkEmail: "mailto:contato@autocheckin.com.br",
    endereco: "Rua da Tecnologia, 123, Sala 45, Bairro Inovação, São Paulo - SP, CEP 01010-010" // Substituir
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-teal-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Home
            </Button>
          </Link>
        </div>
        <Card className="shadow-xl overflow-hidden">
          <CardHeader className="bg-teal-600 text-white p-8 text-center">
            <CardTitle className="text-4xl font-bold">Entre em Contato</CardTitle>
            <p className="text-lg text-teal-100 mt-2">
              Estamos aqui para ajudar! Escolha a melhor forma de falar conosco.
            </p>
          </CardHeader>
          <CardContent className="p-8 sm:p-12">
            <div className="grid md:grid-cols-2 gap-10">
              {/* Informações de Contato */}
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold text-gray-800 border-b pb-2">Nossos Canais</h2>
                
                <div className="flex items-start gap-3">
                  <Phone className="w-6 h-6 text-teal-600 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-medium text-gray-700">Telefone Fixo</h3>
                    <a href={empresa.linkTelefone} className="text-teal-700 hover:text-teal-800 text-lg font-semibold">{empresa.telefone}</a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MessageCircle className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" /> {/* Icone do WhatsApp */}
                  <div>
                    <h3 className="font-medium text-gray-700">WhatsApp</h3>
                    <a href={empresa.linkWhatsApp} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:text-green-700 text-lg font-semibold">{empresa.whatsapp}</a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-6 h-6 text-teal-600 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-medium text-gray-700">Email</h3>
                    <a href={empresa.linkEmail} className="text-teal-700 hover:text-teal-800 text-lg font-semibold">{empresa.email}</a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-6 h-6 text-teal-600 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-medium text-gray-700">Endereço</h3>
                    <p className="text-gray-600">{empresa.endereco}</p>
                  </div>
                </div>
                 <p className="text-sm text-gray-500">
                    Horário de atendimento comercial: Seg-Sex, 9h às 18h.
                </p>
              </div>

              {/* Formulário Rápido (opcional, pode redirecionar para página de email) */}
              <div className="bg-gray-50 p-6 rounded-lg">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">Mensagem Rápida</h2>
                <p className="text-gray-600 mb-4">
                    Prefere enviar uma mensagem diretamente pela página de email?
                </p>
                <Link to={createPageUrl("Email")}>
                    <Button className="w-full bg-teal-600 hover:bg-teal-700">
                        Ir para Formulário de Email
                    </Button>
                </Link>
                 <p className="text-sm text-gray-500 mt-6">
                    Para dúvidas, sugestões ou propostas comerciais, nosso formulário de email é o canal mais indicado para um registro detalhado.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
         <p className="mt-8 text-center text-sm text-gray-500">
            (Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página, incluindo números e endereços.)
        </p>
      </div>
    </div>
  );
}