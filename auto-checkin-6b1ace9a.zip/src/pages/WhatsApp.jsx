import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageCircle, Copy, Phone, Clock } from "lucide-react";
import { WhatsAppConfig } from '@/api/entities';

export default function WhatsApp() {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  const companyId = "oficina-do-carlos-demo"; // Em produção, viria do contexto

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      setLoading(true);
      
      // Carregar configuração do banco de dados
      const configs = await WhatsAppConfig.filter({ companyId });
      
      if (configs.length > 0) {
        setConfig(configs[0]);
      } else {
        // Usar configurações padrão se não houver configuração salva
        setConfig({
          pageTitle: "Fale Conosco no WhatsApp",
          pageDescription: "Nossa equipe de especialistas está pronta para te atender! Clique no botão abaixo para iniciar uma conversa ou adicione nosso número.",
          phoneNumber: "5511999998888",
          phoneDisplayNumber: "+55 (11) 99999-8888",
          buttonText: "Iniciar Conversa Agora",
          businessHours: "Segunda a Sexta, das 9h às 18h",
          defaultMessage: "Olá! Gostaria de mais informações sobre o AutoCheckin.",
          additionalInfo: "(Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)"
        });
      }
    } catch (error) {
      console.error('Erro ao carregar configurações:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (config?.phoneDisplayNumber) {
      navigator.clipboard.writeText(config.phoneDisplayNumber)
        .then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        })
        .catch(err => console.error('Erro ao copiar:', err));
    }
  };

  const openWhatsApp = () => {
    if (config) {
      const whatsappLink = `https://wa.me/${config.phoneNumber}?text=${encodeURIComponent(config.defaultMessage)}`;
      window.open(whatsappLink, '_blank');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!config) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-4">
        <Card className="max-w-md text-center">
          <CardContent className="p-6">
            <MessageCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Configurações não encontradas.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-4">
      <Card className="max-w-md w-full shadow-xl">
        <CardHeader className="text-center pb-4">
          <MessageCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <CardTitle className="text-2xl font-bold text-gray-900">
            {config.pageTitle}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="text-center space-y-6">
          <p className="text-gray-700 leading-relaxed">
            {config.pageDescription}
          </p>
          
          <Button 
            onClick={openWhatsApp}
            className="w-full bg-green-500 hover:bg-green-600 text-white py-3 text-lg font-semibold"
            size="lg"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            {config.buttonText}
          </Button>
          
          <div className="space-y-3">
            <p className="text-gray-600 text-sm">Ou adicione nosso número:</p>
            <div className="flex items-center justify-center gap-2 p-3 bg-gray-100 rounded-lg">
              <Phone className="w-4 h-4 text-green-600" />
              <span className="font-mono text-green-700 font-semibold">
                {config.phoneDisplayNumber}
              </span>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={copyToClipboard}
                className="ml-2 p-1 h-auto"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            {copied && (
              <p className="text-green-600 text-xs">Número copiado!</p>
            )}
          </div>
          
          <div className="flex items-center justify-center gap-2 text-gray-500 text-sm">
            <Clock className="w-4 h-4" />
            <span>Horário de atendimento: {config.businessHours}</span>
          </div>
          
          {config.additionalInfo && (
            <p className="text-xs text-gray-400 italic">
              {config.additionalInfo}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}