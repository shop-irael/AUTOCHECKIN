import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Newspaper, Search, CalendarDays, Tag } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const blogPostsData = [
  {
    id: 1,
    title: "5 Dicas para Modernizar o Atendimento da Sua Oficina Mecânica",
    date: "15 de Julho, 2025",
    category: "Gestão de Oficina",
    excerpt: "Descubra estratégias simples e eficazes para otimizar a recepção de veículos, melhorar a comunicação com clientes e aumentar a satisfação...",
    imageUrl: "https://images.unsplash.com/photo-1559047366-73045003b88b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2FyJTIwcmVwYWlyJTIwc2hvcHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60",
    slug: "dicas-modernizar-atendimento-oficina"
  },
  {
    id: 2,
    title: "A Importância do Histórico do Veículo para Fidelizar Clientes",
    date: "02 de Julho, 2025",
    category: "Fidelização",
    excerpt: "Um histórico bem documentado não só ajuda no diagnóstico, mas também transmite profissionalismo e confiança, incentivando o cliente a retornar...",
    imageUrl: "https://images.unsplash.com/photo-1605648515103-2b5f5ac03544?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGNhciUyMG1haW50ZW5hbmNlfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60",
    slug: "importancia-historico-veiculo-fidelizar"
  },
  {
    id: 3,
    title: "Check-in Digital vs. Papel: Vantagens e Desvantagens",
    date: "20 de Junho, 2025",
    category: "Tecnologia",
    excerpt: "Analisamos os prós e contras de cada método de recepção de veículos para ajudar você a decidir qual o melhor para sua oficina...",
    imageUrl: "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8ZGlnaXRhbCUyMHRlY2hub2xvZ3l8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60",
    slug: "checkin-digital-vs-papel"
  }
];

export default function Blog() {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredPosts = blogPostsData.filter(post =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-orange-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Home
            </Button>
          </Link>
        </div>
        
        <header className="text-center mb-10">
            <Newspaper className="w-16 h-16 text-orange-600 mx-auto mb-4" />
            <h1 className="text-4xl font-bold text-gray-900 mb-3">Blog AutoCheckin</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Dicas, novidades e insights para otimizar a gestão da sua oficina automotiva.
            </p>
        </header>

        <div className="mb-8 relative max-w-lg mx-auto">
            <Input 
              type="text"
              placeholder="Buscar artigos..."
              className="pl-10 pr-4 py-3 text-lg border-2 focus:border-orange-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        </div>

        {filteredPosts.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map(post => (
              <Card key={post.id} className="flex flex-col overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
                <img src={post.imageUrl} alt={post.title} className="h-48 w-full object-cover" />
                <CardHeader>
                  <CardTitle className="text-xl font-semibold text-gray-900 hover:text-orange-700">
                    {/* <Link to={createPageUrl(`BlogPostPage?slug=${post.slug}`)}> {post.title} </Link> */}
                    {/* Criar página individual de post de blog seria um próximo passo */}
                    <a href="#" onClick={(e) => {e.preventDefault(); alert(`Navegar para o post: ${post.title}`)}}>{post.title}</a>
                  </CardTitle>
                  <CardDescription className="mt-1">
                    <div className="flex items-center text-xs text-gray-500 gap-4">
                      <span className="flex items-center gap-1"><CalendarDays className="w-3 h-3" />{post.date}</span>
                      <span className="flex items-center gap-1"><Tag className="w-3 h-3" /><Badge variant="outline" className="text-xs">{post.category}</Badge></span>
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-sm text-gray-600 leading-relaxed">{post.excerpt}</p>
                </CardContent>
                <CardFooter>
                   {/* <Link to={createPageUrl(`BlogPostPage?slug=${post.slug}`)}> */}
                   <a href="#" onClick={(e) => {e.preventDefault(); alert(`Navegar para o post: ${post.title}`)}}>
                    <Button variant="outline" className="text-orange-600 border-orange-500 hover:bg-orange-50 w-full">
                        Ler Mais
                    </Button>
                   </a>
                   {/* </Link> */}
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <p className="text-gray-600 text-center py-10 text-lg">Nenhum artigo encontrado com os termos buscados.</p>
        )}
        <p className="mt-12 text-center text-sm text-gray-500">
            (Este é um conteúdo de exemplo com posts fictícios. O administrador pode solicitar a edição completa desta página e a criação de posts reais.)
        </p>
      </div>
    </div>
  );
}