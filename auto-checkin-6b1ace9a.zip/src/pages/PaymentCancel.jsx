import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function PaymentCancel() {
    return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
            <Card className="max-w-md w-full text-center shadow-lg">
                <CardHeader>
                    <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                    <CardTitle className="text-2xl">Pagamento Cancelado</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                    <p className="text-gray-600 mb-6">
                        A sua transação foi cancelada. Você não foi cobrado. Se isso foi um erro, por favor, tente novamente.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                        <Link to={createPageUrl('Precos')}>
                            <Button variant="outline" className="w-full">Ver Planos Novamente</Button>
                        </Link>
                        <Link to={createPageUrl('Dashboard')}>
                            <Button className="w-full">Ir para o Painel</Button>
                        </Link>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}