
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Eye, CalendarCheck, Users, MonitorPlay, Trash2, PlusCircle } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function EditDemo() {
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    pageTitle: "Agende uma Demonstração Gratuita do AutoCheckin",
    pageSubtitle: "Veja na prática como nossa plataforma pode revolucionar a gestão da sua oficina. Sem compromisso!",
    
    formTitle: "Solicite sua Demo Personalizada",
    formDescription: "Preencha o formulário abaixo e um de nossos especialistas entrará em contato para agendar uma apresentação exclusiva para sua oficina.",
    
    benefitsTitle: "O que você verá na Demonstração:",
    benefits: [
      "Como funciona o check-in digital via QR Code e link.",
      "Acompanhamento do histórico de veículos e serviços.",
      "Geração de relatórios e métricas importantes.",
      "Funcionalidades de assinatura digital e upload de fotos.",
      "Como o AutoCheckin pode economizar tempo e reduzir erros.",
      "Esclarecimento de todas as suas dúvidas ao vivo."
    ],
    
    ctaButtonText: "Quero Agendar Minha Demo!",
    
    contactInfoTitle: "Prefere falar conosco diretamente?",
    contactPhone: "(11) 98765-4321",
    contactEmail: "demo@autocheckin.com.br",

    // Campos para o formulário de solicitação de demo
    // (A lógica de envio do formulário precisaria de integrações ou uma entidade)
    formFieldsEnabled: true, // Controla se o formulário é exibido
    requestEmailNotification: "seu_email_para_notificacoes_de_demo@empresa.com"
  });

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleBenefitChange = (index, value) => {
    const newBenefits = [...formData.benefits];
    newBenefits[index] = value;
    setFormData(prev => ({ ...prev, benefits: newBenefits }));
  };

  const addBenefit = () => {
    setFormData(prev => ({ ...prev, benefits: [...prev.benefits, ""] }));
  };

  const removeBenefit = (index) => {
    const newBenefits = [...formData.benefits];
    newBenefits.splice(index, 1);
    setFormData(prev => ({ ...prev, benefits: newBenefits }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Simulação de salvamento
      // await ContentPage.update('demo', formData);
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Página de Demonstração salva com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar página de Demonstração:', error);
      alert('Erro ao salvar. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Settings")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Configurações
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Editar Página de Demonstração</h1>
            <p className="text-gray-600 mt-1">Configure o conteúdo e o formulário da sua página de agendamento de demo</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to={createPageUrl("Demo")} target="_blank">
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visualizar
            </Button>
          </Link>
          <Button 
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </Button>
        </div>
      </div>

      {/* Page Header Content */}
      <Card>
        <CardHeader><CardTitle>Conteúdo Principal da Página</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="pageTitle">Título Principal</Label>
            <Input id="pageTitle" name="pageTitle" value={formData.pageTitle} onChange={handleInputChange} />
          </div>
          <div>
            <Label htmlFor="pageSubtitle">Subtítulo</Label>
            <Textarea id="pageSubtitle" name="pageSubtitle" value={formData.pageSubtitle} onChange={handleInputChange} rows={2}/>
          </div>
        </CardContent>
      </Card>

      {/* Form Section */}
      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><CalendarCheck className="w-5 h-5"/> Seção do Formulário de Solicitação</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <input type="checkbox" id="formFieldsEnabled" name="formFieldsEnabled" checked={formData.formFieldsEnabled} onChange={handleInputChange} className="form-checkbox h-5 w-5 text-blue-600"/>
            <Label htmlFor="formFieldsEnabled" className="font-medium">Habilitar Formulário de Solicitação de Demo na Página?</Label>
          </div>
          {formData.formFieldsEnabled && (
            <>
              <div>
                <Label htmlFor="formTitle">Título do Formulário</Label>
                <Input id="formTitle" name="formTitle" value={formData.formTitle} onChange={handleInputChange} />
              </div>
              <div>
                <Label htmlFor="formDescription">Descrição do Formulário</Label>
                <Textarea id="formDescription" name="formDescription" value={formData.formDescription} onChange={handleInputChange} rows={2}/>
              </div>
               <div>
                <Label htmlFor="requestEmailNotification">Email para Receber Notificações de Novas Solicitações</Label>
                <Input type="email" id="requestEmailNotification" name="requestEmailNotification" value={formData.requestEmailNotification} onChange={handleInputChange} placeholder="seu-email@suaoficina.com"/>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Benefits Section */}
      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><MonitorPlay className="w-5 h-5"/> Benefícios da Demonstração</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="benefitsTitle">Título da Seção de Benefícios</Label>
            <Input id="benefitsTitle" name="benefitsTitle" value={formData.benefitsTitle} onChange={handleInputChange} />
          </div>
          <div>
            <Label>Lista de Benefícios (o que será mostrado na demo)</Label>
            {formData.benefits.map((benefit, index) => (
              <div key={index} className="flex items-center gap-2 mt-1">
                <Input value={benefit} onChange={(e) => handleBenefitChange(index, e.target.value)} />
                <Button variant="ghost" size="sm" onClick={() => removeBenefit(index)} className="text-red-500 hover:text-red-700">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={addBenefit} className="mt-2 flex items-center gap-1">
              <PlusCircle className="w-3 h-3"/> Adicionar Benefício
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* CTA and Contact Info */}
      <Card>
        <CardHeader><CardTitle>Chamada para Ação e Contato Alternativo</CardTitle></CardHeader>
        <CardContent className="space-y-4">
           <div>
            <Label htmlFor="ctaButtonText">Texto do Botão Principal de Agendamento</Label>
            <Input id="ctaButtonText" name="ctaButtonText" value={formData.ctaButtonText} onChange={handleInputChange} />
          </div>
          <div>
            <Label htmlFor="contactInfoTitle">Título para Contato Alternativo</Label>
            <Input id="contactInfoTitle" name="contactInfoTitle" value={formData.contactInfoTitle} onChange={handleInputChange} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="contactPhone">Telefone para Contato Direto</Label>
              <Input id="contactPhone" name="contactPhone" value={formData.contactPhone} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="contactEmail">Email para Contato Direto</Label>
              <Input type="email" id="contactEmail" name="contactEmail" value={formData.contactEmail} onChange={handleInputChange} />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
