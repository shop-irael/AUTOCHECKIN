import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Eye, PlusCircle, Trash2, HelpCircle, MessageSquare, Phone } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function EditCentralAjuda() {
  const [saving, setSaving] = useState(false);
  const [pageData, setPageData] = useState({
    pageTitle: "Central de Ajuda AutoCheckin",
    pageSubtitle: "Encontre respostas para suas dúvidas mais frequentes e saiba como aproveitar ao máximo nossa plataforma.",
    searchPlaceholder: "Digite sua dúvida aqui...",
  });
  const [faqs, setFaqs] = useState([
    {
      id: '1',
      question: "Como funciona o check-in digital com QR Code?",
      answer: "É simples! O cliente escaneia o QR Code com o celular, preenche um formulário rápido com os dados do veículo e os serviços desejados. Todas as informações chegam instantaneamente para a oficina."
    },
    {
      id: '2',
      question: "Posso personalizar o formulário de check-in?",
      answer: "Sim! Nos planos Intermediário e Pro, você pode adicionar ou remover campos do formulário para adaptá-lo perfeitamente às necessidades da sua oficina."
    },
    {
      id: '3',
      question: "As fotos dos veículos ficam armazenadas com segurança?",
      answer: "Com certeza. Todas as fotos enviadas durante o check-in são armazenadas em nuvem com protocolos de segurança avançados, vinculadas ao histórico do veículo."
    },
    {
      id: '4',
      question: "Como acesso o histórico de um veículo específico?",
      answer: "No seu painel administrativo, vá até a seção 'Histórico de Veículos' e busque pela placa. Você terá acesso a todos os check-ins, serviços realizados, fotos e observações daquele veículo."
    }
  ]);
  const [contactSection, setContactSection] = useState({
    title: "Ainda precisa de ajuda?",
    description: "Se não encontrou a resposta que procurava, nossa equipe de suporte está pronta para te atender.",
    phone: "(11) 1234-5678",
    email: "suporte@autocheckin.com.br",
    whatsapp: "(11) 91234-5678",
    chatEnabled: true,
  });


  const handlePageDataChange = (e) => {
    const { name, value } = e.target;
    setPageData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleContactSectionChange = (e) => {
    const { name, value, type, checked } = e.target;
    setContactSection(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleFaqChange = (index, field, value) => {
    const newFaqs = [...faqs];
    newFaqs[index][field] = value;
    setFaqs(newFaqs);
  };

  const addFaq = () => {
    setFaqs([...faqs, { id: Date.now().toString(), question: "", answer: "" }]);
  };

  const removeFaq = (index) => {
    const newFaqs = [...faqs];
    newFaqs.splice(index, 1);
    setFaqs(newFaqs);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Simulação de salvamento
      // await ContentPage.update('central-ajuda', { pageData, faqs, contactSection });
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Central de Ajuda salva com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar Central de Ajuda:', error);
      alert('Erro ao salvar. Tente novamente.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to={createPageUrl("Settings")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Configurações
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Editar Central de Ajuda (FAQ)</h1>
            <p className="text-gray-600 mt-1">Gerencie as perguntas frequentes e informações de suporte</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to={createPageUrl("CentralAjuda")} target="_blank">
            <Button variant="outline" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Visualizar
            </Button>
          </Link>
          <Button 
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Salvando...' : 'Salvar Alterações'}
          </Button>
        </div>
      </div>

      {/* Page Header Content */}
      <Card>
        <CardHeader><CardTitle>Informações Gerais da Página</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="pageTitleP">Título Principal</Label>
            <Input id="pageTitleP" name="pageTitle" value={pageData.pageTitle} onChange={handlePageDataChange} />
          </div>
          <div>
            <Label htmlFor="pageSubtitleP">Subtítulo</Label>
            <Textarea id="pageSubtitleP" name="pageSubtitle" value={pageData.pageSubtitle} onChange={handlePageDataChange} rows={2}/>
          </div>
          <div>
            <Label htmlFor="searchPlaceholderP">Texto do Campo de Busca (Placeholder)</Label>
            <Input id="searchPlaceholderP" name="searchPlaceholder" value={pageData.searchPlaceholder} onChange={handlePageDataChange} />
          </div>
        </CardContent>
      </Card>

      {/* FAQs Editor */}
      <Card>
        <CardHeader className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2"><HelpCircle className="w-5 h-5"/> Perguntas Frequentes (FAQ)</CardTitle>
          <Button onClick={addFaq} className="flex items-center gap-1">
            <PlusCircle className="w-4 h-4"/> Adicionar Pergunta
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {faqs.length === 0 && <p className="text-center text-gray-500 py-4">Nenhuma pergunta adicionada.</p>}
          {faqs.map((faq, index) => (
            <Card key={faq.id} className="p-4">
              <div className="flex justify-between items-center mb-2">
                <Label className="text-base">Pergunta {index + 1}</Label>
                <Button variant="ghost" size="sm" onClick={() => removeFaq(index)} className="text-red-500 hover:text-red-700">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              <div className="space-y-2">
                <div>
                  <Label htmlFor={`faqQuestion-${index}`}>Pergunta</Label>
                  <Input id={`faqQuestion-${index}`} value={faq.question} onChange={(e) => handleFaqChange(index, 'question', e.target.value)} />
                </div>
                <div>
                  <Label htmlFor={`faqAnswer-${index}`}>Resposta</Label>
                  <Textarea id={`faqAnswer-${index}`} value={faq.answer} onChange={(e) => handleFaqChange(index, 'answer', e.target.value)} rows={3}/>
                </div>
              </div>
            </Card>
          ))}
        </CardContent>
      </Card>
      
      {/* Contact Section Editor */}
      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><MessageSquare className="w-5 h-5"/> Seção "Ainda precisa de ajuda?"</CardTitle></CardHeader>
        <CardContent className="space-y-4">
           <div>
            <Label htmlFor="contactTitleS">Título da Seção</Label>
            <Input id="contactTitleS" name="title" value={contactSection.title} onChange={handleContactSectionChange} />
          </div>
          <div>
            <Label htmlFor="contactDescriptionS">Descrição da Seção</Label>
            <Textarea id="contactDescriptionS" name="description" value={contactSection.description} onChange={handleContactSectionChange} rows={2}/>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="contactPhoneS">Telefone de Suporte</Label>
              <Input id="contactPhoneS" name="phone" value={contactSection.phone} onChange={handleContactSectionChange} />
            </div>
            <div>
              <Label htmlFor="contactEmailS">Email de Suporte</Label>
              <Input type="email" id="contactEmailS" name="email" value={contactSection.email} onChange={handleContactSectionChange} />
            </div>
             <div>
              <Label htmlFor="contactWhatsappS">WhatsApp de Suporte</Label>
              <Input id="contactWhatsappS" name="whatsapp" value={contactSection.whatsapp} onChange={handleContactSectionChange} />
            </div>
          </div>
           <div className="flex items-center space-x-2">
            <input type="checkbox" id="chatEnabledS" name="chatEnabled" checked={contactSection.chatEnabled} onChange={handleContactSectionChange} className="form-checkbox h-5 w-5 text-blue-600"/>
            <Label htmlFor="chatEnabledS" className="font-medium">Habilitar opção de Chat ao Vivo (se disponível)?</Label>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}