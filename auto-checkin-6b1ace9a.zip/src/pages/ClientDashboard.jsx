
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Checkin } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Car, 
  ClipboardList, 
  Clock, 
  CheckCircle, 
  LogOut, 
  Plus,
  Wrench,
  Loader2
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function ClientDashboard() {
  const [user, setUser] = useState(null);
  const [myCheckins, setMyCheckins] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const loadClientData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        const checkinsData = await Checkin.filter({ clientId: currentUser.id }, '-created_date');
        setMyCheckins(checkinsData);

      } catch (error) {
        console.error('Erro ao carregar dados do cliente:', error);
        // Se não estiver logado, volta pra home
        navigate(createPageUrl('Home'));
      } finally {
        setLoading(false);
      }
    };

    loadClientData();
  }, [navigate]);

  const handleLogout = async () => {
    try {
      await User.logout();
      window.location.href = createPageUrl('Home');
    } catch (error) {
      console.error("Erro no logout:", error);
      alert("Erro ao tentar fazer logout. Tente novamente.");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending_confirmation': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'confirmed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in_service': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'pending_confirmation': return 'Pendente';
      case 'confirmed': return 'Confirmado';
      case 'in_service': return 'Em Serviço';
      case 'completed': return 'Concluído';
      case 'cancelled': return 'Cancelado';
      default: return status;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header do Cliente */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14 sm:h-16">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
                <Car className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
              </div>
              <h1 className="text-lg sm:text-xl font-bold text-gray-800">Meu Painel</h1>
            </div>
            <div className="flex items-center gap-2 sm:gap-4">
              <span className="text-sm sm:text-base text-gray-700 hidden sm:block">
                Olá, {user?.full_name.split(' ')[0]}
              </span>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleLogout} 
                className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm px-2 sm:px-3"
              >
                <LogOut className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Sair</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo do Painel */}
      <main className="max-w-5xl mx-auto p-3 sm:p-4 lg:p-6 space-y-4 sm:space-y-6">
        <Card className="bg-white">
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="text-lg sm:text-xl">Bem-vindo, {user?.full_name}!</CardTitle>
          </CardHeader>
          <CardContent className="p-4 sm:p-6 pt-0">
            <p className="text-sm sm:text-base text-gray-600 mb-4">
              Aqui você pode acompanhar o status dos seus serviços e solicitar novos check-ins de forma rápida e fácil.
            </p>
            <Link to={createPageUrl("CheckinForm")}>
              <Button className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto">
                <Plus className="w-4 h-4 mr-2" />
                Criar Novo Check-in
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <ClipboardList className="w-4 h-4 sm:w-5 sm:h-5" />
              Meus Check-ins ({myCheckins.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 sm:p-6 pt-0">
            {myCheckins.length === 0 ? (
              <div className="text-center py-6 sm:py-8">
                <Car className="w-10 h-10 sm:w-12 sm:h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-sm sm:text-base text-gray-500">Você ainda não possui nenhum check-in registrado.</p>
              </div>
            ) : (
              <div className="space-y-3 sm:space-y-4">
                {myCheckins.map((checkin) => (
                  <div key={checkin.id} className="border rounded-lg p-3 sm:p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex flex-col space-y-2 sm:space-y-0 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mb-2">
                          <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                            {checkin.vehicleModel} ({checkin.vehiclePlate})
                          </h3>
                          <Badge className={`${getStatusColor(checkin.status)} text-xs w-fit`}>
                            {getStatusText(checkin.status)}
                          </Badge>
                        </div>
                        <p className="text-xs sm:text-sm text-gray-600 flex items-center gap-1">
                          <Wrench className="w-3 h-3" /> 
                          {checkin.selectedServiceIds?.length || 0} serviços solicitados
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {format(new Date(checkin.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-500">
                        {checkin.status === 'in_service' && <Clock className="w-3 h-3 sm:w-4 sm:h-4 text-purple-600" />}
                        {checkin.status === 'completed' && <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-green-600" />}
                        <span className="font-medium">{getStatusText(checkin.status)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
