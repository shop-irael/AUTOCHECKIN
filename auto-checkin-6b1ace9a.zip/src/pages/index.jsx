import Layout from "./Layout.jsx";

import Home from "./Home";

import CheckinForm from "./CheckinForm";

import Dashboard from "./Dashboard";

import CheckinList from "./CheckinList";

import VehicleHistory from "./VehicleHistory";

import ServiceManagement from "./ServiceManagement";

import Reports from "./Reports";

import Settings from "./Settings";

import Funcionalidades from "./Funcionalidades";

import Precos from "./Precos";

import Demo from "./Demo";

import CentralAjuda from "./CentralAjuda";

import WhatsApp from "./WhatsApp";

import Email from "./Email";

import Sobre from "./Sobre";

import Blog from "./Blog";

import Contato from "./Contato";

import EditFuncionalidades from "./EditFuncionalidades";

import EditContato from "./EditContato";

import EditPrecos from "./EditPrecos";

import EditSobre from "./EditSobre";

import EditBlog from "./EditBlog";

import EditDemo from "./EditDemo";

import EditCentralAjuda from "./EditCentralAjuda";

import DemoRequests from "./DemoRequests";

import PostLogin from "./PostLogin";

import ClientDashboard from "./ClientDashboard";

import EditWhatsApp from "./EditWhatsApp";

import PaymentSuccess from "./PaymentSuccess";

import PaymentCancel from "./PaymentCancel";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    CheckinForm: CheckinForm,
    
    Dashboard: Dashboard,
    
    CheckinList: CheckinList,
    
    VehicleHistory: VehicleHistory,
    
    ServiceManagement: ServiceManagement,
    
    Reports: Reports,
    
    Settings: Settings,
    
    Funcionalidades: Funcionalidades,
    
    Precos: Precos,
    
    Demo: Demo,
    
    CentralAjuda: CentralAjuda,
    
    WhatsApp: WhatsApp,
    
    Email: Email,
    
    Sobre: Sobre,
    
    Blog: Blog,
    
    Contato: Contato,
    
    EditFuncionalidades: EditFuncionalidades,
    
    EditContato: EditContato,
    
    EditPrecos: EditPrecos,
    
    EditSobre: EditSobre,
    
    EditBlog: EditBlog,
    
    EditDemo: EditDemo,
    
    EditCentralAjuda: EditCentralAjuda,
    
    DemoRequests: DemoRequests,
    
    PostLogin: PostLogin,
    
    ClientDashboard: ClientDashboard,
    
    EditWhatsApp: EditWhatsApp,
    
    PaymentSuccess: PaymentSuccess,
    
    PaymentCancel: PaymentCancel,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/CheckinForm" element={<CheckinForm />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/CheckinList" element={<CheckinList />} />
                
                <Route path="/VehicleHistory" element={<VehicleHistory />} />
                
                <Route path="/ServiceManagement" element={<ServiceManagement />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Funcionalidades" element={<Funcionalidades />} />
                
                <Route path="/Precos" element={<Precos />} />
                
                <Route path="/Demo" element={<Demo />} />
                
                <Route path="/CentralAjuda" element={<CentralAjuda />} />
                
                <Route path="/WhatsApp" element={<WhatsApp />} />
                
                <Route path="/Email" element={<Email />} />
                
                <Route path="/Sobre" element={<Sobre />} />
                
                <Route path="/Blog" element={<Blog />} />
                
                <Route path="/Contato" element={<Contato />} />
                
                <Route path="/EditFuncionalidades" element={<EditFuncionalidades />} />
                
                <Route path="/EditContato" element={<EditContato />} />
                
                <Route path="/EditPrecos" element={<EditPrecos />} />
                
                <Route path="/EditSobre" element={<EditSobre />} />
                
                <Route path="/EditBlog" element={<EditBlog />} />
                
                <Route path="/EditDemo" element={<EditDemo />} />
                
                <Route path="/EditCentralAjuda" element={<EditCentralAjuda />} />
                
                <Route path="/DemoRequests" element={<DemoRequests />} />
                
                <Route path="/PostLogin" element={<PostLogin />} />
                
                <Route path="/ClientDashboard" element={<ClientDashboard />} />
                
                <Route path="/EditWhatsApp" element={<EditWhatsApp />} />
                
                <Route path="/PaymentSuccess" element={<PaymentSuccess />} />
                
                <Route path="/PaymentCancel" element={<PaymentCancel />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}