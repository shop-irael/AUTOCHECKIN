import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkin, Servico } from '@/api/entities';
import { 
  ClipboardList, 
  Car,
  Download,
  Eye,
  User,
  Phone,
  Calendar,
  FileText,
  Image as ImageIcon,
  Edit,
  X
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function CheckinList() {
  const [checkins, setCheckins] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCheckin, setSelectedCheckin] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [checkinsData, servicesData] = await Promise.all([
        Checkin.list('-created_date'),
        Servico.list()
      ]);
      setCheckins(checkinsData);
      setServices(servicesData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (checkin) => {
    setSelectedCheckin(checkin);
    setShowModal(true);
  };

  const getServiceNames = (serviceIds) => {
    if (!serviceIds || serviceIds.length === 0) return [];
    return serviceIds
      .map(id => services.find(s => s.id === id))
      .filter(service => service)
      .map(service => service.name);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending_confirmation': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'confirmed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in_service': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'pending_confirmation': return 'Pendente';
      case 'confirmed': return 'Confirmado';
      case 'in_service': return 'Em Serviço';
      case 'completed': return 'Concluído';
      case 'cancelled': return 'Cancelado';
      default: return status;
    }
  };

  const exportCheckins = () => {
    const csvContent = [
      ['Data', 'Cliente', 'Telefone', 'Placa', 'Veículo', 'Status', 'Serviços'],
      ...checkins.map(checkin => [
        format(new Date(checkin.created_date), 'dd/MM/yyyy HH:mm'),
        checkin.clientName,
        checkin.clientPhone,
        checkin.vehiclePlate,
        `${checkin.vehicleModel} ${checkin.vehicleYear}`,
        getStatusText(checkin.status),
        getServiceNames(checkin.selectedServiceIds).join('; ')
      ])
    ].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `checkins-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="space-y-6">
          <Card className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-8 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Check-ins</h1>
          <p className="text-gray-600 mt-1">Gerencie todos os check-ins recebidos</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="flex items-center gap-2" onClick={exportCheckins}>
            <Download className="w-4 h-4" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Check-ins List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ClipboardList className="w-5 h-5" />
            Check-ins ({checkins.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {checkins.length === 0 ? (
            <div className="text-center py-8">
              <Car className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Nenhum check-in encontrado</p>
            </div>
          ) : (
            <div className="space-y-4">
              {checkins.map((checkin) => (
                <div key={checkin.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-gray-900">{checkin.clientName}</h3>
                        <Badge className={getStatusColor(checkin.status)}>
                          {getStatusText(checkin.status)}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-1">
                        {checkin.vehiclePlate} • {checkin.vehicleModel} {checkin.vehicleYear}
                      </p>
                      <p className="text-xs text-gray-500">
                        {format(new Date(checkin.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleViewDetails(checkin)}
                      className="flex items-center gap-2"
                    >
                      <Eye className="w-4 h-4" />
                      Ver Detalhes
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Detalhes */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Detalhes do Check-in - {selectedCheckin?.clientName}
            </DialogTitle>
          </DialogHeader>
          
          {selectedCheckin && (
            <div className="space-y-6">
              {/* Informações do Cliente */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <User className="w-5 h-5" />
                    Dados do Cliente
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Nome</Label>
                    <p className="text-gray-900">{selectedCheckin.clientName}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Telefone</Label>
                    <p className="text-gray-900">{selectedCheckin.clientPhone}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Informações do Veículo */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Car className="w-5 h-5" />
                    Dados do Veículo
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Placa</Label>
                    <p className="text-gray-900 font-mono">{selectedCheckin.vehiclePlate}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Modelo</Label>
                    <p className="text-gray-900">{selectedCheckin.vehicleModel}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Ano</Label>
                    <p className="text-gray-900">{selectedCheckin.vehicleYear}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Cor</Label>
                    <p className="text-gray-900">{selectedCheckin.vehicleColor}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Serviços Solicitados */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Edit className="w-5 h-5" />
                    Serviços Solicitados
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedCheckin.selectedServiceIds && selectedCheckin.selectedServiceIds.length > 0 ? (
                    <div className="space-y-2">
                      {getServiceNames(selectedCheckin.selectedServiceIds).map((serviceName, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          <span>{serviceName}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500">Nenhum serviço selecionado</p>
                  )}
                </CardContent>
              </Card>

              {/* Fotos do Veículo */}
              {selectedCheckin.photoUrls && selectedCheckin.photoUrls.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <ImageIcon className="w-5 h-5" />
                      Fotos do Veículo ({selectedCheckin.photoUrls.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {selectedCheckin.photoUrls.map((photoUrl, index) => (
                        <div key={index} className="aspect-square">
                          <img 
                            src={photoUrl} 
                            alt={`Foto ${index + 1}`}
                            className="w-full h-full object-cover rounded-lg border hover:scale-105 transition-transform cursor-pointer"
                            onClick={() => window.open(photoUrl, '_blank')}
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Assinatura */}
              {selectedCheckin.signatureUrl && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Edit className="w-5 h-5" />
                      Assinatura Digital
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="border rounded-lg p-4 bg-gray-50 inline-block">
                      <img 
                        src={selectedCheckin.signatureUrl} 
                        alt="Assinatura"
                        className="max-w-xs h-auto"
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Observações */}
              {selectedCheckin.observations && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <FileText className="w-5 h-5" />
                      Observações
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700">{selectedCheckin.observations}</p>
                  </CardContent>
                </Card>
              )}

              {/* Informações do Check-in */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Calendar className="w-5 h-5" />
                    Informações do Check-in
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Status</Label>
                    <div className="mt-1">
                      <Badge className={getStatusColor(selectedCheckin.status)}>
                        {getStatusText(selectedCheckin.status)}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Data do Check-in</Label>
                    <p className="text-gray-900">
                      {format(new Date(selectedCheckin.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Label({ children, className }) {
  return <label className={`block text-sm font-medium ${className || ''}`}>{children}</label>;
}