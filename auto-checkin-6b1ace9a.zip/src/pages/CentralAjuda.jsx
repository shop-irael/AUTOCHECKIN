import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Search, ChevronDown, ChevronUp, LifeBuoy } from "lucide-react";
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const FAQItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between items-center w-full py-4 text-left hover:bg-gray-50 px-2 rounded"
      >
        <span className="font-medium text-gray-800">{question}</span>
        {isOpen ? <ChevronUp className="w-5 h-5 text-blue-600" /> : <ChevronDown className="w-5 h-5 text-gray-500" />}
      </button>
      {isOpen && <div className="pb-4 px-2 text-gray-600 leading-relaxed">{answer}</div>}
    </div>
  );
};

export default function CentralAjuda() {
  const faqs = [
    {
      question: "Como configuro minha oficina no AutoCheckin?",
      answer: "Após criar sua conta, acesse a aba 'Configurações' no painel administrativo. Lá você poderá inserir os dados da sua oficina, personalizar o formulário de check-in e configurar os serviços oferecidos. Nosso time de suporte também está disponível para auxiliar nesse processo inicial."
    },
    {
      question: "Como meus clientes fazem o check-in digital?",
      answer: "Seus clientes podem fazer o check-in de duas formas principais: escaneando o QR Code exclusivo da sua oficina (que você pode imprimir e exibir na recepção) ou através de um link direto que você pode compartilhar por WhatsApp, SMS, email ou em suas redes sociais."
    },
    {
      question: "O AutoCheckin tem integração com outros sistemas de gestão?",
      answer: "No plano Pro, oferecemos acesso à nossa API, que permite a integração do AutoCheckin com outros sistemas de gestão de oficinas (ERPs), CRM ou ferramentas de marketing que sua oficina já utiliza. Consulte nossa equipe técnica para mais detalhes sobre as possibilidades de integração."
    },
    {
      question: "Quais são as formas de pagamento dos planos?",
      answer: "Atualmente, aceitamos pagamentos via cartão de crédito (principais bandeiras) e boleto bancário para planos mensais ou anuais. Os pagamentos são processados de forma segura através de nosso parceiro de pagamentos."
    },
    {
      question: "Posso cancelar meu plano a qualquer momento?",
      answer: "Sim, você pode cancelar seu plano a qualquer momento, sem multas ou taxas de cancelamento. O acesso às funcionalidades do plano permanecerá ativo até o final do período já pago."
    }
  ];

  const [searchTerm, setSearchTerm] = useState('');
  const filteredFaqs = faqs.filter(faq => 
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-blue-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Voltar para Home
            </Button>
          </Link>
        </div>
        <div className="bg-white p-8 sm:p-12 shadow-xl rounded-lg">
          <header className="text-center mb-10">
            <LifeBuoy className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <h1 className="text-4xl font-bold text-gray-900 mb-3">Central de Ajuda</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Encontre respostas para suas dúvidas ou entre em contato com nosso suporte.
            </p>
          </header>

          <div className="mb-8 relative">
            <Input 
              type="text"
              placeholder="Digite sua dúvida para buscar..."
              className="pl-10 pr-4 py-3 text-lg border-2 focus:border-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          </div>
          
          <div className="mb-10">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Perguntas Frequentes (FAQ)</h2>
            {filteredFaqs.length > 0 ? (
              <div className="space-y-1">
                {filteredFaqs.map((faq, index) => (
                  <FAQItem key={index} question={faq.question} answer={faq.answer} />
                ))}
              </div>
            ) : (
              <p className="text-gray-600 text-center py-4">Nenhuma pergunta encontrada com o termo "{searchTerm}".</p>
            )}
          </div>

          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-700">Ainda precisa de ajuda?</CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-lg text-gray-800 mb-2">Suporte via WhatsApp</h3>
                <p className="text-gray-600 mb-3">Converse diretamente com nossa equipe de suporte para um atendimento rápido e personalizado.</p>
                <a href={createPageUrl("WhatsApp")}>
                    <Button className="bg-green-500 hover:bg-green-600 text-white">
                        Falar no WhatsApp
                    </Button>
                </a>
              </div>
              <div>
                <h3 className="font-semibold text-lg text-gray-800 mb-2">Suporte via Email</h3>
                <p className="text-gray-600 mb-3">Prefere nos contatar por email? Envie sua dúvida e responderemos o mais breve possível.</p>
                <a href={createPageUrl("Email")}>
                    <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-100">
                        Enviar Email
                    </Button>
                </a>
              </div>
            </CardContent>
          </Card>
          <p className="mt-8 text-center text-sm text-gray-500">
            (Este é um conteúdo de exemplo. O administrador pode solicitar a edição completa desta página.)
          </p>
        </div>
      </div>
    </div>
  );
}