import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Company } from '@/api/entities';
import { 
  QrCode, 
  Download, 
  Share2, 
  Copy,
  ExternalLink,
  Smartphone
} from 'lucide-react';

export default function QRCodeGenerator() {
  const [company, setCompany] = useState(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef(null);

  const companyId = "oficina-do-carlos-demo";
  const baseUrl = window.location.origin;
  const checkinUrl = `${baseUrl}/CheckinForm/${companyId}`;

  useEffect(() => {
    loadCompany();
    generateQRCode();
  }, []);

  const loadCompany = async () => {
    try {
      // Em produção, buscar a empresa real: Company.get(companyId)
      const mockCompany = {
        id: companyId,
        name: "Oficina do Carlos",
        plan: "intermediario",
        qrCodeUrl: null
      };
      setCompany(mockCompany);
    } catch (error) {
      console.error('Erro ao carregar empresa:', error);
    }
  };

  const generateQRCode = async () => {
    setLoading(true);
    try {
      // Gerar QR Code usando biblioteca JavaScript nativa
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      
      // Configurar tamanho do canvas
      const size = 300;
      canvas.width = size;
      canvas.height = size;
      
      // Limpar canvas
      ctx.fillStyle = 'white';
      ctx.fillRect(0, 0, size, size);
      
      // Gerar QR Code usando uma função simples
      await generateQRCodePattern(ctx, checkinUrl, size);
      
      // Adicionar texto da empresa
      ctx.fillStyle = 'black';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(company?.name || 'AutoCheckin', size / 2, size - 10);
      
      // Converter para data URL
      const dataUrl = canvas.toDataURL('image/png');
      setQrCodeDataUrl(dataUrl);
      
    } catch (error) {
      console.error('Erro ao gerar QR Code:', error);
      // Fallback: usar serviço online para gerar QR Code
      const qrServiceUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(checkinUrl)}`;
      setQrCodeDataUrl(qrServiceUrl);
    } finally {
      setLoading(false);
    }
  };

  // Função simples para gerar padrão de QR Code (usando serviço externo como fallback)
  const generateQRCodePattern = async (ctx, text, size) => {
    // Para simplificar, vamos usar um serviço online confiável
    const qrServiceUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(text)}`;
    
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, size, size);
        resolve();
      };
      img.onerror = reject;
      img.src = qrServiceUrl;
    });
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Erro ao copiar:', err);
    }
  };

  const downloadQRCode = () => {
    if (!qrCodeDataUrl) return;
    
    const link = document.createElement('a');
    link.href = qrCodeDataUrl;
    link.download = `qrcode-checkin-${company?.name?.replace(/\s+/g, '-').toLowerCase() || 'oficina'}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const testQRCode = () => {
    window.open(checkinUrl, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* QR Code Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <QrCode className="w-5 h-5" />
            QR Code para Check-in
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* QR Code Display */}
            <div className="text-center">
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg border shadow-sm inline-block">
                  {qrCodeDataUrl ? (
                    <img 
                      src={qrCodeDataUrl} 
                      alt="QR Code Check-in"
                      className="w-64 h-64 object-contain"
                    />
                  ) : (
                    <div className="w-64 h-64 flex items-center justify-center border-2 border-dashed border-gray-300">
                      {loading ? (
                        <div className="text-center">
                          <QrCode className="w-16 h-16 text-gray-400 mx-auto mb-2 animate-pulse" />
                          <p className="text-gray-500">Gerando QR Code...</p>
                        </div>
                      ) : (
                        <div className="text-center">
                          <QrCode className="w-16 h-16 text-gray-400 mx-auto mb-2" />
                          <p className="text-gray-500">QR Code não gerado</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                
                {/* Canvas escondido para geração */}
                <canvas ref={canvasRef} style={{ display: 'none' }} />
                
                <div className="flex justify-center gap-2 flex-wrap">
                  <Button onClick={downloadQRCode} variant="outline" size="sm" disabled={!qrCodeDataUrl}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                  <Button onClick={testQRCode} variant="outline" size="sm">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Testar Link
                  </Button>
                  <Button onClick={generateQRCode} variant="outline" size="sm" disabled={loading}>
                    <QrCode className="w-4 h-4 mr-2" />
                    {loading ? 'Gerando...' : 'Regenerar'}
                  </Button>
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Como usar:</h3>
                <ol className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">1</span>
                    Imprima ou exiba este QR Code na sua oficina
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">2</span>
                    Cliente escaneia com a câmera do celular
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">3</span>
                    Formulário de check-in abre automaticamente
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-5 h-5 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">4</span>
                    Cliente preenche e envia para sua oficina
                  </li>
                </ol>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Smartphone className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-blue-900">Dica Pro:</span>
                </div>
                <p className="text-sm text-blue-700">
                  Coloque o QR Code em local visível na recepção. 
                  Clientes podem fazer check-in antes mesmo de chegar à oficina!
                </p>
              </div>

              <div className="p-4 bg-green-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <ExternalLink className="w-4 h-4 text-green-600" />
                  <span className="font-medium text-green-900">Link do QR Code:</span>
                </div>
                <p className="text-xs text-green-700 font-mono break-all mb-2">{checkinUrl}</p>
                <Button 
                  onClick={testQRCode} 
                  size="sm" 
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  Testar Link Diretamente
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Link Sharing */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Compartilhar Link Direto
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="checkin-url">URL do Check-in</Label>
            <div className="flex gap-2 mt-1">
              <Input
                id="checkin-url"
                value={checkinUrl}
                readOnly
                className="flex-1 font-mono text-sm"
              />
              <Button 
                onClick={() => copyToClipboard(checkinUrl)}
                variant="outline"
              >
                <Copy className="w-4 h-4 mr-2" />
                {copied ? 'Copiado!' : 'Copiar'}
              </Button>
            </div>
          </div>
          
          <div className="text-sm text-gray-600">
            <p>💡 <strong>Use este link para:</strong></p>
            <ul className="list-disc list-inside space-y-1 mt-2 ml-4">
              <li>Enviar por WhatsApp para clientes</li>
              <li>Colocar no site da oficina</li>
              <li>Adicionar em cartões de visita digitais</li>
              <li>Compartilhar nas redes sociais</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Plan Info */}
      {company && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Badge className="bg-blue-100 text-blue-800">
                  Plano {company.plan}
                </Badge>
                <span className="text-sm text-gray-600">
                  QR Code funcional disponível
                </span>
              </div>
              {company.plan === 'basico' && (
                <Button variant="outline" size="sm">
                  Upgrade para Pro
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}