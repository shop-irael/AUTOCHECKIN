import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CreditCard, Check, Star } from "lucide-react";
import { createCheckoutSession } from '@/api/functions';
import { User } from '@/api/entities';

export default function StripeCheckout({ plan, companyId, onClose }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleCheckout = async () => {
    setLoading(true);
    setError(null);
    try {
      const user = await User.me();
      const response = await createCheckoutSession({
        planId: plan.id,
        companyId: companyId,
        customerEmail: user.email,
        customerName: user.full_name,
      });

      // Tratamento de erro robusto
      if (response.error) {
        throw new Error(response.error.message || 'Erro na comunicação com o servidor.');
      }
      if (response.data && response.data.error) {
        throw new Error(response.data.details || response.data.error);
      }
      if (response.data && response.data.url) {
        window.location.href = response.data.url;
      } else {
        throw new Error('URL de checkout não foi recebida do servidor.');
      }
    } catch (err) {
      console.error('Erro detalhado ao iniciar checkout:', err);
      setError(`Não foi possível iniciar o pagamento. Por favor, tente novamente. Detalhe: ${err.message}`);
    } finally {
      // Garante que o loading seja desativado, evitando o carregamento infinito
      setLoading(false);
    }
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          {plan.popular && (
            <Badge className="bg-blue-600 text-white mb-2">
              <Star className="w-4 h-4 mr-1" />
              Mais Popular
            </Badge>
          )}
        </div>
        <CardTitle className="text-2xl">
          Plano {plan.name}
        </CardTitle>
        <div className="text-center mt-4">
          <span className="text-4xl font-bold text-gray-900">R$ {plan.price}</span>
          <span className="text-gray-600">/mês</span>
        </div>
        <p className="text-sm text-gray-500 mt-2">{plan.checkins}</p>
      </CardHeader>

      <CardContent className="space-y-6">
        <div>
          <h4 className="font-semibold mb-3">Funcionalidades incluídas:</h4>
          <ul className="space-y-2">
            {plan.features.slice(0, 5).map((feature, index) => (
              <li key={index} className="flex items-start gap-2">
                <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span className="text-sm">{feature}</span>
              </li>
            ))}
            {plan.features.length > 5 && (
              <li className="text-sm text-gray-500">
                + {plan.features.length - 5} outras funcionalidades
              </li>
            )}
          </ul>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        )}

        <div className="space-y-3">
          <Button 
            onClick={handleCheckout}
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-3"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Processando...
              </>
            ) : (
              <>
                <CreditCard className="mr-2 h-5 w-5" />
                Assinar Agora
              </>
            )}
          </Button>

          <Button 
            variant="outline" 
            onClick={onClose}
            className="w-full"
            disabled={loading}
          >
            Cancelar
          </Button>
        </div>

        <div className="text-center space-y-1">
          <p className="text-xs text-gray-500">
            🔒 Pagamento seguro processado pelo Stripe
          </p>
          <p className="text-xs text-gray-500">
            Cancele a qualquer momento
          </p>
        </div>
      </CardContent>
    </Card>
  );
}