import React, { useRef, useEffect, useState } from 'react';
import { Button } from "@/components/ui/button";
import { Eraser, RefreshCw } from 'lucide-react';

export default function SignatureCanvas({ onSave, width = 400, height = 200, signature }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isEmpty, setIsEmpty] = useState(true);

  const getCanvasContext = () => canvasRef.current.getContext('2d');

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = getCanvasContext();
    // Set canvas dimensions based on props or parent
    const parentWidth = canvas.parentElement.clientWidth;
    canvas.width = Math.min(width, parentWidth > 0 ? parentWidth : width);
    canvas.height = height;

    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (signature) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        setIsEmpty(false);
      }
      img.src = signature;
    } else {
      clearCanvas();
    }

  }, [width, height, signature]);

  const getCoordinates = (event) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    if (event.touches && event.touches.length > 0) {
      return {
        x: event.touches[0].clientX - rect.left,
        y: event.touches[0].clientY - rect.top,
      };
    }
    return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
    };
  };

  const startDrawing = (event) => {
    const { x, y } = getCoordinates(event);
    const ctx = getCanvasContext();
    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
    setIsEmpty(false);
  };

  const draw = (event) => {
    if (!isDrawing) return;
    const { x, y } = getCoordinates(event);
    const ctx = getCanvasContext();
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const endDrawing = () => {
    if (!isDrawing) return;
    const ctx = getCanvasContext();
    ctx.closePath();
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = getCanvasContext();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // Draw a light grey placeholder box or text
    ctx.fillStyle = '#f0f0f0';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#999';
    ctx.font = '14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Assine aqui', canvas.width / 2, canvas.height / 2);
    setIsEmpty(true);
  };

  const handleSave = () => {
    if (isEmpty) {
      alert("Por favor, forneça uma assinatura.");
      return;
    }
    const dataUrl = canvasRef.current.toDataURL('image/png');
    onSave(dataUrl);
  };

  return (
    <div className="w-full">
      <canvas
        ref={canvasRef}
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={endDrawing}
        onMouseOut={endDrawing} // Prevents line from sticking if mouse leaves canvas while drawing
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={endDrawing}
        className="border border-gray-300 rounded-lg cursor-crosshair bg-white touch-none w-full"
        style={{ touchAction: 'none' }} // Important for touch devices
      />
      <div className="mt-2 flex flex-wrap gap-2">
        <Button type="button" variant="outline" onClick={clearCanvas} className="text-sm">
          <RefreshCw className="w-4 h-4 mr-2" />
          Limpar
        </Button>
        <Button type="button" onClick={handleSave} disabled={isEmpty} className="text-sm bg-blue-600 hover:bg-blue-700">
          Confirmar Assinatura
        </Button>
      </div>
    </div>
  );
}