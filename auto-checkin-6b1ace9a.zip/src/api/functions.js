import { base44 } from './base44Client';


export const confirmPayment = base44.functions.confirmPayment;

export const createPaymentIntent = base44.functions.createPaymentIntent;

export const handleStripeWebhook = base44.functions.handleStripeWebhook;

export const verifyCheckoutSession = base44.functions.verifyCheckoutSession;

export const createCheckoutSession = base44.functions.createCheckoutSession;

