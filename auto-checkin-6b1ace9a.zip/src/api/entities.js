import { base44 } from './base44Client';


export const Servico = base44.entities.Servico;

export const Checkin = base44.entities.Checkin;

export const Company = base44.entities.Company;

export const DemoRequest = base44.entities.DemoRequest;

export const WhatsAppConfig = base44.entities.WhatsAppConfig;



// auth sdk:
export const User = base44.auth;